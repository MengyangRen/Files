
[主-/mysql/conf.d/docker.cnf]
[mysqld]
sql_mode="STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
skip-host-cache
skip-name-resolve
max_connections=5000

server-id=1
log_bin=mysql-bin
log_bin_index=mysql-bin.index
bind-address=0.0.0.0
binlog_format=mixed
binlog_cache_size=1M
expire_logs_days=7
binlog_do_db=video_douyin
binlog_do_db=aqiyi
#binlog-ignore-db=mysql
sync-binlog=1



[从-/mysql/conf.d/docker.cnf]
[mysqld]
sql_mode="STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
skip-host-cache
skip-name-resolve
max_connections=5000


server-id=105
relay-log=relay-log
relay-log-index=relay-log.index
binlog-ignore-db=mysql 
log_bin=mysql-slave1-bin
binlog_cache_size=1M 
binlog_format=mixed 
expire_logs_days=7 
log_slave_updates=1 
slave_skip_errors=1062  
read_only=1

[从-/mysql/conf.d/docker.cnf]
[mysqld]
sql_mode="STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
skip-host-cache
skip-name-resolve
max_connections=5000

server-id=3
relay-log=relay-log
relay-log-index=relay-log.index
log_bin=mysql-bin
read_only=1


[配置说明]
## 设置server_id，一般设置为IP，同一局域网内注意要唯一
server_id=100  
## 复制过滤：也就是指定哪个数据库不用同步（mysql库一般不同步）
binlog-ignore-db=mysql
## 开启二进制日志功能，可以随便取，最好有含义（关键就是这里了）
log-bin=edu-mysql-bin  
## 主从复制的格式（mixed,statement,row，默认格式是statement）
binlog_format=mixed 
## 二进制日志自动删除/过期的天数。默认值为0，表示不自动删除。
expire_logs_days=7  
## 跳过主从复制中遇到的所有错误或指定类型的错误，避免slave端复制中断。
## 如：1062错误是指一些主键重复，1032错误是因为主从数据库数据不一致
slave_skip_errors=1062

docker run -d \
   -e MYSQL_ROOT_PASSWORD=123abc \
   -p 3308:3306 \
   -v /home/docker/mysql-slave-1/data/:/var/lib/mysql/ \
   -v /home/docker/mysql-slave-1/conf.d/docker.cnf:/etc/mysql/conf.d/docker.cnf \
   --name mysql-slave-1 \
   --privileged=true  \
   mysql:5.7 \
   --character-set-server=utf8mb4 \
   --collation-server=utf8mb4_unicode_ci


//show master status;
show slave status

CREATE USER 'slave-'@'%' IDENTIFIED BY '123abc';
GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'slave1'@'%';  

CREATE USER 'slave2'@'%' IDENTIFIED BY '123abc';
GRANT REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'slave2'@'%';  

change master to master_host='172.17.0.2', master_user='slave1', master_password='123abc', master_port=3306, master_log_file='mysql-bin.000050', master_log_pos=21580, master_connect_retry=30;

master_host: Master 的IP地址
master_user: 在 Master 中授权的用于数据同步的用户
master_password: 同步数据的用户的密码
master_port: Master 的数据库的端口号
master_log_file: 指定 Slave 从哪个日志文件开始复制数据，即上文中提到的 File 字段的值
master_log_pos: 从哪个 Position 开始读，即上文中提到的 Position 字段的值
master_connect_retry: 当重新建立主从连接时，如果连接失败，重试的时间间隔，单位是秒，默认是60秒。

change master to master_log_file='mysql-bin.000050',master_log_pos=708;

#并行复制配置
[从-/mysql/conf.d/docker.cnf]
[mysqld]
sql_mode="STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"
skip-host-cache
skip-name-resolve
max_connections=5000

server-id=3
relay-log=relay-log
relay-log-index=relay-log.index

read_only=1

slave-parallel-type=LOGICAL_CLOCK
slave-parallel-workers=16
master_info_repository=4
relay_log_info_repository=TABLE
relay_log_recovery=ON


