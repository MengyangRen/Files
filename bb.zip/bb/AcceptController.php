<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Basesvr\SimpleCommon\Utils\AES;
use Basesvr\SimpleCommon\Accept;
use Illuminate\Support\Facades\Route;

class AcceptController extends Controller
{

    static $_version = null;

    public function __construct()
    {
        if (preg_match("#api/v([0-9])/#",request()->path(), $matches)) {
            self::$_version = $matches[1];
        }
    }

    /**
     *
     * accept
     *
     * @param Request $request
     * @return mixed|\Psr\Http\Message\StreamInterface
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    public function accept (Request $request)
    {
        $routerParameters = $request->all();

        if (!isset($routerParameters['data'])) throw new \Exception('error accept params.');
        
        $data = AES::getInstance(
            self::$_version
                ? config('sys.encrpytion_key_' . self::$_version)
                : null
        )->decrypt($routerParameters['data']);

        $dataArr = \GuzzleHttp\json_decode($data, true);

        $request->merge($dataArr['params']);

        $dataArr['headers'] = array_merge($dataArr['headers'] ?? [], [
            'Accept' => 'application/json',
        ]);

        //设置头部信息
        foreach ($dataArr['headers'] as $k => $v){

            $request->headers->set($k, $v);

        }

        if (!isset($dataArr['uri']) || !isset($dataArr['method'])) throw new \Exception('data实体参数错误.');

        return Route::dispatch($request::create($dataArr['uri'], $dataArr['method']));

        //dd($routerParameters,$dataArr);

//        return Accept::getInstance($dataArr['uri'],
//            $dataArr['method'],
//            $dataArr['headers'] ?? [],
//            $dataArr['params'] ?? []
//        )->getResponseFromServer();
    }

    public function testResponse ()
    {
        //$method = $this->testVideoLists();
        $method = $this->testVideoCatList();


        $a = AES::getInstance()->encrypt(json_encode($method));
        return [
            'data' => $a,
        ];
        $b = AES::getInstance()->decrypt(urldecode($a));
        dd($b);
    }

    /**
     *
     * 测试api.version   70Hc4INbSXAxXpbAp2Dkwtsbzp2HS1SrnjesVXKEDTGdB4N3qDNDYXbhMgtKYdrAMekMyVOHKyODu8baqB%2F7rjBr2cR%2FlFTkZ8w8qgnQZB8%3D
     *
     * @return array
     */
    protected function testVersion ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/version',
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer 9b8b1bbfc38e0fa29dcf9ed2b2fdea67 1015c2dc5151ca9b3.84677706',
                'device_code' => 'test-0000-0000-0001'
            ],
            'params' => [
                'platform' => 'A'
            ]
        ];
    }

    /**
     *
     * 70Hc4INbSXAxXpbAp2DkwmL1oTlRdklXPJuKRohsJY6htWNxY6NW0h5T52iXhAxzpcPUt72NCqKAga7gUfMcU35FWwHe%2F5zVsE8U33msEVoUGc7up2UuCQl%2BDSCbduAZvbO1sbp7mAe7q%2B0SmLADCd4k6Z9j7wqB3KSz0sMrAk2ZvFV%2BOBfGREHe34OwJXMku2oWhLm2zwidmEq3H%2BlcSyajPxFf%2BnDEOgPaKcIN8ZG1s8%2BW0o%2FNkxky80S6O1KM7GILSSJbQIbDg9BZlJEdBVIhPbasqQV0vvVYQOUNMl0aj7jnPe6dlY5%2Fr6s29N6Cg0DX9Jm6EC3VuCr7qrTuQgZlcKHBjTCKh%2FoewpB6pgQ%3D
     *
     * @return array
     */
    protected function testVideoLists ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/v2/video/lists',
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer 1b5ffc3f532f11bc7f3bfd12a7dae9b9 3645da8dfb9bdc325.27216583',
                'device_code' => 'test-0000-0000-0001',
            ],
            'params' => [
                //'video_title' => '女',
                //'key_id' => 1,
                'limit' => 10,
                'page' => 1,
            ]
        ];
    }

    /**
     *
     * 70Hc4INbSXAxXpbAp2DkwmL1oTlRdklXPJuKRohsJY5J3oiX2cH9v3wm348mAOxL5QWt%2FcdqQnsIoDG9TPYLQ7yzCSybSDaX9O7MKjziq8r9H%2BSx17U3BVEn86X0pWk5r7nJ3D2TFtfqQvFI1PoXDZeV46OLv6E0o99%2F5C9A0eAxYH1%2Fln%2B2%2Fw4a34FkQ2kXgGb6l4QHJoQLYBoZrmt6aHQYen04sGvTtPAbdor6YZ8%3D
     *
     * @return array
     */
    protected function testVideoInfo ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/video/info',
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer 1b5ffc3f532f11bc7f3bfd12a7dae9b9 3645da8dfb9bdc325.27216583'
            ],
            'params' => [
                'video_id' => 17337
            ]
        ];
    }

    /**
     *
     * dTHvPuU92JpdUZRx6WgOao632k4x1aM%2BBPMPbrRe5pQ4Yf9VCjAhIOxurnTU4HTnq2bRS1g44giwS%2FUoJ%2BOhg244xNRi4xE40XjaDjDWXxhb%2BZNqrkVjNuls5M1h2v0pQj0a6XA%2F%2FkuCywAHCzfeNwsoFAtSKmOKnOkRHRg4C%2FtE%2BkTwBhKCiWjYGPG0z46h7Oa%2Bjkiv%2BixHjZUmEOrZXa2XyVb3iV1wPGiJCV%2BB9Y6K2pMLwOI5KXrbma%2FLKSQyroqPCtzCI3TXTfz2Ek0ypRAnr60ygUPU3YCF6mo8tPVFCVQZV%2FfkrXTiFDVdoKsR0fiWRL%2FWdLAppfqU4QmJQQXn67M4CgRPmLFDri%2Fh9iJCMBaoW7z3IJZZT6GNA%2FL1cdv5mupTcwcVuKuELAcAr1mzQDfLlepgydhiDbxTkTE%3D
     *
     * @return array
     */
    protected function testVideoCommentAdd ()
    {
        return [
            'method' => 'POST',
            'uri' => '/api/video/user/comment/add',
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer 1b5ffc3f532f11bc7f3bfd12a7dae9b9 3645da8dfb9bdc325.27216583'
            ],
            'params' => [
                'video_id' => 1,
                'global_type' => 'film',
                'content' => '卧槽啦啦啦啦啦牛逼啊！',
            ]
        ];
    }

    /**
     *
     * 70Hc4INbSXAxXpbAp2DkwmL1oTlRdklXPJuKRohsJY7z9x2R9wzcrtm4rmvIwuUWixadYy2eFxi1I736diX6B%2FwXpWypS5q500Lco%2FA%2FfR8%3D
     *
     * @return array
     */
    protected function testVideoDict ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/video/dict',
            'params' => [
                'global_type' => 'film',
            ]
        ];
    }

    /**
     *
     * 获取域名列表
     *
     * eg:70Hc4INbSXAxXpbAp2DkwtUZUF7M2%2BX%2FhmCNsoCOFDkZeaOgNyZhwPTmT34Zhg3E2WfTonsTX9hGW7V9%2Bzglk0sj%2FuDsBqPdABBLaVxhKHE%3D
     *
     * @return array
     */
    protected function testPublicDomain ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/domain',
            'headers' => [
                'Accept' => 'application/json',
            ]
        ];

    }

    /**
     *
     * 获取电影分类列表-V2
     *
     * eg:70Hc4INbSXAxXpbAp2DkwtUZUF7M2%2BX%2FhmCNsoCOFDkZeaOgNyZhwPTmT34Zhg3E2WfTonsTX9hGW7V9%2Bzglk0sj%2FuDsBqPdABBLaVxhKHE%3D
     *
     * @return array
     */
    protected function testVideoCatList ()
    {
        return [
            'method' => 'GET',
            'uri' => '/api/v2/video-cat/list',
            'headers' => [
                'Accept' => 'application/json',
                'Authorization' => 'Bearer 1b5ffc3f532f11bc7f3bfd12a7dae9b9 3645da8dfb9bdc325.27216583',
            ],
            'params' => [
                'limit' => 20,
                'page' => 1,
            ]
        ];
    }

}