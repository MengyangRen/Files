
SELECT
    ue.channel AS '渠道',
	count(*) AS '(2019-10-1实际安装人数/注册人数)' 
FROM
	users AS ue 
WHERE
	ue.created_at BETWEEN '2019-10-1 00:00:00' 
	AND '2019-10-1 23:59:00'
	AND ue.channel = 'DY8888' 
	AND ue.`from` = 'ql1' 


# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额'
FROM
	(
	SELECT
		o.user_id,
		o.pay_price
	FROM
		v_order AS o
		LEFT JOIN users AS ue ON o.user_id = ue.id 
	WHERE
	ue.created_at BETWEEN '2019-10-1 00:00:00' 
	AND '2019-10-1 23:59:00'
	AND o.order_type = 2 
	AND o.pay_status = 1 
	AND ue.channel = 'DY8888' 
	AND ue.`from` = 'ql1' 
	GROUP BY
		o.user_id
	HAVING
	count(*) = 1 
) AS tt;
