#实际的安装人数
SELECT
	ue.channel AS '渠道',
	count(*) AS '2019-10-7(实际安装人数/注册人数)' 
FROM
	v_user_extend AS ue 
WHERE
	ue.created_at BETWEEN '2019-10-7 00:00:00' 
	AND '2019-10-7 23:59:00' 
	AND ue.channel = 'zyw001' 
	AND ue.`from` = 'tg';

# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额',
	SUM( tt.price_current ) AS '总(当前价格)',
	SUM( tt.price_original ) AS '总(原价)' 
FROM
	(
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current 
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		o.created_at BETWEEN '2019-10-7 00:00:00' 
		AND '2019-10-7 23:59:00' 
		AND o.order_type = 2 
		AND o.pay_status = 1 
		AND ue.channel = 'zyw001' 
		AND ue.`from` = 'tg' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
	count(*) = 1 
) AS tt;



#实际的安装人数
SELECT
	ue.channel AS '渠道',
	count(*) AS '2019-10-7(实际安装人数/注册人数)' 
FROM
	v_user_extend AS ue 
WHERE
	ue.created_at BETWEEN '2019-10-7 00:00:00' 
	AND '2019-10-7 23:59:00' 
	AND ue.channel = 'ffqd002' 
	AND ue.`from` = 'ad';

# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额',
	SUM( tt.price_current ) AS '总(当前价格)',
	SUM( tt.price_original ) AS '总(原价)' 
FROM
	(
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current 
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		o.created_at BETWEEN '2019-10-7 00:00:00' 
		AND '2019-10-7 23:59:00' 
		AND o.order_type = 2 
		AND o.pay_status = 1 
		AND ue.channel = 'ffqd002' 
		AND ue.`from` = 'ad' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
	count(*) = 1 
) AS tt;