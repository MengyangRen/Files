#实际的安装人数
SELECT
	ue.channel AS '渠道',
	count(*) AS '2019-10-7(实际安装人数/注册人数)' 
FROM
	v_user_extend AS ue 
WHERE
	ue.created_at BETWEEN '2019-10-7 00:00:00' 
	AND '2019-10-7 23:59:00' 
	AND ue.channel = 'ffqd01' 
	AND ue.`from` = 'xu';

# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额',
	SUM( tt.price_current ) AS '总(当前价格)',
	SUM( tt.price_original ) AS '总(原价)' 
FROM
	(
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current 
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		o.created_at BETWEEN '2019-11-12 00:00:00' 
		AND '2019-11-12 23:59:00' 
		AND o.order_type = 2 
		AND o.pay_status = 1 
		#AND ue.channel = 'ffqd01' 
		#AND ue.`from` = 'xu' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
	count(*) = 1 
) AS tt;

# ad-sp
#实际的安装人数
SELECT
	ue.channel AS '渠道',
	count(*) AS '(实际安装人数/注册人数)' 
FROM
	v_user_extend AS ue 
WHERE
	 ue.channel = 'ad' 
	AND ue.`from` = 'sp';
	
# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额',
	SUM( tt.price_current ) AS '总(当前价格)',
	SUM( tt.price_original ) AS '总(原价)' 
FROM
	(
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current 
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		 o.order_type = 2 
		AND o.pay_status = 1 
		AND ue.channel = 'ad' 
		AND ue.`from` = 'sp' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
	count(*) = 1 
) AS tt;

# 777/12
#实际的安装人数
SELECT
	ue.channel AS '渠道',
	count(*) AS '(实际安装人数/注册人数)' 
FROM
	v_user_extend AS ue 
WHERE
	 ue.channel = '777' 
	AND ue.`from` = '12';

# 统计实际支付总人数/金额 (无重复)
SELECT
	count( user_id ) AS '支付成功人数',
	SUM( tt.pay_price ) AS '实际支付总金额',
	SUM( tt.price_current ) AS '总(当前价格)',
	SUM( tt.price_original ) AS '总(原价)' 
FROM
	(
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current 
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		 o.order_type = 2 
		AND o.pay_status = 1 
		AND ue.channel = '777' 
		AND ue.`from` = '12' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
	count(*) = 1 
) AS tt;

#抖音(所有)
渠道	(实际安装人数/注册人数)
ad	636
支付成功人数	实际支付总金额	总(当前价格)	总(原价)
14	944.92	945.00	1005.00
-------------------------------

#
-----------------------------------------

/**
 * 
 * 统计支付失败的总人数/金额
 * 
 */

SELECT 
 count(user_id) AS '支付失败人数(支付失败+未支付的)',
 SUM(tt.pay_price) AS '实际失败总金额',
 SUM(tt.price_current) AS '总(当前价格)',
 SUM(tt.price_original) AS '总(原价)'
FROM (
	SELECT
		ue.channel,
		o.user_id,
		o.pay_price,
		o.price_original,
		o.price_current
	FROM
		v_order AS o
		LEFT JOIN v_user_extend AS ue ON o.user_id = ue.user_id 
	WHERE
		o.created_at BETWEEN '2019-10-7 00:00:00' 
		AND '2019-10-7 23:59:00' 
		AND o.order_type = 2
		AND o.pay_status != 1 
		AND ue.channel = 'ffqd01' 
		AND ue.`from` = 'xu' 
	GROUP BY
		o.user_id,
		o.wc_title 
	HAVING
		count(*) = 1
) AS tt;


#福利卡
#有问题
SELECT
	wc_id as '福利卡ID',
	code  as '邀请码'
FROM
	v_welfare_card_code AS o 
WHERE
		o.created_at BETWEEN '2019-10-7 00:00:00' 
		AND '2019-10-7 23:59:00' 

DELETE FROM tb WHERE CreateTime BETWEEN '2017-01-01 00:00:00' AND '2017-02-01 00:00:00'

DELETE FROM v_welfare_card_code WHERE created_at BETWEEN '2019-10-7 00:00:00' AND '2019-10-7 23:59:00'; 
DELETE FROM v_welfare_card_code WHERE created_at BETWEEN '2019-10-7 00:00:00' AND '2019-10-7 23:59:00'; 

SELECT
	wc_id as '福利卡ID',
	code  as '邀请码'
FROM
	v_welfare_card_code AS o 
WHERE
    o.wc_id = 5
	AND o.created_at BETWEEN '2019-10-22 00:00:00' 
	AND '2019-10-22 23:59:00'


DELETE TABLE v_welfare_card_code where o.created_at 
	BETWEEN '2019-09-26 00:00:00' AND '2019-09-26 23:59:00' 


DELETE TABLE v_welfare_card_code where o.created_at 
	BETWEEN '2019-10-07 00:00:00' AND '2019-10-07 23:59:00' 

DELETE TABLE v_welfare_card_code where o.created_at 
	BETWEEN '2019-10-11 00:00:00' AND '2019-10-11 23:59:00' 


SELECT
	wc_id as '福利卡ID',
	code  as '邀请码'
FROM
	v_welfare_card_code AS o 
WHERE
		o.created_at BETWEEN '2019-10-11 00:00:00' 
		AND '2019-10-11 23:59:00' 



CREATE TABLE `v_activity` (
  `id` smallint(11) NOT NULL AUTO_INCREMENT,
  `as` char(32) NOT NULL COMMENT ' 别名',
  `title` varchar(255) NOT NULL COMMENT '活动title',
  `banner_oss_path` varchar(200) NOT NULL,
  `icon_oss_path` varchar(200) NOT NULL,
  `type` enum('LINK','INTERNAL-LINK') NOT NULL,
  `redirect_url` varchar(200) DEFAULT NULL,
  `redirect_position` char(50) DEFAULT NULL COMMENT '类型为内链接,跳转的位置 ACT_DETAIL',
  `sort` tinyint(2) NOT NULL DEFAULT '10',
  `start_date` datetime NOT NULL COMMENT '开始时间',
  `end_date` datetime NOT NULL COMMENT '结束时间',
  `days` tinyint(1) DEFAULT NULL COMMENT '活动天数',
  `child_act` varchar(255) NOT NULL COMMENT '子活动（DYNAMIC_PRAISE,VIDEO_PRAISE,UPLOAD_VIDEO',
  `topics` varchar(255) DEFAULT NULL COMMENT '参与活动的话题圈12,234,345',
  `rules_desc` text COMMENT '活动规则简单描述',
  `rules_detail` text COMMENT '活动规则详情',
  `display` tinyint(1) DEFAULT '0' COMMENT '是否在首页显示（0不显示，1显示）',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='活动表';

#新增表
CREATE TABLE `v_ad` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`key` char(50) NOT NULL,
	`type` enum('LINK','VIDEO','VIDEO-AD','INTERNAL-LINK') DEFAULT NULL,
	`title` varchar(20) NOT NULL,
	`remark` varchar(100) DEFAULT NULL,
	`cover_oss_path` varchar(200) NOT NULL,
	`redirect_url` varchar(200) DEFAULT NULL,
	`redirect_position` char(50) DEFAULT NULL COMMENT '类型为内链接,跳转的位置（ MEMBER_CENTER，TASK_INTERFACE，LU_FRIENDLY）',
	`sort` tinyint(2) NOT NULL DEFAULT '0',
	`video_id` int(11) DEFAULT '0',
	`status` tinyint(1) unsigned NOT NULL DEFAULT '1',
	`created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
	`updated_at` timestamp NULL DEFAULT NULL,
	`deleted_at` timestamp NULL DEFAULT NULL,
	PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;

CREATE TABLE `v_key_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` char(10) NOT NULL,
  `sort` tinyint(2) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35239 DEFAULT CHARSET=utf8mb4 COMMENT '搜索关键字';


#创建通知表


CREATE TABLE `v_key_words` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` char(10) NOT NULL,
  `sort` tinyint(2) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35239 DEFAULT CHARSET=utf8mb4 COMMENT '搜索关键字';

CREATE TABLE `v_topic_collect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT  0 COMMENT '用户Aid',
  `topic_id` int(11) NOT NULL DEFAULT  0 COMMENT '话题id',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_unique` (`uid`,`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='话题收藏关系表';

CREATE TABLE `v_msg_notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL COMMENT '类型:FELLOW-PUSH(关注好友发布），TOPIC-UPDATE(话题圈更新)',
  `user_id` int(11) NOT NULL DEFAULT  0 COMMENT '用户id',
  `topic_id` int(11) NOT NULL DEFAULT  0 COMMENT '话题id',
  `dynamic_id` int(11) NOT NULL DEFAULT 0 COMMENT '动态id',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COMMENT='消息-通知表';


CREATE TABLE `v_user_receive_msg` (
	`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
	`user_id` int(11) unsigned NOT NULL DEFAULT  0,
	`notice_max_id`  int(11)  unsigned  NOT NULL DEFAULT  0,
	`comment_max_id` int(11)  unsigned  NOT NULL DEFAULT  0,
	`praise_max_id`  int(11)  unsigned  NOT NULL DEFAULT  0,
	`system_max_id`  int(11)  unsigned  NOT NULL DEFAULT  0,
	`follower_max_id` int(11) unsigned  NOT NULL DEFAULT  0,
	`created_at` timestamp NULL DEFAULT NULL,
	`updated_at` timestamp NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



insert into tb_xx(user_id,0,0,0,0) select id as user_id, from users
-- {{notice_act_as}} {{type}} 发布了视频
-- {{notice_act_as}} {{type}} 更新了视频
-- {{notice_act_as}} {{type}} 发布了动态
-- {{notice_act_as}} {{type}} 更新了动态


CREATE TABLE `v_msg_notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL COMMENT '类型:FELLOW-PUSH(关注好友发布），TOPIC-UPDATE(话题圈更新)',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `topic_id` int(11) DEFAULT NULL COMMENT '话题id',
  `dynamic_id` int(11) DEFAULT NULL COMMENT '动态id',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-通知表';


CREATE TABLE `v_msg_notice` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL COMMENT '类型:FELLOW-PUSH(关注好友发布），TOPIC-UPDATE(话题圈更新)',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `topic_id` int(11) DEFAULT NULL COMMENT '话题id',
  `dynamic_id` int(11) DEFAULT NULL COMMENT '动态id',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-通知表';


CREATE TABLE `v_msg_praise` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('VIDEO','VIDEO-COMMENT','DY-COMMENT','DYNAMIC') DEFAULT NULL COMMENT '类型:VIDEO(点赞视频),VIDEO-COMMENT(点赞视频评论),DY-COMMENT（点赞动态评论),DYNAMIC(点赞动态)',
  `from_uid` int(11) DEFAULT NULL COMMENT '点赞者id',
  `to_uid`int(11) DEFAULT NULL COMMENT '目标用户id',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-点赞通知表';


CREATE TABLE `v_msg_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('VIDEO','DY') DEFAULT NULL COMMENT '类型:VIDEO(首页视频),DY(动态)',
  `from_uid` int(11) DEFAULT NULL COMMENT '评论id',
  `to_uid`int(11) DEFAULT NULL COMMENT '目标用户id',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-点赞通知表';


CREATE TABLE `v_msg_follower` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) DEFAULT NULL COMMENT '关注者id',
  `to_uid`int(11) DEFAULT NULL COMMENT '目标用户id',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-关注表';




CREATE TABLE `v_msg_system` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid`int(11) DEFAULT NULL COMMENT '用户id',
  `type` enum('DY-IMG-TEXT-AUDI','DY-VIDEO-AUDI') DEFAULT NULL COMMENT '类型:DY-IMG-TEXT-AUDI(动态图文审核),DY-VIDEO-AUDI(动态视频-审核通过)',
  `json` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='消息-关注表';


INSERT subject_group_r (
	data_id,
	data_type,
	subject_id,
	group_id
) 
insert into v_user_receive_msg (
	user_id,created_at
)select 
     id,
     created_at
  from
     users;



INSERT INTO users SELECT id as user_id,created_at FROM v_user_receive_msg;

    insert into insertTest select * from insertTest2;

DROP procedure record_timestamp_deal ;
##创建存储过程
create procedure record_timestamp_deal()

begin

declare tslogId varchar(50);
declare done int default 0;

# declare existence boolean ;

##从时间戳记录表中获取ID存入游标
declare cur cursor for select id from time_stamp_log;

##异常处理
declare continue handler for sqlstate '02000' set done = 1;

open cur;
    ##取出游标值至变量中
    fetch next from cur into tslogId;
    
repeat
    if not done then 
        #查询时间戳待记录id是否在时间戳待存证表
        if (select * from osv_timestamp_evi_prepare where timestampId = tslogId) is not null then
            ##不存在的记录写入待存证表
            insert into osv_timestamp_evi_prepare(timestampId,createTime) values(tslogId,now());
        end if;
    end if;

    ##重新抓取数据进入循环
    fetch next from cur into tslogId;

##结束循环
until done end repeat;

##关闭游标
close cur;

end ;


call record_timestamp_deal();

-----------------
1.话题圈更新动态
  --您收藏的话题圈更新了动态
  --您关注的好友发布了动态 {
     1.图文
     2.视频
  }

---------------------
3.话题圈发布图文