
#该条语句触发- Creating Sort Index
#导致Cpu 占用率的原因之一

SELECT
	* 
FROM
	`v_video_comment` 
WHERE
	`v_video_comment`.`parent_id` IN (337395,
		318658,
		304463
	) 
ORDER BY
	`created_at` DESC





SELECT
	`v_topic_content`.*,
	(
	SELECT
		count(*) 
	FROM
		`v_topic_content_comment` 
	WHERE
		`v_topic_content`.`id` = `v_topic_content_comment`.`topic_content_id` 
	AND `parent_id` = ?) AS `comment_count` 
FROM
	`v_topic_content` 
WHERE
	(
		`topic_id` = ? 
		AND `is_recommend` = ? 
	AND `check` = ?) 
	AND `v_topic_content`.`deleted_at` IS NULL 
ORDER BY
	`is_top` DESC,
	`created_at` DESC 
	LIMIT 15 OFFSET 0

	select count(*) as aggregate from `users` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id` left join `v_user_invite_code` on `owner_user_id` = `users`.`id` left join `v_vip_card` on `v_vip_card`.`id` = `v_user_extend`.`vip_id` where `users`.`is_robot` = ? and `nikename` like ?
	
