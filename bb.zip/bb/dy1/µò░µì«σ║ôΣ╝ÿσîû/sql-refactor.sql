
Count: 14  Time=46.92s (656s)  Lock=0.00s (0s)  Rows=1.0 (14), 2users@2hosts
select count(*) as aggregate from `users` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id` left join `v_user_invite_code` on `owner_user_id` = `users`.`id` left join `v_vip_card` on `v_vip_card`.`id` = `v_user_extend`.`vip_id` where `users`.`is_robot` = 1


