
# mysqldumpslow -s at -t 20 a4733e9108c0-slow.log
# 按照平均查询时间进行排序，同时取排序的前20个

Reading mysql slow query log from a4733e9108c0-slow.log

Count: 1  Time=724.52s (724s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE FROM `v_order_history`

Count: 4  Time=372.50s (1489s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE
  FROM
  `video_douyin`.`v_order`
  WHERE
  `pay_type` = 'S'
  AND `order_type` = 'S'
  AND `vc_id` = 'S'
  LIMIT N

Count: 1  Time=55.47s (55s)  Lock=0.00s (0s)  Rows=3819061.0 (3819061), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_msg_queue`

Count: 1  Time=54.18s (54s)  Lock=0.00s (0s)  Rows=11086953.0 (11086953), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_video_appraise`

Count: 1  Time=48.26s (48s)  Lock=0.00s (0s)  Rows=3700709.0 (3700709), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `users`

Count: 14  Time=46.92s (656s)  Lock=0.00s (0s)  Rows=1.0 (14), 2users@2hosts
  select count(*) as aggregate from `users` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id` left join `v_user_invite_code` on `owner_user_id` = `users`.`id` left join `v_vip_card` on `v_vip_card`.`id` = `v_user_extend`.`vip_id` where `users`.`is_robot` = N

Count: 2  Time=45.01s (90s)  Lock=0.00s (0s)  Rows=13.0 (26), root[root]@[139.180.128.226]
  SELECT
  *
  FROM
  `v_order`
  WHERE
  ( `order_type` = N AND `pay_status` = N AND `status` = N )
  ORDER BY
  `v_order`.`id` ASC
  LIMIT N OFFSET N

Count: 1  Time=33.24s (33s)  Lock=0.00s (0s)  Rows=10.0 (10), root[root]@[139.180.128.226]
  SELECT
  id
  FROM
  `v_order`
  WHERE
  ( `order_type` = N AND `pay_status` = N AND `status` = N )
  ORDER BY
  `v_order`.`id` ASC
  LIMIT N OFFSET N



Count: 1  Time=31.66s (31s)  Lock=0.00s (0s)  Rows=20.0 (20), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select `users`.`nikename`, count(v_user_invite_history.id) as count from `v_user_invite_history` inner join `users` on `users`.`id` = `v_user_invite_history`.`owner_user_id` group by `owner_user_id` order by `count` desc, `users`.`id` asc limit N offset N

Count: 1  Time=26.85s (26s)  Lock=0.00s (0s)  Rows=3819042.0 (3819042), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_welfare_card`

Count: 11  Time=26.01s (286s)  Lock=0.00s (0s)  Rows=1.0 (11), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` left join `users` on `users`.`id` = `v_order`.`user_id`

Count: 1  Time=23.89s (23s)  Lock=0.00s (0s)  Rows=3680716.0 (3680716), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_operate`

Count: 1  Time=23.81s (23s)  Lock=0.00s (0s)  Rows=2971633.0 (2971633), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_order`

Count: 1  Time=22.15s (22s)  Lock=0.00s (0s)  Rows=3680710.0 (3680710), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_invite_code`

Count: 1  Time=21.78s (21s)  Lock=0.00s (0s)  Rows=3680706.0 (3680706), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `user_device`

Count: 2  Time=21.55s (43s)  Lock=0.00s (0s)  Rows=1.0 (2), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and (`price_current` > N)

Count: 5  Time=20.60s (103s)  Lock=0.00s (0s)  Rows=530.6 (2653), root[root]@[139.180.128.226]
  SELECT * FROM `video_douyin`.`v_order` WHERE `pay_type` = 'S' AND `order_type` = 'S' AND `vc_id` = 'S' LIMIT N,N

Count: 1  Time=20.19s (20s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE
  FROM
  v_order
  WHERE
  created_at < 'S'

Count: 2  Time=19.73s (39s)  Lock=0.00s (0s)  Rows=1.0 (2), root[root]@[139.180.128.226]
  SELECT count(*) FROM `video_douyin`.`v_order` WHERE `pay_type` = 'S' AND `order_type` = 'S' AND `vc_id` = 'S'

Count: 428  Time=18.01s (7707s)  Lock=0.00s (0s)  Rows=7.9 (3367), devops_hk2[devops_hk2]@[45.114.172.47]
  select * from `v_order` where (`order_type` = N and `pay_status` = N and `status` = N) order by `v_order`.`id` asc limit N offset N

root@a4733e9108c0:/var/lib/mysql# mysqldumpslow -s at -t 20 a4733e9108c0-slow.log

Reading mysql slow query log from a4733e9108c0-slow.log
Count: 1  Time=724.52s (724s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE FROM `v_order_history`

Count: 4  Time=372.50s (1489s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE
  FROM
  `video_douyin`.`v_order`
  WHERE
  `pay_type` = 'S'
  AND `order_type` = 'S'
  AND `vc_id` = 'S'
  LIMIT N



Count: 1  Time=55.47s (55s)  Lock=0.00s (0s)  Rows=3819061.0 (3819061), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_msg_queue`

Count: 1  Time=54.18s (54s)  Lock=0.00s (0s)  Rows=11086953.0 (11086953), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_video_appraise`

Count: 1  Time=48.26s (48s)  Lock=0.00s (0s)  Rows=3700709.0 (3700709), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `users`

Count: 14  Time=46.92s (656s)  Lock=0.00s (0s)  Rows=1.0 (14), 2users@2hosts
  select count(*) as aggregate from `users` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id` left join `v_user_invite_code` on `owner_user_id` = `users`.`id` left join `v_vip_card` on `v_vip_card`.`id` = `v_user_extend`.`vip_id` where `users`.`is_robot` = N

Count: 2  Time=45.01s (90s)  Lock=0.00s (0s)  Rows=13.0 (26), root[root]@[139.180.128.226]
  SELECT
  *
  FROM
  `v_order`
  WHERE
  ( `order_type` = N AND `pay_status` = N AND `status` = N )
  ORDER BY
  `v_order`.`id` ASC
  LIMIT N OFFSET N

Count: 1  Time=33.24s (33s)  Lock=0.00s (0s)  Rows=10.0 (10), root[root]@[139.180.128.226]
  SELECT
  id
  FROM
  `v_order`
  WHERE
  ( `order_type` = N AND `pay_status` = N AND `status` = N )
  ORDER BY
  `v_order`.`id` ASC
  LIMIT N OFFSET N

Count: 1  Time=31.66s (31s)  Lock=0.00s (0s)  Rows=20.0 (20), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select `users`.`nikename`, count(v_user_invite_history.id) as count from `v_user_invite_history` inner join `users` on `users`.`id` = `v_user_invite_history`.`owner_user_id` group by `owner_user_id` order by `count` desc, `users`.`id` asc limit N offset N

Count: 1  Time=26.85s (26s)  Lock=0.00s (0s)  Rows=3819042.0 (3819042), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_welfare_card`

Count: 11  Time=26.01s (286s)  Lock=0.00s (0s)  Rows=1.0 (11), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` left join `users` on `users`.`id` = `v_order`.`user_id`

Count: 1  Time=23.89s (23s)  Lock=0.00s (0s)  Rows=3680716.0 (3680716), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_operate`

Count: 1  Time=23.81s (23s)  Lock=0.00s (0s)  Rows=2971633.0 (2971633), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_order`

Count: 1  Time=22.15s (22s)  Lock=0.00s (0s)  Rows=3680710.0 (3680710), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `v_user_invite_code`

Count: 1  Time=21.78s (21s)  Lock=0.00s (0s)  Rows=3680706.0 (3680706), root[root]@[127.0.0.1]
  SELECT /*!N SQL_NO_CACHE */ * FROM `user_device`

Count: 2  Time=21.55s (43s)  Lock=0.00s (0s)  Rows=1.0 (2), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and (`price_current` > N)

Count: 5  Time=20.60s (103s)  Lock=0.00s (0s)  Rows=530.6 (2653), root[root]@[139.180.128.226]
  SELECT * FROM `video_douyin`.`v_order` WHERE `pay_type` = 'S' AND `order_type` = 'S' AND `vc_id` = 'S' LIMIT N,N

Count: 1  Time=20.19s (20s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE
  FROM
  v_order
  WHERE
  created_at < 'S'

Count: 2  Time=19.73s (39s)  Lock=0.00s (0s)  Rows=1.0 (2), root[root]@[139.180.128.226]
  SELECT count(*) FROM `video_douyin`.`v_order` WHERE `pay_type` = 'S' AND `order_type` = 'S' AND `vc_id` = 'S'

Count: 436  Time=17.89s (7801s)  Lock=0.00s (0s)  Rows=8.0 (3495), devops_hk2[devops_hk2]@[45.114.172.47]
  select * from `v_order` where (`order_type` = N and `pay_status` = N and `status` = N) order by `v_order`.`id` asc limit N offset N



[日期:2019-11-05]

Reading mysql slow query log from a4733e9108c0-slow.log
Count: 34  Time=1546.28s (52573s)  Lock=0.00s (0s)  Rows=0.9 (29), 2users@2hosts
  select count(*) as aggregate from `users` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id` left join `v_user_invite_code` on `owner_user_id` = `users`.`id` left join `v_vip_card` on `v_vip_card`.`id` = `v_user_extend`.`vip_id` where `users`.`is_robot` = N

Count: 1  Time=1028.19s (1028s)  Lock=182.11s (182s)  Rows=0.0 (0), devops_hk2[devops_hk2]@[45.114.172.47]
  update `v_user_extend` set `upload_daily` = N, `updated_at` = 'S' where `upload_review` = N

Count: 1  Time=724.52s (724s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE FROM `v_order_history`

Count: 1  Time=585.22s (585s)  Lock=0.00s (0s)  Rows=3819182.0 (3819182), root[root]@[139.180.128.226]
  SELECT * FROM `v_user_welfare_card`

Count: 2  Time=426.48s (852s)  Lock=0.00s (0s)  Rows=1.0 (2), root[root]@[139.180.128.226]
  SELECT
  count( users.id ) AS AGGREGATE
  FROM
  `users`
  LEFT JOIN `v_user_extend` ON `v_user_extend`.`user_id` = `users`.`id`
  LEFT JOIN `v_user_invite_code` ON `owner_user_id` = `users`.`id`
  LEFT JOIN `v_vip_card` ON `v_vip_card`.`id` = `v_user_extend`.`vip_id`
  WHERE
  users.id > N

Count: 4  Time=372.50s (1489s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  DELETE
  FROM
  `video_douyin`.`v_order`
  WHERE
  `pay_type` = 'S'
  AND `order_type` = 'S'
  AND `vc_id` = 'S'
  LIMIT N

Count: 1  Time=173.96s (173s)  Lock=0.00s (0s)  Rows=0.0 (0), root[root]@[139.180.128.226]
  SELECT
  count(users.id) AS AGGREGATE
  FROM
  `users`
  LEFT JOIN `v_user_extend` ON `v_user_extend`.`user_id` = `users`.`id`
  LEFT JOIN `v_user_invite_code` ON `owner_user_id` = `users`.`id`
  LEFT JOIN `v_vip_card` ON `v_vip_card`.`id` = `v_user_extend`.`vip_id`

Count: 1  Time=162.42s (162s)  Lock=0.00s (0s)  Rows=1.0 (1), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`created_at` > 'S' and `v_order`.`created_at` < 'S' and (`price_current` > N)

Count: 1  Time=149.45s (149s)  Lock=0.00s (0s)  Rows=1.0 (1), root[root]@[139.180.128.226]
  SELECT
  count(users.id) AS AGGREGATE
  FROM
  `users`
  LEFT JOIN `v_user_extend` ON `v_user_extend`.`user_id` = `users`.`id`
  LEFT JOIN `v_user_invite_code` ON `owner_user_id` = `users`.`id`
  LEFT JOIN `v_vip_card` ON `v_vip_card`.`id` = `v_user_extend`.`vip_id`
  WHERE is_robot = N

Count: 1  Time=135.82s (135s)  Lock=0.11s (0s)  Rows=1.0 (1), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_user_wallet` left join `users` on `users`.`id` = `v_user_wallet`.`user_id` left join `v_user_extend` on `v_user_extend`.`user_id` = `users`.`id`

Count: 1  Time=120.27s (120s)  Lock=0.00s (0s)  Rows=1.0 (1), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`price_current`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`created_at` > 'S' and `v_order`.`created_at` < 'S' and (`price_current` > N)

Count: 1  Time=118.67s (118s)  Lock=0.00s (0s)  Rows=1.0 (1), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`pay_price`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`created_at` > 'S' and `v_order`.`created_at` < 'S' and (`price_current` > N)

Count: 1  Time=116.59s (116s)  Lock=0.00s (0s)  Rows=10.0 (10), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select `v_order`.`id`, `order_no`, `order_type`, `vc_title`, `pay_type`, `v_order`.`pay_gateway`, `price_current`, `paid_at`, `v_order`.`created_at`, `v_order`.`pay_price`, `v_order`.`gateway_no` from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`created_at` > 'S' and `v_order`.`created_at` < 'S' and (`price_current` > N) order by `created_at` desc limit N offset N

Count: 31  Time=109.49s (3394s)  Lock=0.00s (0s)  Rows=10.0 (310), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select `v_order`.`id`, `order_no`, `order_type`, `vc_title`, `pay_type`, `v_order`.`pay_gateway`, `price_current`, `paid_at`, `v_order`.`created_at`, `v_order`.`pay_price`, `v_order`.`gateway_no` from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`paid_at` > 'S' and `v_order`.`paid_at` < 'S' and (`price_current` > N) order by `created_at` desc limit N offset N

Count: 32  Time=107.54s (3441s)  Lock=0.00s (0s)  Rows=1.0 (31), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`price_current`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`paid_at` > 'S' and `v_order`.`paid_at` < 'S' and (`price_current` > N)

Count: 31  Time=105.11s (3258s)  Lock=0.00s (0s)  Rows=0.9 (29), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`pay_price`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`paid_at` > 'S' and `v_order`.`paid_at` < 'S' and (`price_current` > N)

Count: 31  Time=103.40s (3205s)  Lock=0.00s (0s)  Rows=1.0 (31), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select count(*) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and `v_order`.`paid_at` > 'S' and `v_order`.`paid_at` < 'S' and (`price_current` > N)

Count: 19  Time=99.95s (1899s)  Lock=0.00s (0s)  Rows=0.9 (18), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`pay_price`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and (`price_current` > N)

Count: 19  Time=97.87s (1859s)  Lock=0.00s (0s)  Rows=0.9 (18), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select sum(`price_current`) as aggregate from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and (`price_current` > N)

Count: 20  Time=95.14s (1902s)  Lock=0.00s (0s)  Rows=9.5 (190), devops_douyin_180[devops_douyin_180]@[154.206.46.180]
  select `v_order`.`id`, `order_no`, `order_type`, `vc_title`, `pay_type`, `v_order`.`pay_gateway`, `price_current`, `paid_at`, `v_order`.`created_at`, `v_order`.`pay_price`, `v_order`.`gateway_no` from `v_order` where `v_order`.`pay_status` = N and `v_order`.`order_type` = N and (`price_current` > N) order by `created_at` desc limit N offset N