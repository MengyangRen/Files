抖音管理后台优化-数据库

修订者 : 幕洋 , 日期 : 2019/10/23

##1 概述
 >抖音用户量300W，数据总量3G左右
 >现阶段大表（大于100M）共计10表
 
##2 大表列表
|     表  |      数据长度|  行数 |   引擎     | 行格式      |  索引长度                 |
| --------|:------------ |:------|:-----------|:------------|:--------------------------|
| user_device |   254M   |  373W   |  InnoDB     |   DYNAMIC    | 577.78 MB/可用空间4.00 MB |
| users       |   900M   |  378w   |  InnoDB     |   DYNAMIC    | 467.44 MB/可用空间5.00 MB |
| v_order     |   587M    | 290W   |  InnoDB    |   DYNAMIC   | 279.78 MB/可用空间7.00 MB |
| v_user_extend |   558M   | 358W  |  InnoDB   |   DYNAMIC  | 489.58MB/可用空间5.00 MB |
| v_user_invite_code |   172M   | 367W  |  InnoDB   |   DYNAMIC    | 172 MB/可用空间4.00 MB |
| v_user_msg_queue |   640M   | 345W  |  InnoDB   |   DYNAMIC    | 99 MB/可用空间4.00 MB |
| v_user_operate   |   208.73M   | 375W  |  InnoDB   |   DYNAMIC    | 42 MB/可用空间4.00 MB |
| v_user_welfare_card | 160.67 MB | 385W  |  InnoDB | DYNAMIC   | 206.81 MB/可用空间4.00 MB |
|v_video_appraise| 440.92 MB| 1079W  |  InnoDB | DYNAMIC   | 324.00 MB/可用空间4.00 MB |


##3 统计抖音数据库索引+数据总大小

```Sql
 
#查询所有的表大小语句


select table_name,table_rows,data_length+index_length,
concat(round((data_length+index_length)/1024/1024,2),'MB') 
data from tables where table_schema='video_douyin';

#查询某个表
and table_name='表名';

#计算单表每天日增长量

结合sh脚本统计


```
##4 一个字段是否有必要选择建立索引

```Sql

SELECT count(DISTINCT(invite_count))/count(*) AS `选择性` FROM v_user_extend;
SELECT count(DISTINCT(concat(channel,from)))/count(*) AS Selectivity FROM v_user_extend;
1.(精确值为0.00001579）
2.如果不足0.0001的时候,就没必要选择构建索引

```

##5 数据导出，导入

```Sql

doyin
mysqldump -h127.0.0.1 -uroot -P3306 -pCniGhB97oogEzsi9eRs7RGT7mMXcqagQ video_douyin  >/var/lib/mysql/backup/video_douyin.sql
asy
mysqldump -h127.0.0.1 -uroot -P3306 -pCniGhB97oogEzsi9eRs7RGT7mMXcqagQ asiyu  >/var/lib/mysql/backup/asiyu.sql

 1.mysqldump -h127.0.0.1 -uroot -P3306 -pCniGhB97oogEzsi9eRs7RGT7mMXcqagQ video_douyin users >/var/lib/mysql/backup/users.sql

 2.打包压缩 tar -czf  doyin-2019.10.23.tar.gz  video_douyin.sql
 tar -zxvf  use67.tar.gz  -C ./users.sql



mysql -h127.0.0.1 -uroot -P3306 -pxinshengli666 video_douyin_oa < /var/lib/mysql/backup/video_douyin.sql
mysql -h127.0.0.1 -uroot -P3306 -pxinshengli666 video_douyin_oa < /var/lib/mysql/backup/users.sql



```



##6 索引建构记录

```Sql

v_user_extend
SELECT count(DISTINCT(invite_count))/count(*) AS `选择性` FROM v_user_extend;
0.1
invite_count 建立b树索引
ALTER TABLE `v_user_extend` ADD INDEX idx_ic( `invite_count` );  
耗时：5分钟左右



v_user_invite_history
SELECT count(DISTINCT(owner_user_id))/count(*) AS `选择性` FROM v_user_invite_history;
0.1740
ALTER TABLE `v_user_invite_history` ADD INDEX idx_oui( `owner_user_id` );
耗时：3分钟左右


v_order
SELECT count(DISTINCT(concat(order_type,pay_status,status)))/count(*) AS Selectivity FROM v_order;
SELECT count(DISTINCT(concat(order_type,pay_status,status,device_type)))/count(*) AS Selectivity FROM v_order;
SELECT count(DISTINCT(concat(user_id)))/count(*) AS Selectivity FROM v_order;


ALTER TABLE `v_order` ADD INDEX idx_uid ( `user_id`);
ALTER TABLE `v_order` ADD INDEX idx_ops ( `order_type`, `pay_status`, `status` );
耗时：1分钟左右
ALTER TABLE `v_order` ADD INDEX idx_opsd ( `order_type`, `pay_status`, `status`,`device_type`);
耗时: 1分钟左右

v_video_appraise 

ALTER TABLE `v_video_appraise` ADD INDEX idx_vid ( `video_id`);
ALTER TABLE `v_video_appraise` ADD INDEX idx_created_at ( `created_at`);


#解决的问题是 Using filesort

v_video_comment
ALTER TABLE `v_video_comment` ADD INDEX idx_pid ( `parent_id`);
ALTER TABLE `v_video_comment` ADD INDEX idx_created_at ( `created_at`);




v_topic_content
select count(*) as aggregate from `v_topic_content` where (`is_recommend` = ? and `check` = ?) and `v_topic_content`.`deleted_at` is null
ALTER TABLE `v_topic_content` ADD INDEX idx_ic ( `is_recommend`,`check`);


v_video
ALTER TABLE `v_video` ADD INDEX idx_created_at ( `created_at`);





```

### 语句优化记录 

```SQL

语句1 （平均150ms=>0.03ms）
select count(*) as aggregate from `v_user_extend` where `invite_count` > 0
select sum(`invite_count`) as aggregate from `v_user_extend` where `invite_count` > 0


语句2(120ms=>0.25ms)
SELECT
	* 
FROM
	users
	LEFT JOIN `v_user_extend` ON `v_user_extend`.`user_id` = `users`.`id`
	LEFT JOIN `v_user_invite_code` ON `owner_user_id` = `users`.`id`
	LEFT JOIN `v_vip_card` ON `v_vip_card`.`id` = `v_user_extend`.`vip_id` 
WHERE
	`users`.`is_robot` = 0 
	AND `nikename` = '飞流'

语句3（299.45ms ->0.15ms）
DESC SELECT
	`owner_user_id`,
	`name`,
	`nikename`,
	`code`,
	`v_user_invite_history`.`created_at` 
FROM
	`v_user_invite_history`
	LEFT JOIN `users` ON `users`.`id` = `v_user_invite_history`.`use_user_id` 
WHERE
	`v_user_invite_history`.`owner_user_id` IN (
	13);


语句4 （11176.71ms ->0.003ms ）
SELECT
	count(*) AS AGGREGATE 
FROM
	`users`
	LEFT JOIN `v_user_extend` ON `v_user_extend`.`user_id` = `users`.`id`
	LEFT JOIN `v_user_invite_code` ON `owner_user_id` = `users`.`id`
	LEFT JOIN `v_vip_card` ON `v_vip_card`.`id` = `v_user_extend`.`vip_id` 
WHERE
	`users`.`is_robot` = 0
	AND `v_user_invite_code`.`code`= "90SZU"

语句5 （121734.21ms->0.014ms）
  SELECT
  *
  FROM
  `v_order`
  WHERE
  ( `order_type` = N AND `pay_status` = N AND `status` = N )
  ORDER BY
  `v_order`.`id` ASC
  LIMIT N OFFSET N

```


## 备注
```Sql

完成
1.用户管理    (20s-40s) (3s内)
2.订单管理   （20s-30s)
3，财务管理    (20s-30s)



Vendor 代码修改
vendor/laravel/framework/src/Illuminate/Database/Eloquent/Builder.php

   public function paginate($perPage = null, $columns = ['*'], $pageName = 'page', $page = null,$total = null)
    {

        $page = $page ?: Paginator::resolveCurrentPage($pageName);
        $perPage = $perPage ?: $this->model->getPerPage();

        // for muyang
        $total = $total ?: $this->toBase()->getCountForPagination();

        // $results = ($total = $this->toBase()->getCountForPagination())
        //                             ? $this->forPage($page, $perPage)->get($columns)
        //                             : $this->model->newCollection();
        //                             
        //                             
        $results = ($total)? $this->forPage($page, $perPage)->get($columns) : $this->model->newCollection();
                                    
        return $this->paginator($results, $total, $perPage, $page, [
            'path' => Paginator::resolveCurrentPath(),
            'pageName' => $pageName,
        ]);
    }

```



