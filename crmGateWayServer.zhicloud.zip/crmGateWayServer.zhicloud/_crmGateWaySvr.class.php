<?php
//namespace CrmServer;
//
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   CRM双向通讯网关服务
 *  
 * @author    v.r
 * @package   crmServer
 * @copyright copyright http://my.oschina.net/u/1246814
 * @version  1.0.0
 *
 *
 *  
 *  1.客户端请求协议
 *
 * ---------------------------------------------------------------------
 *  登陆协议
 *  {"type":"login","origin":"hlhx","qiniu_path":"","time":"1525681260"}
 *
 *  合作商新用户 
 *  {"type":"new-custom","origin":"hlhx","qiniu_path":"hlj/hx/2018/05/07/20180507162149.zip","time":"1525681280"}
 * -------------------------------------------------------------------------------------
 *  
 *
 * 
 * 2.
 * 服务端主动询问客服端用户服务费交付 请求协议
 * {judy_type(q)e":"custom-cover-charge","origin":"zhicloud","qiniu_path":"/e223/343434/","time":"234234234212312"}
 *
 * 客户端响应服务费协议
 * {"type":"custom-cover-charge","origin":"xjhx","qiniu_path":"/空间","time":"2423424"}
 * 
 */

if(!defined('CRM_LIB_PATH'))
    define('CRM_LIB_PATH', dirname(__FILE__));

date_default_timezone_set('Asia/Shanghai');
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'config.class.php';
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'util'.DIRECTORY_SEPARATOR.'util.class.php';
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Factory.class.php';
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Events.class.php';
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Worker.class.php';
require_once CRM_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Server.class.php';
//CRM服务启动
$CrmGateWayServer = new CrmGateWayServer(SER_IP,SER_PORT);
$CrmGateWayServer->run();