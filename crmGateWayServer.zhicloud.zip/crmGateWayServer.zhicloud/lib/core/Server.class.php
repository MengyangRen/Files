<?php
class CrmGateWayServer {
    
    private   $serivce;
    private   $worker;
    public    $hashTable;
    public    $setting;
    public    $host;
    protected $port = 9701;
    protected $listen;
    protected $mode = SWOOLE_PROCESS;
    public    $processName = 'swoole-crm-gateway-srv';

    private $preSysCmd = '%+-swoole%+-';
    private $requireFile = '';
    
    public function __construct($ip = NULL ,$port = NULL) {
        if (!empty($ip) && !empty($port)) {
            $this->host = $ip;
            $this->port = $port;
        } 
    }
    
    public function run() {
        
        $this->serivce = new \swoole_server($this->host, $this->port);
        $this->serivce->set(SERVER_CONFIG::$set);
        $this->serivce->on('Start',array($this,'onMasterStart'));
        $this->serivce->on('ManagerStart', array($this, 'onManagerStart')); 
        $this->serivce->on('WorkerStart', array($this, 'onWorkerStart'));  
        $this->serivce->on('Shutdown',array($this,'onShutdown'));
        $this->serivce->on("Connect",array($this,'onConnect'));       
        $this->serivce->on("Receive",array($this,'onReceive'));      
        $this->serivce->on("Close",array($this,'onClose'));        
        $this->serivce->on("Task",array($this,'onTask'));     
        $this->serivce->on("Finish",array($this,'onFinish')); 
        $this->serivce->start();
        
    }

    public function start() {
        Util::_writelog($this->processName . ": start\033[32;40m [OK] \033[0m");
        $this->serivce->start();
    }


    /**
     * 
     * 主进程服务启动 
     * @return mixed $data default array, 
     * else Exception 
     */
    public function onMasterStart($srv = NULL) {
      print '_______CRM服务启动______'.PHP_EOL;
      Events::monitorChannel($srv);
    }

    /**
     * 管理进程启动 
     * @return mixed $data default array, 
     * else Exception 
     */
    public function onManagerStart() {
        print '管理进程开启'.PHP_EOL;
    }

    /**
     * 工作进程启动 
     * @return mixed $data default array, 
     * else Exception 
     */
    public function onWorkerStart($srv, $workerId) {
        Events::onWorkerStart($srv,$workerId);
    }

    /**
     * 客户端连接 
     * @return mixed $data default array, 
     * else Exception 
     */
    public function onConnect($srv, $fd, $from_id){
        Events::onConnect($srv,$fd,$from_id);
    }

    /**
     * 接受消息
     * @param  obj $srv      swoole对象
     * @param  resource $fd  客户端连接
     * @param  int  $from_id 不同进程的id(workerid)
     * @param  string  $data 数据
     * @return string
     *
     */
    public function onReceive($srv, $fd, $from_id, $data) {
        Events::onMessage($srv, $fd, $from_id, $data);
    }

    /**
     * 任务 
     * @return mixed $data default array,
     *  else Exception 
     */
    public function onTask($srv, $task_id, $from_id, $data) {
        Events::onTask($srv, $task_id, $from_id, $data);
    }

    /**
     * 汇总 

     * @return mixed $data default array, 
     * else Exception 
     */
    public function onFinish($srv, $task_id, $data) {
        Events::onFinish($srv, $task_id, $data);
    }


    /**
     * 连接关闭 
     * @return mixed $data default array,
     *  else Exception 
     */
    public function onClose($srv, $fd, $reactorId){
        Events::onClose($srv, $fd, $reactorId);
    }


    /**
     * 服务关闭 
     * @return mixed $data default array,
     *  else Exception 
     */
    public function onShutdown(){
        print '任务服务关闭成功'.PHP_EOL;
    }

    //停止服务
    public function shutdown() {
        print "服务停止..".PHP_EOL;
    }
}