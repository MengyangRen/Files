<?php
class Worker
{


    public static $hzsPool = array();

    /**
     * checkType
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function checkType($type = NULL) {
        if (!in_array(
            $type, 
            array_values(SERVER_CONFIG::$types)
            ))
           throw new \Exception("Protocol type error", 1024);
        return $type;
    }


    /**
     * login
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function login($srv = NULL ,$message = NULL,$fd = NULL) {
        $origin = $message['origin'];
        Worker::$hzsPool[$origin][$fd] = $srv;
    }

    /**
     * 
     * publishToChannel
     * 
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function pub($json_protocol = NULL) {
        try {
            $redis = new Redis();
            $res = $redis->connect(CHANNEL_SERVER_IP,CHANNEL_SERVER_PORT);
            $res = $redis->publish(CRM_0LTN,$json_protocol);
            $redis->close();
        } catch (\Exception $e) {
            throw new \Exception("Error Processing Request", 1);
        }
    }

    /**
     * 
     * sendHandler
     * 
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function sendHandler($m,$srv) {
        $org = Util::jsonDecode($m)['origin'];
        if (empty(Worker::$hzsPool[$org]))
            return ;
        $pools = Worker::$hzsPool[$org];
        foreach ($pools as $fd=>$pool) {
            $srv->send($fd,$m);
        }
    }
}