<?php
class Events
{

    
    /**
     * onWorkerStart
     * @param string $ip
     * @param int $port
     * @return void
     */
    public static function onWorkerStart($srv, $worker_id) {
        return ;
    }

    /**
     * monitorChannel
     * 
     * @param string $ip
     * @param int $port
     * @return void
     */
    public static function monitorChannel($srv = NULL) {
        //链接redis
        $redis_client = new \swoole_redis;

        //通道
        $redis_client->on('message', function (swoole_redis $client, $result) use($srv) {
            if ($result[0] == 'message')
                Worker::controllerHandler($result[2],$srv);
        });

        $redis_client->connect(
            CHANNEL_SERVER_IP,
            CHANNEL_SERVER_PORT, 
            function (swoole_redis $client, $result) {
                $client->subscribe(CRM_2LTN);
            }
        );
    } 

    /**
     * onMessage
     * 
     * @param string serv
     * @param int    fd
     * @param int    from_id
     * @param json   data
     * @return void
     * 
     */
    public static function onMessage($srv, $fd, $from_id, $message)
    {

        if (Util::jsonDecode($message)['type'] == 'ping') {       
            $srv->send(
                $fd,
                Util::jsonEncode(array(
                    'type'=>'pong'
                ))
            );
            return true;
        } else {
            print "---------------------------------------".PHP_EOL;
            print "[Sokcet]:\033[32;40m [".$fd."] \033[0m".PHP_EOL;
            print "[协议]:".$message.PHP_EOL;
            print "[时间]:".date("Y-m-d H:i:s",time()).PHP_EOL;
            print "---------------------------------------".PHP_EOL;
        }
        
        try { 

            if (!empty(Util::isJson(trim($message)))) 
                throw new \Exception("Illegal protocol access", 1034);

            $_fuc = Worker::checkType(
                Util::jsonDecode($message)['type']
                );
    

            if ('login' == $_fuc) {
                Worker::login(
                    $srv,
                    Util::jsonDecode($message),
                    $fd
                );
            } else {
                Worker::pub($message);
            }

            $srv->send(
                $fd,
                Util::__makeResponseJsonProtocol().PHP_EOL
            );

        } catch (\Exception $e) {
            $srv->send(
                $fd,
                Util::__makeResponseJsonProtocol($e->getCode(),$e->getMessage()).PHP_EOL
            );
            $srv->close($fd); //踢掉用户
        }

    }

    /**
     * onConnect
     * @param string $serv
     * @param int $fd
     * @return void
     */
    public static function onConnect($srv, $fd, $from_id) {
        $msg =  "server: {$fd} 客户端连接成功.\n";
        print $msg;
        $srv->send($fd,$msg);
    }


    /**
     * onClose
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onClose($srv, $fd) {
        //清楚资源
        $pools = Worker::$hzsPool;
        foreach ($pools as $pool) {
            if (!empty($pool[$fd])) {
                 unset($pool[$fd]);
            }
        }
    }


    /**
     * onTask
     * 
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onTask($srv, $task_id, $from_id, $data) {
        return ;
    }

    /**
     * onFinish
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onFinish($srv, $task_id, $data) {
        return ;
    }

}