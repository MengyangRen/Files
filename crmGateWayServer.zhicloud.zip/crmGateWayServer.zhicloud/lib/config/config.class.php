
<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *  配置项
 * @author v.r
 * @package         配置项
 * @subpackage      config.class.php
 */


define('CRM_0LTN','crm_0ltn');  // sub
define('CRM_2LTN','crm_2ltn');  // pub
define('SER_IP','0.0.0.0');
define('SER_PORT',4503);
define('CHANNEL_SERVER_IP','127.0.0.1');
define('CHANNEL_SERVER_PORT',6379);


class SERVER_CONFIG 
{   
    /**
     * swoole 配置设置
     * @var array
     */
    public static $set = array(
        //'reactor_num'              => 16,     // 线程数. 一般设置为CPU核数的1-4倍
        'worker_num'               => 2,    // 工作进程数量. 设置为CPU的1-4倍最合理
        'max_request'              => 1000,     // 防止 PHP 内存溢出, 一个工作进程处理 X 次任务后自动重启 (注: 0,不自动重启)

        //'max_conn'                 => 10000, // 最大连接数
        //'task_worker_num'          => 1,     // 任务工作进程数量
        //'task_ipc_mode'            => 2,     //设置task进程与worker进程之间通信的方式1unix socket、2消息队列、3消息队列通信，并设置为争抢模式
        //'task_max_request'         => 0,     // 防止 PHP 内存溢出
        
        'dispatch_mode'            => 2,
        'daemonize'                => false,     // 设置守护进程模式
        'backlog'                  => 128,

        //'heartbeat_check_interval' => 10,    // 心跳检测间隔时长(秒)
        //'heartbeat_idle_time'      => 20,   // 连接最大允许空闲的时间
        //'package_eof' => "\r\n",
        //'open_eof_check' => true,
        //'open_eof_split' => true,
        //'package_max_length' => 1024 * 1024 * 1, //1M*/
        //'open_eof_check'           => 1,
        //'open_eof_split'           => 1,
        //'package_eof'              => "\r\r\n",
        //'open_cpu_affinity'        => 1,
        //'socket_buffer_size'    => 1024 * 1024 * 128,
        //'buffer_output_size'    => 1024 * 1024 * 2,
        //'enable_delay_receive'  => true,
        //'cpu_affinity_ignore'   =>array(0,1)//如果你的网卡2个队列（或者没有多队列那么默认是cpu0来处理中断）,并且绑定了core 0和core 1,那么可以通过这个设置避免swoole的线程或者进程绑定到这2个core，防止cpu0，1被耗光而造成的丢包


        //'task_tmpdir'           =>'/tmp/task_data', //task数据临时存放目录
        
        'log_file'              =>'/tmp/swoole-crm-gateway/swoole.log',   //swoole错误日志存放路径
        'master_pid'            =>'/tmp/swoole-crm-gateway/master_pid.log',      //master进程号
        'manager_pid'           =>'/tmp/swoole-crm-gateway/manager_pid.log'         //管理进程*/
    ); 



  /**
   * 协议类型配置
   * @var array
   */
  public static $types = array(
      '10011'=>'login',
      '20022'=>'new-custom',
      '30033'=>'update-custom',
      '40044'=>'init-custom-src',
  );
  
}