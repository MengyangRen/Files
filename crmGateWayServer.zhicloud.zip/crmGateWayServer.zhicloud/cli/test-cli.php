<?php
define('SER_IP','127.0.0.1');
define('SER_PROT',4503);
class EchoClient {
    protected $client = null;

    public function __construct() {
        //注意这里需设置为异步，不然下面无法设置事件回调函数
        $this->client = new swoole_client(SWOOLE_SOCK_TCP, SWOOLE_SOCK_ASYNC);
        $this->client->on('connect', array($this, 'connect'));
        $this->client->on('receive', array($this, 'receive'));
        $this->client->on('close', array($this, 'close'));
        $this->client->on('error', array($this, 'error'));
        //连接服务端
        $this->client->connect(SER_IP,SER_PROT);

    }

    public function connect($client) {
        echo "connect \n";
    }

    public function receive($client, $data) {
        echo "server send: {$data}";

        //向标准输出写入数据
        fwrite(STDOUT, "请输入消息：");
        //获取标准输入数据
        $msg = trim(fgets(STDIN));
        //向服务端发送数据
        $client->send($msg);
    }

    public function close($client) {
        echo "close \n";
    }

    public function error($client) {
        echo "error \n";
    }
}

$cli = new EchoClient();