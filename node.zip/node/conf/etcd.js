{
    "Endpoints":[
        "http://103.87.8.176:2379"
    ],
    "Username":"root",
    "Password":"admin1314",
    "#DialTimeout":"单位秒",
    "DialTimeout": 2
}