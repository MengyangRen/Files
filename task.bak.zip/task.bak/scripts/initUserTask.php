<?php

/** 
*  @author  vincent.ren
*  @example file/path.php description 
*/
define( 'ROOT', dirname ( dirname ( __FILE__ ) ) );
require_once (ROOT . '/../cola/core/colaapp.php');
require_once (ROOT . '/app/config/bootstrap.cli.php');
loadCola();
$TaskWebhookService = loadService('TaskInitUserService',true);
if(!empty($argv[1])){
    //获取需要跑的总数
    if($argv[1]=='getnum'){
        $total=$TaskWebhookService->getJobsNum();
        echo $total;
        exit;
    }elseif(is_numeric($argv[1])){
        error_reporting(0);
        $TaskWebhookService->init($argv[1],$argv[2]);
        $TaskWebhookService->run();
    }
}