<?php
/** 
*  从db消息队列中取出放入redis队列中
*  @author  vincent.ren
*  @example file/path.php description 
*/

error_reporting(0);
exec('ps -ef | grep ' . basename(__FILE__) . ' | grep -v grep | grep -v sh', $out); // cron will have 'sh -c'
if( count($out) > 1 ) exit;  

define ( 'ROOT', dirname ( dirname ( __FILE__ ) ) );
require_once (ROOT . '/../cola/core/colaapp.php');
require_once (ROOT . '/app/config/bootstrap.cli.php');
loadCola();

$TaskPushAppService = loadService('TaskPushAppService',true);
$TaskPushAppService->start();
