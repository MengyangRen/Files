<?php

/** 
*  平台的消息写入数据库队列
*  @author  vincent.ren
*  @example file/path.php description 
*/

error_reporting(0);
exec('ps -ef | grep ' . basename(__FILE__) . ' | grep -v grep | grep -v sh', $out); // cron will have 'sh -c'
if( count($out) > 1 ) exit;  

define('ROOT', dirname(dirname(__FILE__)));
require_once(ROOT . '/../cola/core/colaapp.php');
require_once (ROOT . '/app/config/bootstrap.cli.php');

loadCola();
$TaskPutMqFromZcService = loadService('TaskPutMqFromZcService', true);
$TaskPutMqFromZcService->start();