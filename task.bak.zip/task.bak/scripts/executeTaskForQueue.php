<?php
/**
 *  执行来自redis队列的任务
 *  @author  vincent.ren
 *  @example file/path.php description 
 */
error_reporting(0);
exec('ps -ef | grep ' . basename(__FILE__) . ' | grep -v grep | grep -v sh', $out); // cron will have 'sh -c'
if( count($out) > 1 ) exit;  

define( 'ROOT', dirname ( dirname ( __FILE__ ) ) );
require_once (ROOT . '/../cola/core/colaapp.php');
require_once (ROOT . '/app/config/bootstrap.cli.php');
loadCola();
$TaskAssistMessageService = loadService('TaskAssistMessageService',true);
$TaskAssistMessageService->executeTaskForQueue();