#!/bin/sh
basepath=$(cd `dirname $0`; pwd)
#每次多少条
per_page_num=50
param='getnum'
#total=`/usr/bin/php5 ${basepath}/../task/scripts/initCompanyLogo.php ${param}`
total=2000
echo 'TotalNum:'${total}
if ((${total}>0));then
    page=`echo "sclae=2; $total/$per_page_num" | bc`
    total_page=`echo $page | awk '{print int($0)+1}'`
    echo 'TotalPage:'${total_page}
    for (( i = 1; i <= $total_page;i=(i+1))); do
    {
        count=`ps -ef |grep "initCompanyLogo.php ${i} ${per_page_num}" |grep -v grep |wc -l`
        if (($count>0));then
            echo "initCompanyLogo.php ${i} ${per_page_num}"' is Running...'
        else
            #执行初始化公司头像
            /usr/bin/php5 ${basepath}/../task/scripts/initCompanyLogo.php ${i} ${per_page_num}
        fi
    } &
    done
    exit 0
fi
exit 0