#!/bin/sh
basepath=$(cd `dirname $0`; pwd)
#每次多少条
per_page_num=500
param='getnum'
for (( i = 0; i < 60;i=(i+1))); do  
    total=`/usr/bin/php ${basepath}/../task/scripts/initUserTask.php ${param}`
    echo 'Total:'${total}
    if ((${total}>0));then
        page=`echo "sclae=2; $total/$per_page_num" | bc`
        total_page=`echo $page | awk '{print int($0)+1}'`
        for (( i = 1; i <= $total_page;i=(i+1))); do
        {
            count=`ps -ef |grep "initUserTask.php ${i} ${per_page_num}" |grep -v grep |wc -l`
            if ((${count}>0));then
                echo "initUserTask.php ${i} ${per_page_num}"' is Running...'
            else
                #执行初始化用户数据
                /usr/bin/php ${basepath}/../task/scripts/initUserTask.php ${i} ${per_page_num}
            fi
        } &
        done
        exit 0
    fi
    sleep 1
done
exit 0