# @Author: xurui
# @Date:   2018-04-17 11:08:01
# @Last Modified by:   xurui
# @Last Modified time: 2018-05-08 13:01:24

#!/bin/sh

for (( i = 0; i < 60;i=(i+1))); do  

    #创建发送消息存储表
    $(/usr/bin/php '/application/_cloudTask_/task/scripts/executeTaskForQueue.php')
    #消息定时发送任务
    $(/usr/bin/php '/application/_cloudTask_/task/scripts/updateTimingMessageStatus.php')
    #过期消息导出任务
    # $(/usr/bin/php '/application/_cloudTask_/task/scripts/exportExpireMessageToDisk.php')
    #将过期消息存入七牛且修改库
    # $(/usr/bin/php '/application/_cloudTask_/task/scripts/uploadMessageFileToQiNiu.php')
    ###
    #
    sleep 1
    echo $i


done  
exit 0  