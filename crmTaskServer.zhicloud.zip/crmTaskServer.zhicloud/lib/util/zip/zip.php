<?php
include_once "./src/Comodojo/Zip/ZipBase.php";
include_once "./src/Comodojo/Zip/Zip.php";
include_once "./src/Comodojo/Zip/ZipManager.php";
include_once "./src/Comodojo/Zip/ManagerTools.php";
include_once "./src/Comodojo/Zip/StatusCodes.php";


$zip = \Comodojo\Zip\Zip::open('20180507162149.zip');

var_dump($zip);
