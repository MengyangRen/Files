<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *  任务 -多进程任务工具库 
 * @author v.r
 * @package         
 * @subpackage      lib.util.protocol.class.php
 */ 

class Util{
    /**
     * [自动加载类]
     * @return [type] [description]
     * 
     */
    public static function _loadOfClassPhp($class) {
        
        if (false !== stripos($class, 'Task')) {            
            $file = CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'task'.DIRECTORY_SEPARATOR.$class.'.class.php';
         
            if (is_file($file)) { 
                 require_once $file;
            } else {
                Util::_writeLog("解析类（{$class}）__task__文件不存在"); 
                exit;
            }
        }
        
        if (false !== stripos($class, 'Controller')) {            
            $file = CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'controller'.DIRECTORY_SEPARATOR.$class.'.class.php';
            if (is_file($file)) { 
                require_once $file;
            } else {
                Util::_writeLog("解析类（{$class}）__controller__文件不存在"); 
                exit;
            }
        }

        if (false !== stripos($class, 'Component')) {            
            $file = CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'component'.DIRECTORY_SEPARATOR.$class.'.class.php';
            if (is_file($file)) { 
                require_once $file;
            } else {
                Util::_writeLog("解析类（{$class}）__component__文件不存在"); 
                exit;
            }
        }
    }
    public static function makeRandomValue($bit = 8){
        if ($bit < 6) $bit = 6; 
        $string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
        $salt = '';
        for ($i = 0; $i < $bit; $i++) {
            $salt .= substr($string, mt_rand(0,61), 1);
        }
        return $salt;
    } 

    /**
     * [makeJsonToArray json换行为数组 递归]
     * @param  [type] $json [description]
     * @return [type]       [description]
     */
    public static function makeObjToArray($json){
        $json = is_object($json) ? get_object_vars($json):$json;
        $arr = array();
        $val = '';
        foreach ($json as $key => $value) {
              if (is_array($value)|| is_string($value)) {
                  $val = $value;
              } else {
                 if(is_object($value)) {
                    $val = self::makeObjToArray($value);
                 }
              }
              $arr[$key] = $val;
        }
        $json = null;
        return $arr;
    }

    /**
     * 
     *  格式化时间
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     *
     */
    public static function formatChargeDate($charge_end_date = NULL) {
        $charge_time = '';

        preg_match_all("/\d{4}\/\d+\/\d+/s",$charge_end_date,$arr);
        if (!empty($arr[0][0])) {
            $charge_time = strtotime($arr[0][0]);
            $charge_time = date('Y/m/d H:i:s',$param['charge_end_date']);
        }

        if (!empty($charge_end_date)) //服务费到期时间 charge_end_date
            $data['ServiceChargeExpireTime'] = strtotime($param['charge_end_date']);
   
    }

    public static function getRemoteZip($url,$path) {
       // set_time_limit(0);  
        $hostfile = fopen($url, 'r');  
        $fh = fopen($path, 'w');
        while (!feof($hostfile)) {  
        $output = fread($hostfile, 8192);  
            fwrite($fh, $output);  
        }  
        fclose($hostfile);  
        fclose($fh);  
    } 

    /**
     * 
     *  通过七牛获取数据并解压
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     *
     * 
     * <ROW>
         <cust_name>哈尔滨天资商贸有限公司</cust_name>
         <CUST_TAX_CODE>9123010357805761XW</CUST_TAX_CODE>
         <ACCOUNT_BANK></ACCOUNT_BANK>       发票银行
         <BANK_ACCOUNT></BANK_ACCOUNT>       银行账号
         <CUST_SCALE>一般纳税人</CUST_SCALE> 公司类型
         <INDUSTRY_NAME>其他行业</INDUSTRY_NAME> 所属行业
         <CONTACT>李安邦</CONTACT> 联系人
         <TEL>045158956008</TEL>   座机
         <MOBILE></MOBILE>         手机号
         <TAX_AUTHORITY_CODE>123010000</TAX_AUTHORITY_CODE> 税局编号
         <TAX_AUTHORITY_NAME>黑龙江省哈尔滨市国家税务局</TAX_AUTHORITY_NAME> 税局名称
         <CHARGE_END_DATE>2017-12-31T00:00:00</CHARGE_END_DATE>  服务费到期时间
         <EMAIL></EMAIL> 邮件
         <BUSINESS_SCOPE></BUSINESS_SCOPE>
         <LEGAL_PERSON>郭文友</LEGAL_PERSON> 法人
         <REGISTERED_FUND>0</REGISTERED_FUND> 
         <REGISTER_DATE>2011-09-29T00:00:00</REGISTER_DATE> //注册时间
         <UPDATE_DATE>2018-03-19T00:00:00</UPDATE_DATE> //更新时间
         <BILLING_MACHINE_NO>0</BILLING_MACHINE_NO>  //分机号
         <SUBSTATION_ID>1611</SUBSTATION_ID>
         <ENTERPRICE_TYPE_NAME>有限责任公司</ENTERPRICE_TYPE_NAME>
         <ENTERPRISE_SCALE>0</ENTERPRISE_SCALE>
         <ADDR>哈尔滨市南岗区鞍山街120号</ADDR>
         <BRANCH_OFFICE>哈尔滨市南岗区国家税务局</BRANCH_OFFICE>
     </ROW>
     * 
     */
    public static function getZipDataForQiniu($url = NULL) {
        try {   

            
            $xmlData = array();
          /*  $arr = array_reverse(explode('/', $url));
            $zip_tmp_path = ZIP_TEMP_PATH.$arr[0];
            Util::getRemoteZip($url,$arr);*/
            $zip = file_get_contents($url);
            $arr = array_reverse(explode('/', $url));
            $zip_tmp_path = ZIP_TEMP_PATH.$arr[0];
            file_put_contents($zip_tmp_path,$zip);

            $zip = new ZipArchive;  
            if ($zip->open($zip_tmp_path) !== TRUE) 
                throw new \Exception("Zip exception open", 1);
            
            $zip->setPassword(ZIP_PASSWORD);
            $zip->extractTo(ZIP_TEMP_PATH);
            $zip->close(); 
            $zs = explode('.', $zip_tmp_path);
            $file = $zs[0].'.xml';

            $xmlParser = new xmlParser;
            $data = $xmlParser->getCrmXmlDataToArray($file);
            $xmlParser->idestruct();
            
            @unlink($zip_tmp_path);
            @unlink($file);
            return $data['items'];
        } catch (\Exception $e) {
            throw new \Exception("Error Processing Request", 1);
        }

    }


    public static function formatDate($charge_end_date = NULL) {
        if (empty($charge_end_date)) 
            return 0;
        $arr = explode("T", $charge_end_date);
        return strtotime($arr[0]);  
    }
    
    /**
     * 
     *  通过七牛获取数据并解压
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     *
     * 
     * 
     */
   public static function getInitCustomTaskTextForQiniu($url = NULL) {
        try {   

            $text = file_get_contents($url);
            return explode(',',file_get_contents($url));
        } catch (\Exception $e) {
            throw new \Exception("Error Processing Request", 1);
        }
    }


    

    /**
     * 
     * 通过税局编码号分析出省市区
     * @param string $taxBureau   
     * @return    array
     * 1 6 5 0 1 0 4 00
     *  65010400
     *  1，6
     */
    public static function analyseProvinceCodeByTaxBureau($taxBureau = NULL) {
        $code = substr($taxBureau, 1, 6);
        $tmp = array(
            'province' => '', //省
            'city' => '', //市
            'zone' => '', //县或市或区
        );
        $rc = str_split($code, 2);
        $tmp['province'] = array(
            'code' => $rc[0] . '0000',
            '_as' => $rc[0],
        );
        if ('00' != $rc[1]) {
            $tmp['city'] = array(
                'code' => $rc[0] . $rc[1] . '00',
                '_as' => $rc[1],
            );
        }
        if ('00' != $rc[2]) {
            $tmp['zone'] = array(
                'code' => $code,
                '_as' => $rc[2],
            );
        }
        return $tmp;
    }

    /**
     * 通过税号分析出地区码
     * @param string $xml  
     * @return srtring (6位地区码)
     *
     * 税号规则
     * 15位=6位税务区划+企业编码
     * 
     * 17位=15位身份证+2编码
     * 18位=身份证
     * 
     * 20位=18位身份证+2编码
     *
     * 企业信用代码   91650100761133756N (18)
     * 企业税号       650100 030001620 （15） 
     *
     * 直辖市 500000 
     * INSERT INTO region (pid,type,code,name) VALUES ('3393','1','654100','伊犁地区');
     * 
     */
    public static function analyseRegionCodeByTax($tax = NULL) {
        $ret = null;
        
        if (15 != strlen($tax) && 
            17 != strlen($tax) && 
            20 != strlen($tax) && 
            18 != strlen($tax) && 
            19 != strlen($tax)) {

            print "非法税号:".$tax .PHP_EOL;
            return array(
                'province' => array(
                    'code' => 0,
                    '_as' =>0,
                )
            );
        } 
        if (15 == strlen($tax) || 17 == strlen($tax) || 20 == strlen($tax))
            $ret = substr($tax, 0, 6);

        if (18 == strlen($tax) || 19 == strlen($tax))
            $ret = substr($tax, 2, 6);


        $tmp = array(
            'province' => '', //省
            'city' => '', //市
            'zone' => '', //县或市或区
        );

        $rc = str_split($ret, 2);

        $tmp['province'] = array(
            'code' => $rc[0] . '0000',
            '_as' => $rc[0],
        );

        if ('00' != $rc[1]) {
            $tmp['city'] = array(
                'code' => $rc[0] . $rc[1] . '00',
                '_as' => $rc[1],
            );
        }

        if ('00' != $rc[2]) {
            $tmp['zone'] = array(
                'code' => $ret,
                '_as' => $rc[2],
            );
            
        }

        return $tmp;
    }
    /**
     *  写日志
     * @return mixed $data default array, else Exception 
     */
    public static function _writelog($msg = NULL) {
        print $msg.PHP_EOL;
    }

    /**
     *  写pid
     * @return mixed $data default array, else Exception 
     */
    public static function _writePid($path,$pid) {
        return file_put_contents($path,$pid);
    }

    /**
     *  读pid
     * @return mixed $data default array, else Exception 
     */
    public static function _readPid($path) {
        return file_get_contents($path);
    }

    public static function jsonEncode(array $data = NULL) {
        return json_encode($data);
    }
    
    public static function jsonDecode($str = NULL) {
        return (array)json_decode($str);
    }

    public static function getTaskClass($type = NULL) {
        return SERVER_CONFIG::$types[$type];
    }
    public static function getMasterPid($masterPidFile = NULL)
    {
        $pid = false;
        if (file_exists($masterPidFile)) {
            $pid = file_get_contents($masterPidFile);
        }
        return $pid;
    }
    public static function getManagerPid($managerPidFile = NULL)
    {
        $pid = false;
        if (file_exists($managerPidFile)) {
            $pid = file_get_contents($managerPidFile);
        }
        return $pid;
    }


}