<?php
include_once "./bootstrap.php";

$file = __DIR__ . '/20180524163421948.xml';


class xmlParser 
{
	/**
	 * 数组数据
	 * @var array
	 */
	public  $crm = array();

	/**
	 * 获取crmXml数据变array
	 * @param  [type] $file [description]
	 * @return [type]       [description]
	 */
	public function getCrmXmlDataToArray($file)
	{

		$self = $this;
		$handler = new FastXml\CallbackHandler\GenericHandler;
		$handler->setOnItemParsedCallback(function ($item) use ($self) {
			  $self->crm[] = $item;
		});


		// set "on progress" callback
		$handler->setOnProgressCallback(function ($bytesProcessed, $bytesTotal) use ($self) {
		    // eg. draw a progress bar
		});

		$parser = new FastXml\Parser($handler);
		$parser->setIgnoreTags(['ROOT','ROW']);
		$parser->setEndTag('BRANCH_OFFICE');
		$parser->parse($file);
		
		return array(
			'items'=>$this->crm,
			'len'=>count($this->crm),
		);
	}
}

$xmlParser = new xmlParser;

$items = $xmlParser->getCrmXmlDataToArray($file);

var_dump($items['len']);