<?php

class Events
{


    /**
     * 任务队列
     * 
     * @param string $ip
     * @param int $port
     * @return void
     * 
     */

    public static $queue = array();
    
    /**
     * 监控频道
     * 
     * @param string $ip
     * @param int $port
     * @return void
     */
    public static function monitorChannel($srv = NULL) {
        print 'monitor start...'.PHP_EOL;
        //链接redis
        $redis_client = new \swoole_redis;
        //通道
        $redis_client->on('message', function (swoole_redis $client, $result) use($srv) {
            if ($result[0] == 'message') {
                //array_push(Events::$queue,$message);
                Worker::controllerHandler($result[2],$srv);
            }
        });

        $redis_client->connect(
            CHANNEL_SERVER_IP,
            CHANNEL_SERVER_PORT, 
            function (swoole_redis $client, $result) {
                $client->subscribe(CRM_0LTN);
            }
        );
    } 

    /**
     * onWorkerStart
     * @param string $ip
     * @param int $port
     * @return void
     */
    public static function onWorkerStart($srv = NULL) {
        return ;
    }

    /**
     * onMessage
     * 
     * @param string serv
     * @param int    fd
     * @param int    from_id
     * @param json   data
     * @return void
     * 
     */
    public static function onMessage($srv, $fd, $from_id, $message)
    {
        return ;
    }

    /**
     * onConnect
     * @param string $serv
     * @param int $fd
     * @return void
     */
    public static function onConnect($srv, $fd, $from_id) {
        return ;

    /*
    $msg =  "server: {$fd} 客户端连接成功.\n";
    print $msg;
    $srv->send($fd,$msg);
    */    

    }


    /**
     * onClose
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onClose($srv, $fd) {
        //清楚资源
        return '';
    }


    /**
     * onTask
     * 
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onTask($srv, $task_id, $from_id, $data) {
        $class = Util::jsonDecode($data)['_taskClass_'];
        print "任务开始时间：".$task_id.$from_id.date('Y-m-d H:i:s',time()).PHP_EOL;
        return $class::run($srv,$task_id,$from_id,$data,function($data) use ($srv) {
              $element = $srv->hashTable->get($data['_uq']);
              $element['num'] += 1;
              $element['success'] += $data['data']['success'];
              $element['fail'] += $data['data']['fail'];
              $srv->hashTable->set($data['_uq'],$element);
              print "任务结束时间：".date('Y-m-d H:i:s',time()).PHP_EOL;
              return Util::jsonEncode($data);
          });
    }

    /**
     * onFinish
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function onFinish($srv, $task_id, $data) {
        $class = Util::jsonDecode($data)['_taskClass_'];
        $element = $srv->hashTable->get(Util::jsonDecode($data)['_uq']);
        $msg = '';
        $msg .="任务ID:\033[32;40m [".$task_id."] \033[0m".PHP_EOL;
        $msg .="来自进程编号:"."\033[32;40m [".$srv->worker_id."] \033[0m".PHP_EOL;
        $msg .='任务数'.$element['num'].'总数'.$element['len'].PHP_EOL;
        Util::_writelog($msg);
        if ($element['num'] == $element['len']) {
            return $class::Finish($srv,$task_id,$element,$data,function($data)use($srv) {
              $_uq = Util::jsonDecode($data)['_uq'];
              $element = $srv->hashTable->get($_uq);
              $srv->hashTable->del($_uq);
              print  '结束时间：'.date('Y-m-d H:i:s',time()).PHP_EOL;
            });
        } 
    }
}