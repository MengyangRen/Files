<?php
class Worker
{
    /**
     * controllerHandler
     * 
     * @param string protocol
     * @param obj    $srv
     * @return void
     * 
     */
    public static function controllerHandler($protocol = NULL,$srv = NULL) {
        $type = Util::jsonDecode($protocol)['type'];
        $_class = SERVER_CONFIG::$types[$type];
        if (empty($_class))
            return ;
        $_class::run($srv,$protocol);
    }

    /**
     * 
     * publishToChannel
     * 
     * @param string $ip
     * @param int $fd
     * @return void
     * 
     */
    public static function pub($json_protocol = NULL) {
        try {

            $redis = new Redis();
            $res = $redis->connect(CHANNEL_SERVER_IP,CHANNEL_SERVER_PORT);
            $res = $redis->publish(CRM_2LTN,$json_protocol);
            $redis->close();

        } catch (\Exception $e) {
            throw new \Exception($e->getMessage(), $e->getCode());
        }
    }
    
    
}