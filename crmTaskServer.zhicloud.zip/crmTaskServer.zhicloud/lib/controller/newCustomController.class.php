<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   
 *   用户数据更新 (新增用户)
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */
class newCustomController implements IController
{
    /**
     * 
     * 运行
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     * {"type":"new-custom","origin":"hlhx","qiniu_path":"hlj/hx/2018/05/07/20180507162149.zip","time":"1525681280"}
     * 
     */
     public static function run($srv,$protocol) {		
          try {

               $org = Util::jsonDecode($protocol)['origin'];
               $maps = Util::getZipDataForQiniu(
                    QINIU_DOMAIN.Util::jsonDecode($protocol)['qiniu_path']
               );

              $objs = array(
                  'companysModel'=>Factory::model('companysModel'),
                  'hzsModel'=>Factory::model('hzsModel'),
                  'customsModel'=>Factory::model('customsModel'),
                  'cchModel'=>Factory::model('cchModel'),
                  'regionModel'=>Factory::model('regionModel'),
                  'tnChangeModel'=>Factory::model('tnChangeModel'),
                  'zhicloudCompanSrcModel'=>Factory::model('zhicloudCompanSrcModel'),
                  'customsFeatureModel'=>Factory::model('customsFeatureModel'),
                  'chargeExpireModel'=>Factory::model('chargeExpireModel'),
              );

              $itemNum =  0;
              $len = count($maps);
              if (!$len)  
                  return ;

              do {   


                    /**
                     * 情况
                     * 
                     * 1.合作商客户的税号变更了，平台未变更 ？
                     * 2.平台税号变更，合作商税号未变更 ？
                     * ----------------------------------
                     *
                     * 3.税号存在平台，账号为默认生成 （更新信息与所属合作商）
                     * 4.税号在平台不存在，该用户生成数据插入到资源库中
                     *
                     */        
                             
                    $item = $maps[$itemNum];
                    $item += array('org'=>$org);

                    $arr = $objs['companysModel']->getCompanyByTaxNo(
                            trim($item['CUST_TAX_CODE'])
                    );

                   /**
                    * #数据库中查询到
                    * 
                    * 更新用户信息
                    * 
                    * 1.合作商所属判定，1个省可能存在多个合作商，
                    *   通过数据来源修正所属合作商
                    * 2.对基于税号生成的默认账号，信息进行修正
                    * 
                    */

                    if (!empty($arr)) {
                       self::updateCustom($item,$arr,$org,$objs);  
                    }

                   /**
                    * #数据库中未查询到
                    * 
                    * 通过企业名称查询到企业信息
                    * 
                    * 1.如查询到说明公司税号进行变更了
                    * 2.直接更新
                    *
                    * 注：
                    *   如用户税号与企业名称都进行变更，
                    *   该情况下无法进行处理
                    *  
                    */
                   
                    if (empty($arr)) {
                       $arr = $objs['companysModel']
                       ->getCompanyByName($item['cust_name']);
                       //如果税号不一致,企业名称相同
                       if (!empty($arr)) {  
                          //添加一个新税号
                          $objs['tnChangeModel']->save($item['CUST_TAX_CODE'],$arr['id']);
                       } else {
                          //更新到资源库
                          self::addCustomToZhiCloudCompanSrc($item,$objs,$org);
                       }
                    }

                    $itemNum++;
               } while ($len > $itemNum);
       
        $maps = NULL;
        $sn = Util::jsonDecode($protocol)['sn'];
        print "---------------------------------------".PHP_EOL;
        print "[任务编号]:\033[32;40m [".$sn."] \033[0m".PHP_EOL;
        print "[协议]:".$protocol.PHP_EOL;
        print "[任务数]:".$len.PHP_EOL;
        print "[成功]:".$len.PHP_EOL;
        print "[失败]:"."0".PHP_EOL;
        print "[时间]:".date("Y-m-d H:i:s",time()).PHP_EOL;
        print "---------------------------------------".PHP_EOL;

      	} catch (\Exception $e) {
           var_dump($e->getMessage());
           var_dump($e->getCode()); 
      	}
  	 }

     /**
      * 
      *  添加用到致云资源库
      * 
      * @param obj    item     服务对象
      * @param string protocol 协议
      * @return void
      * 
      */
     protected static function addCustomToZhiCloudCompanSrc($item = array(),$objs = array(),$org = NULL) {
        $objs['zhicloudCompanSrcModel']->save(array(
          'tax'=>$item['CUST_TAX_CODE'],
          'type'=>3, //crm服务更新
          'company_name'=>$item['cust_name'],
          'tb_code'=>empty($item['TAX_AUTHORITY_CODE'])? '': $item['TAX_AUTHORITY_CODE'] ,
          '_as'=>$org,
          '_md'=>createCustomComponent::makeJson($item,$objs)
        ));
        return  true;
     }

    /**
     * 
     *  更新用户
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     * 
     */
     protected static function updateCustom($item = array(),$arr = NULL,$org = NULL,$objs = array()) 
     {

        try {
              
              $hzs_id = $objs['hzsModel']->getHzsIDBySign(trim($org))['id'];
              $customs = $objs['cchModel']->getCustomIds($arr['id']);


              /**
               * 
               * 合作商变更 (用户桌面应用变更)
               * 
               * 更新公司所属合作商
               * 更新用户所有合作商
               * 更新中间表
               * 修正用户数据
               * 更新用户特征表（合作商，区域，等）
               * 更新服务费
               * 
               */
              
              if ($arr['hzs_id'] != $hzs_id) {

                 $objs['companysModel']->upHzsID($arr['id'],$hzs_id);
                 foreach ($customs as $custom) {
                    $objs['customsModel']->upHzsID($custom['custom_id'],$hzs_id);
                 }
                 $objs['cchModel']->upHzsID($arr['id'],$hzs_id); 

                 /**
                  *1.合作商变更
                  *2.桌面应用变更
                  *
                  */
                 $arr['hzs_id'] = $hzs_id;
                 desktopAppComponent::changeCustomDesktopApps($arr,$hzs_id);

              }
              
              if (trim($item['cust_name']) != $arr['company_name']) {
                  self::amendCompanyInfo($item,$arr['id'],$objs);
              }

              //$objs['customsFeatureModel']->upHzsID();
              $item['hzs_id'] = $hzs_id;
              self::updateServiceCharge($item,$objs);

        } catch (Exception $e) {
             throw new \Exception($e->getMessage(), 1);
        }
    }

    /**
     * 
     *  更新服务费用
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     * 
     */
    
     protected static function updateServiceCharge($item = array(),$objs = array()) 
     {
     
        $arr = $objs['chargeExpireModel']->getCompayCharge($item['CUST_TAX_CODE']);

        if (empty($arr)) {
            $data = array(
              'tax_number'=>$item['CUST_TAX_CODE'],
              'hzs_id'=>$item['hzs_id'],
              'type'=>1,
              'expire'=>Util::formatDate($item['CHARGE_END_DATE']),
              'check_up_time'=>0,
            );
            $objs['chargeExpireModel']->save($data);
        }

    }

    /**
     * 
     *  修复企业信息
     *  
     * @param obj   item  数据项
     * @param int   id    协议
     * @param obj   objs  数据对象 
     * @return void
     * 
     */
    protected static function amendCompanyInfo($item,$id,$objs) { 
      $objs['companysModel']->upFieldData(
          createCustomComponent::makeUpFieldArr($item,$objs),
          $id
      );

    }


}