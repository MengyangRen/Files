<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   
 *   初始化资源
 *   （合作商用户的数据-同步到-资源库中）
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */

class initCustomSrcController implements IController
{


    /**
     * 
     * 运行
     * 
     * @param obj    srv     服务对象
     * @param string protocol 协议
     * @return void
     * 
     */
	public static function run($srv,$protocol) {
		
    try {	

         $protocol = Util::jsonDecode($protocol);
         $taskItems = Util::getInitCustomTaskTextForQiniu(
              QINIU_DOMAIN.$protocol['qiniu_path']
         );
         
         $len = count($taskItems);
         $taskData = array(
              '_taskClass_'=>'initCustomSrcTask',
              'org'=>$protocol['origin'],
              '_uq'=>$protocol['sn'],
              'items'=>$taskItems
         );

        try {
           $asysTaskCli = new asysTaskCli;
           $asysTaskCli->connect();
           $asysTaskCli->create(20002,$taskData,$len,$protocol['sn']);
           $asysTaskCli->close();
        } catch (Exception $e) {
            print $e->getCode();
            print $e->getMessage();
        }

		} catch (\Exception $e) {
        throw new \Exception($e->getMessage(),$e->getCode());
		}
	}

  
}