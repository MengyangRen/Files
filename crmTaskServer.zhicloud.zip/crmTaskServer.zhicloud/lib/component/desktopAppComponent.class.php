<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   
 *   客户桌面组件
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 *

 * 
 */

class desktopAppComponent
{

 
    /**
     * 
     *  改变客户桌面应用数据
     *  
     * @param int    company  企业信息
     * @param int    hzs_id   合作商id 
     * @return void
     * 
     */
    public static function changeCustomDesktopApps($company = NULL ,$hzs_id = NULL) {

        $objs = array(
          'cchModel'=>Factory::model('cchModel'),
          'cloudDesktopAppsModel'=>Factory::model('cloudDesktopAppsModel'),
          'cloudDesktopAppTplModel'=>Factory::model('cloudDesktopAppTplModel'),
          'cloudDesktopAppTplRegionModel'=>Factory::model('cloudDesktopAppTplRegionModel'),
        );

        $custom_area = desktopAppComponent::getCustomRegionalSign($company,$objs);

        $apps = desktopAppComponent::getHzsTplApps($hzs_id,$objs);
        if (empty($apps)) 
            return false;
        $list = desktopAppComponent::createCustomApps($custom_area,$apps);

        //重新初始化用户应用
        foreach ($list as $item) {
          foreach ($item as $val) {
            /**
             * 不存在情况
             * 
             */
            if ($objs['cloudDesktopAppsModel']->findCustomApps($val['uid'])) {
                $objs['cloudDesktopAppsModel']->save($val);
            } else {
              //存在就删除更新   
              if ($objs['cloudDesktopAppsModel']->delCustomApps($val['uid'])) 
                   $objs['cloudDesktopAppsModel']->save($val);
            }
            # code...
          }
        }
    }


    /**
     * 
     *  获取合作商模板应用集合
     *  
     * @param int    hzs_id     合作商id 
     * @return void
     * 
     */
    public static function getHzsTplApps($hzs_id = NULL,$objs = NULL) {
        $newApps = array();
        
        $appTpls = $objs['cloudDesktopAppTplModel']->getAppTplByHzsId($hzs_id);


        

        if (empty($appTpls)) {
           print $hzs_id."合作商未配置应用模板".PHP_EOL;
           return false;
        } 

        var_dump($appTpls);

        if (!is_array($appTpls)) {
            $appTpls = (array) $appTpls;
        } 
        
        foreach ($appTpls as $apps) {
           $area = $objs['cloudDesktopAppTplRegionModel']->getAppTplRegionByTid($apps['id']);

           if (empty($area)) {
              if (!is_array($area)) {
                  print $hzs_id."合作商应用模板为无区域".PHP_EOL;
                  $area = (array) $area;
              } 

              $apps['province_id'] = $area['province_id'];
              $apps['city_id'] = $area['city_id'];
              $apps['zone_id'] = $area['zone_id'];
              $newApps[] = $apps;
          
           } else {
              $apps['province_id'] = 0;
              $apps['city_id'] = 0;
              $apps['zone_id'] = 0;
              $newApps[] = $apps;
           }

        }
        return $newApps;
    }


    /**
     * 
     *  用户的区域特征
     *  
     * @param int    company  企业
     * @param int    hzs_ud     合作商id 
     * @return void
     * 
     */
    public static function getCustomRegionalSign($company ,$objs) {
      $_rs  = array();  
      $customs = $objs['cchModel']->getCustomIds($company['id']);
      foreach ($customs as $custom) {
         $_rs[] = array(
          'compan_id'=>$company['id'],
          'uid'=>$custom['custom_id'],
          'hzs_id'=>$company['hzs_id'],
          'province_id'=>$company['province_id'],
          'city_id'=>$company['city_id'],
          'zone_id'=>$company['zone_id'],
         );
      }
      return $_rs;
    } 

    /**
     * 
     *  创建用户桌面应用
     *  
     * @param int    company  企业
     * @param int    hzs_ud     合作商id 
     * @return void
     * 
     */
    public static function createCustomApps($custom_area = NULL,$tpl_apps = NULL) {
      $apps =  array();


      //地区区域
      foreach ($custom_area as $custom) {

        $p_apps = array();
        $c_apps = array();

        foreach ($tpl_apps as  $app) {
          /**
           *1.所属该省合作商的应用
           *2.所属该市合作商的应用
           *
           */
          if (($app['province_id'] == $custom['province_id'])  && 
            ($app['city_id'] == 0)) {

            $p_apps[] = array(
              'uid'=>$custom['uid'],
              'compan_id'=>$custom['compan_id'],
       /*       'hzs_id'=>$custom['hzs_id'],*/
              'app_id'=>$app['app_id']
            );
          
          } 


          if (($app['province_id'] == $custom['province_id'])  && 
            ($app['city_id'] == $custom['city_id'])) {
          
            $c_apps[] = array(
              'uid'=>$custom['uid'],
              'compan_id'=>$custom['compan_id'],
             /* 'hzs_id'=>$custom['hzs_id'],*/
              'app_id'=>$app['app_id']
            );

          }
        }

        $apps[] = array_merge($p_apps,$c_apps);

      }

      return $apps;   
    }

}