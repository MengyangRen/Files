<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *  定义控制器的接口
 * 
 * @author  v.r
 * @copyright copyright http://my.oschina.net/u/1246814
 * 
 */
interface IController
{
	public static function run($srv,$protocol); //任务
	
	//public static function Finish($srv, $task_id, $element,$data,$callback); //汇总
}
