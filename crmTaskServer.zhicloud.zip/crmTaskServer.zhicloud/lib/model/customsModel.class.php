<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   合作商模型
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class customsModel 
{
	private $table = 'zhiCloudCustoms.customs';
	private $model = NULL;
	private $useDb = 'zhiCloudCustoms';

    /**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function upHzsID($uid = NULL ,$hid = NULL) {
		$sql = "UPDATE ".$this->table." SET hzs_id = '{$hid}'";
		$sql.= " WHERE id = '{$uid}'";
		return MysqlPoolClient::glean($sql,'exec');
	}

}