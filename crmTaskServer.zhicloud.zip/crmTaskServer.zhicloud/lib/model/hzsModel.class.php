<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   合作商模型
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class hzsModel 
{
	private $table = 'zhiCloudHzs.hzs';
	private $model = NULL;
	private $useDb = 'zhiCloudHzs';

	/**
     * 
     *  通过标识查询合作商
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function getHzsIDBySign($sign = NULL) {
        $sql = "SELECT id,sign FROM ".$this->table. " WHERE  `sign` = '". $sign."'";
        $ret = MysqlPoolClient::glean($sql);
        return $ret[0];
	}

	/**
     * 
     *  区域信息
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function getHzsAreasBySign($sign = NULL) {
        $sql = "SELECT id,province_id FROM ".$this->table. " WHERE  `sign` = '". $sign."'";
        $ret = MysqlPoolClient::glean($sql);
        return $ret[0];
	} 
}