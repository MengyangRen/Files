<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   应用桌面模板表
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class cloudDesktopAppsModel 
{
	private $table = 'zhiCloudApp.cloud_desktop_apps';
	private $model = NULL;
	private $useDb = 'zhiCloudApp';



    /**
     * 
     *  删除用户桌面应用
     *  
     * @param int    company_id  企业id
     * @param int    hzs_id     合作商id 
     * @return void
     * 
     */
    public function delCustomApps($uid = NULL) {
       $sql = " DELETE FROM ".$this->table." WHERE  `uid` = ".$uid;
       return MysqlPoolClient::glean($sql,'exec');
    }

    /**
     * 
     *  查找用户桌面应用
     *  
     * @param int    uid  用户uid
     * @return void
     * 
     */
    public function findCustomApps($uid = NULL) {
        $sql = " SELECT * FROM ".$this->table." WHERE  `uid` = ".$uid;
        return MysqlPoolClient::glean($sql);
    }

    /**
     * 
     *  保证用户初始化数据
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     */
    public function save($data) {
        $sql = createSqlComponent::Insert($this->table,$data);
        return MysqlPoolClient::glean($sql,'exec');

    }		
}
