<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   公司模型
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class companysModel 
{
	private $table = 'zhiCloudCustoms.companys';
	private $model = NULL;
	private $useDb = 'zhiCloudCustoms';

	/**
     * 
     *  通过税号查询企业
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     */
    
	public function getCompanyByTaxNo($tn = NULL) {
        $sql = "SELECT * FROM ".$this->table. " WHERE  `tax_number` = '". $tn."'";
        $ret = MysqlPoolClient::glean($sql);
        return $ret[0];

    }


    /**
     * 
     *  通过企业名字查询企业
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     */
    public function getCompanyByName($name = NULL) {
        $sql = "SELECT * FROM ".$this->table. " WHERE  `company_name` = '". $name."'";
        $ret = MysqlPoolClient::glean($sql);
        return $ret[0];

    }



    /**
     * 
     *  更新字段
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     *  
     */
    public function upFieldData($item = array(), $id = NULL) {
        $sql = "UPDATE ".$this->table." SET ";
        $sql.= createSqlComponent::Set($item);
        $sql.= " WHERE ";
        $sql.= createSqlComponent::And(array('id'=>$id));
        return MysqlPoolClient::glean($sql,'exec');
    }


    /**
     * 
     *  更新税号
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
    public function upTaxNumber($tax_number = NULL ,$id = NULL) {
        $sql = "UPDATE ".$this->table." SET tax_number = '{$tax_number}'";
        $sql.= " WHERE id = '{$id}'";
        return MysqlPoolClient::glean($sql,'exec');

    }

	
	/**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function upHzsID($cid = NULL ,$hid = NULL) {
        $sql = "UPDATE ".$this->table." SET hzs_id = '{$hid}'";
    	$sql.= " WHERE id = '{$cid}'";
        return MysqlPoolClient::glean($sql,'exec');
	}
    
}