<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   所用数据库相关模型
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class zqtNoticeModel 
{
	private $table = 'zhiCloudCommon.government_notices_push';
	private $model = NULL;
	private $useDb = 'zhiCloudCommon';

	/**
     * 
     * 更新政企通，通知的推送数量与状态
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     *  
     */
    public function updateZqtNoticeSendStatus($success = NULL,$uq = NULL) {
    	$sql = "UPDATE ".$this->table." SET count = count + {$success},pushed = 1";
    	$sql.= " WHERE mucode = '{$uq}'";    
        return MysqlPoolClient::glean($sql,'exec');
    }   
}