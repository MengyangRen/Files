<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   应用桌面模板表
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class cloudDesktopAppTplRegionModel 
{
	private $table = 'zhiCloudApp.cloud_desktop_app_tpl_region';
	private $model = NULL;
	private $useDb = 'zhiCloudApp';
    
    /**
     * 
     *   获取应用模板区域
     *  
     * @param int    tpl_id  模板id
     * @return void
     * 
     */
    public function getAppTplRegionByTid($id  = NULL) {
        $sql = "SELECT province_id,city_id,zone_id FROM ".$this->table." WHERE  tpl_id = ".$id;
        $ret = MysqlPoolClient::glean($sql);
        return $ret[0];
    }

}
