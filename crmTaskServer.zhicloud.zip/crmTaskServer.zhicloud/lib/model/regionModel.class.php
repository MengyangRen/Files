<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  地区模型
 *     
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class regionModel 
{
	
	private $table = 'zhiCloudCommon.region';
	private $model = NULL;
	private $useDb = 'zhiCloudCommon';

	public function getIdByZcode($code = NULL,$type = 0) {
		$sql = "SELECT id FROM ".$this->table. " WHERE  `code` = '". $code ."'";
		$ret = MysqlPoolClient::glean($sql);
		return $ret[0];
	}
    
    /**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getHzsIDBySign
     */
	public function upHzsID($uid = NULL ,$hid = NULL) {
		$sql = "UPDATE ".$this->table." SET hzs_id = '{$hid}'";
		$sql.= " WHERE id = '{$uid}'";
		return MysqlPoolClient::glean($sql,'exec');
	}

}