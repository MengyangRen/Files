<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   资源库
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class zhicloudCompanSrcModel 
{

	private $table = 'zhiCloudNetWorkSrc.zhicloud_compan_src_t';
	private $model = NULL;
	private $useDb = 'zhiCloudNetWorkSrc';
	/**
     * 
     *  保存资源数据
     * @param   mixed $increment default true, else full crawler
     *  getWriteQueueFailedItems
     */
	public function save($data) {
		$sql = createSqlComponent::Insert($this->table,$data);
		$sql = str_replace("\\","\\\\",$sql);
	    return MysqlPoolClient::glean($sql,'exec');

	}
}