<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   合作商模型
 *   
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */

class chargeExpireModel 
{

	private $table = 'zhiCloudCommon.charge_expire';
	private $model = NULL;
	private $useDb = 'zhiCloudCommon';
	
    /**
     * 
     *  获取该公司的服务费
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  getCompayCharge
     */
	public function getCompayCharge($tax_number = NULl) {
		$sql = "SELECT id FROM ".$this->table. " WHERE  `tax_number` = '". $tax_number."'";
        $ret = MysqlPoolClient::glean($sql);
        if (!empty($ret)) 
            return $ret[0];
        else 
            return false; 
	}

    /**
     * 
     *  更新服务费
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  save
     */
    public function updateServiceCharge($arr = NULL) {
        $tax_number = $arr['tax_number'];
        $expire = $arr['expire'];
        $time   =  time();
        $sql  = "UPDATE ".$this->table." SET expire = '{$expire}',check_up_time = '{$time}'";
        $sql .= "WHERE tax_number = '{$tax_number}'";
        return MysqlPoolClient::glean($sql,'exec');
    }
    
    /**
     * 
     *  更新合作商id
     *  
     * @param   mixed $increment default true, 
     * else full crawler
     *  save
     */
	public function save($data = array()) {
		$sql = createSqlComponent::Insert($this->table,$data);
        return MysqlPoolClient::glean($sql,'exec');
	}


}