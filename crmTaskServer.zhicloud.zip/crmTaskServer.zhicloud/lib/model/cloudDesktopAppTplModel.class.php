<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *   应用桌面模板表
 * @author  v.r
 * @package task.services 
 * 
 * 注: 辅助方法为私有方法 命名以下滑线开头
 * 
 */


class cloudDesktopAppTplModel 
{
	private $table = 'zhiCloudApp.cloud_desktop_app_tpl';
	private $model = NULL;
	private $useDb = 'zhiCloudApp';

    /**
     * 
     *  改变客户桌面应用数据
     *  
     * @param int    company_id  企业id
     * @param int    hzs_id     合作商id 
     * @return void
     * 
     */
    public function getAppTplByHzsId($hzs_id = NULL) {
        $sql  = "SELECT *  FROM ".$this->table." WHERE  hzs_id = ".$hzs_id ;
        $sql .= " AND `is_push` = 1";
        return MysqlPoolClient::glean($sql);
    }
		
}
