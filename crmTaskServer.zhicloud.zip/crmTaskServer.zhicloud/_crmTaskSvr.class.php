<?php

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  CRM业务处理服务
 * 
 * @author  v.r
 * @package Common
 * 
 */

if(!defined('CRM_TASK_LIB_PATH'))
    define('CRM_TASK_LIB_PATH', dirname(__FILE__));
date_default_timezone_set('Asia/Shanghai');

require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'config.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'util'.DIRECTORY_SEPARATOR.'util.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'util'.DIRECTORY_SEPARATOR.'mysql_pool_syn_tcp_client.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'interface'.DIRECTORY_SEPARATOR.'Itask.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'interface'.DIRECTORY_SEPARATOR.'IController.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Factory.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Events.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Worker.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'Server.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'util'.DIRECTORY_SEPARATOR.'asysTaskCli.class.php';
require_once CRM_TASK_LIB_PATH.DIRECTORY_SEPARATOR.'lib'.DIRECTORY_SEPARATOR.'util'.DIRECTORY_SEPARATOR.'xml-parser-master'.DIRECTORY_SEPARATOR.'bootstrap.php';
spl_autoload_register("Util::_loadOfClassPhp"); 
$CrmTaskServer = new crmTaskServer(SER_IP,SER_PORT);
$CrmTaskServer->run();
