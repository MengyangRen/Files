define({
  "name": "马上约.API文档",
  "version": "1.0.0",
  "description": "PHP Development ",
  "apidoc": "0.3.0",
  "header": {
    "title": "公共约定",
    "content": "<p>##1 概述\n##2.通用参数说明\n##3.通用码</p>\n<table>\n<thead>\n<tr>\n<th>CODE码</th>\n<th style=\"text-align:center\">说明</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td>200</td>\n<td style=\"text-align:center\">成功码</td>\n</tr>\n<tr>\n<td>304</td>\n<td style=\"text-align:center\">未修改</td>\n</tr>\n<tr>\n<td>400</td>\n<td style=\"text-align:center\">请求无效</td>\n</tr>\n<tr>\n<td>401</td>\n<td style=\"text-align:center\">未授权</td>\n</tr>\n<tr>\n<td>500</td>\n<td style=\"text-align:center\">服务内部错误</td>\n</tr>\n<tr>\n<td>501</td>\n<td style=\"text-align:center\">不支持该客户端</td>\n</tr>\n<tr>\n<td>601</td>\n<td style=\"text-align:center\">参数非法</td>\n</tr>\n<tr>\n<td>602</td>\n<td style=\"text-align:center\">内容为空</td>\n</tr>\n</tbody>\n</table>\n"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-08-29T05:10:09.995Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
