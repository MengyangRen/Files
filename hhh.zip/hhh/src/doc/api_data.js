define({ "api": [
  {
    "type": "get",
    "url": "apply-servant/ad-item",
    "title": "申请服务者宣传广告",
    "description": "<p>申请服务者宣传广告</p>",
    "group": "Ad",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/apply-servant/ad-item",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n HTTP/1.1 200 OK \n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 2,\n          \"key\": \"key2\",\n          \"position\": \"APPlY-SERVANT\",\n          \"type\": \"LINK\",\n          \"title\": \"申请加入服务者宣传广告\",\n          \"remark\": \"xxx\",\n          \"path\": \"/www/back2/jsd.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 2\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2049",
            "description": "<p>赞无广告</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AdController.php",
    "groupTitle": "Ad",
    "name": "GetApplyServantAdItem"
  },
  {
    "type": "get",
    "url": "/home/ad-items",
    "title": "首页广告",
    "description": "<p>首页广告</p>",
    "group": "Ad",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/home/ad-items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "响应（示例）：",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 5,\n          \"key\": \"key5\",\n          \"position\": \"HOME-BANNER-MODEL\",\n          \"type\": \"LINK\",\n          \"title\": \"广告3\",\n          \"remark\": \"cc\",\n          \"path\": \"/www/back5/default.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 3\n      },\n      {\n          \"id\": 4,\n          \"key\": \"key4\",\n          \"position\": \"HOME-BANNER-MODEL\",\n          \"type\": \"LINK\",\n          \"title\": \"首页广告2\",\n          \"remark\": \"yy\",\n          \"path\": \"/www/back4/default.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 2\n      },\n      {\n          \"id\": 3,\n          \"key\": \"key3\",\n          \"position\": \"HOME-BANNER-MODEL\",\n          \"type\": \"LINK\",\n          \"title\": \"首页广告\",\n          \"remark\": \"xxx\",\n          \"path\": \"/www/back3/default.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 1\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "错误Code": [
          {
            "group": "错误Code",
            "optional": false,
            "field": "2049",
            "description": "<p>暂无广告</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AdController.php",
    "groupTitle": "Ad",
    "name": "GetHomeAdItems"
  },
  {
    "type": "get",
    "url": "/login/ad-items",
    "title": "登陆广告",
    "description": "<p>登陆广告</p>",
    "group": "Ad",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/login/ad-items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n  HTTP/1.1 200 OK\n  \n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 1,\n          \"key\": \"key\",\n          \"position\": \"LOGIN-MODEL\",\n          \"type\": \"LINK\",\n          \"title\": \"登陆模块广告1\",\n          \"remark\": \"xx\",\n          \"path\": \"/www/back/js.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 1,\n          \"status\": 1,\n          \"created_at\": \"2019-08-25 21:04:10\",\n          \"updated_at\": null,\n          \"deleted_at\": null\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2049",
            "description": "<p>赞无广告</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AdController.php",
    "groupTitle": "Ad",
    "name": "GetLoginAdItems"
  },
  {
    "type": "get",
    "url": "/wallet/ad-items",
    "title": "钱包广告",
    "description": "<p>钱包广告</p>",
    "group": "Ad",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/wallet/ad-items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n  HTTP/1.1 200 OK\n  \n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 2,\n          \"key\": \"key2\",\n          \"position\": \"WALLET-MODEL\",\n          \"type\": \"LINK\",\n          \"title\": \" 钱包模块广告\",\n          \"remark\": \"xxx\",\n          \"path\": \"/www/back2/jsd.jpg\",\n          \"redirect_url\": \"http://www.baidu.com\",\n          \"sort\": 2\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2049",
            "description": "<p>赞无广告</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AdController.php",
    "groupTitle": "Ad",
    "name": "GetWalletAdItems"
  },
  {
    "type": "patch",
    "url": "/password",
    "title": "修改密码(password)",
    "description": "<p>修改密码(password)</p>",
    "group": "Auth",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Mobile",
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code_key",
            "description": "<p>发送短信后服务端返回的短信key</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>验证码</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"status_code\": 0,\n      \"message\": \"修改成功\",\n      \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"status_code\": 400,\n  \"message\": {\n      \"修改失败\"\n   },\n  \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/UserController.php",
    "groupTitle": "Auth",
    "name": "PatchPassword"
  },
  {
    "type": "post",
    "url": "/auth/token/new",
    "title": "刷新token(refresh token)",
    "description": "<p>刷新token(refresh token)</p>",
    "group": "Auth",
    "permission": [
      {
        "name": "JWT"
      }
    ],
    "version": "1.0.0",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Authorization",
            "description": "<p>用户旧的jwt-token, value已Bearer开头</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Header-Example:",
          "content": "{\n  \"Authorization\": \"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjEsImlzcyI6Imh0dHA6XC9cL21vYmlsZS5kZWZhcmEuY29tXC9hdXRoXC90b2tlbiIsImlhdCI6IjE0NDU0MjY0MTAiLCJleHAiOiIxNDQ1NjQyNDIxIiwibmJmIjoiMTQ0NTQyNjQyMSIsImp0aSI6Ijk3OTRjMTljYTk1NTdkNDQyYzBiMzk0ZjI2N2QzMTMxIn0.9UPMTxo3_PudxTWldsf4ag0PHq1rK8yO9e5vqdwRZLY\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"status_code\": 0,\n      \"message\": \"刷新token成功\",\n      \"data\": {\n         \"token\": \"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA\"\n      }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AuthController.php",
    "groupTitle": "Auth",
    "name": "PostAuthTokenNew"
  },
  {
    "type": "post",
    "url": "/login",
    "title": "登录(login)",
    "description": "<p>登录(login)</p>",
    "group": "Auth",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "area_code",
            "description": "<p>手机区号</p>"
          },
          {
            "group": "Parameter",
            "type": "Mobile",
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"status_code\": 0,\n      \"message\": \"登陆成功\",\n      \"data\": {\n         \"token\": \"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA\"\n      }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 500\n{\n     \"status_code\": 500,\n     \"message\": \"登陆失效\",\n     \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AuthController.php",
    "groupTitle": "Auth",
    "name": "PostLogin"
  },
  {
    "type": "post",
    "url": "/register",
    "title": "注册(register)",
    "description": "<p>注册(register)</p>",
    "group": "Auth",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "area_code",
            "description": "<p>国际手机区号</p>"
          },
          {
            "group": "Parameter",
            "type": "Mobile",
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号[unique]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "password",
            "description": "<p>密码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code_key",
            "description": "<p>发送短信后服务端返回的短信key</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>短信验证码</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nickname",
            "description": "<p>昵称</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "sex",
            "description": "<p>性别</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "birth",
            "description": "<p>生日</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"status_code\": 0,\n      \"message\": \"注册成功\",\n      \"data\": {\n         \"token\": \"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA\"\n      }\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"status_code\": 400,\n  \"message\": {\n      \"The mobile has already been taken.\"\n   },\n  \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/AuthController.php",
    "groupTitle": "Auth",
    "name": "PostRegister"
  },
  {
    "type": "put",
    "url": "/user",
    "title": "修改用户信息(user)",
    "description": "<p>修改用户信息(user)</p>",
    "group": "Auth",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "nickname",
            "description": "<p>昵称</p>"
          },
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "sex",
            "description": "<p>性别</p>"
          },
          {
            "group": "Parameter",
            "type": "Date",
            "optional": false,
            "field": "birth",
            "description": "<p>生日</p>"
          },
          {
            "group": "Parameter",
            "type": "Url",
            "optional": false,
            "field": "avatar",
            "description": "<p>头像</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "description",
            "description": "<p>个性签名</p>"
          },
          {
            "group": "Parameter",
            "type": "double",
            "optional": false,
            "field": "height",
            "description": "<p>身高</p>"
          },
          {
            "group": "Parameter",
            "type": "double",
            "optional": false,
            "field": "weight",
            "description": "<p>体重</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "profession",
            "description": "<p>职业</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "income",
            "description": "<p>收入</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n      \"status_code\": 0,\n      \"message\": \"修改成功\",\n      \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 400 Bad Request\n{\n  \"status_code\": 400,\n  \"message\": {\n      \"修改失败\"\n   },\n  \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/UserController.php",
    "groupTitle": "Auth",
    "name": "PutUser"
  },
  {
    "type": "get",
    "url": "/collect/items",
    "title": "收藏列表",
    "description": "<p>收藏列表</p>",
    "group": "Collect",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "uid",
            "description": "<p>用户id</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/collect/items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 100007,\n          \"nickname\": \"nick-567\",\n          \"sex\": \"女\",\n          \"age\": \"24岁数\",\n          \"height\": \"1.78cm\",\n          \"weight\": \"45.5kg\",\n          \"cover-video\": \"xxxx.mp4\"\n      },\n      {\n          \"id\": 100008,\n          \"nickname\": \"nick-457\",\n          \"sex\": \"女\",\n          \"age\": \"26岁数\",\n          \"height\": \"1.57cm\",\n          \"weight\": \"42.5kg\",\n          \"cover-video\": \"xxxx.mp4\"\n      },\n      {\n          \"id\": 100009,\n          \"nickname\": \"nick-678\",\n          \"sex\": \"女\",\n          \"age\": \"27岁数\",\n          \"height\": \"1.82cm\",\n          \"weight\": \"45.7kg\",\n          \"cover-video\": \"xxxx.mp4\"\n      },\n      {\n          \"id\": 100010,\n          \"nickname\": \"nick-778\",\n          \"sex\": \"女\",\n          \"age\": \"18岁数\",\n          \"height\": \"1.65cm\",\n          \"weight\": \"65.7kg\",\n          \"cover-video\": \"xxxx.mp4\"\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2079",
            "description": "<p>暂无收藏数据</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CollectController.php",
    "groupTitle": "Collect",
    "name": "GetCollectItems"
  },
  {
    "type": "post",
    "url": "/collect/add",
    "title": "收藏添加",
    "description": "<p>收藏添加</p>",
    "group": "Collect",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "from_uid",
            "description": "<p>收藏者id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "to_uid",
            "description": "<p>目标id</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/collect/add",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\nHTTP/1.1 200 OK\n{\n   \"status_code\": \"200\",\n   \"message\": \"ok\",\n   \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2149",
            "description": "<p>收藏失败</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "23002",
            "description": "<p>重复收藏用户</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "20467",
            "description": "<p>该用户非服务者</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CollectController.php",
    "groupTitle": "Collect",
    "name": "PostCollectAdd"
  },
  {
    "type": "post",
    "url": "/collect/delete",
    "title": "收藏删除",
    "description": "<p>收藏删除</p>",
    "group": "Collect",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "from_uid",
            "description": "<p>收藏者id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "to_uid",
            "description": "<p>目标id</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/collect/delete",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n {\n\t   \"status_code\": \"200\",\n\t   \"message\": \"ok\",\n\t   \"data\": []\n\t}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2137",
            "description": "<p>收藏删除失败</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CollectController.php",
    "groupTitle": "Collect",
    "name": "PostCollectDelete"
  },
  {
    "type": "get",
    "url": "/comment/add",
    "title": "评论服务者",
    "description": "<p>评论服务者</p>",
    "group": "Comment",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "from_uid",
            "description": "<p>评论者id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "to_uid",
            "description": "<p>目标id</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "content",
            "description": "<p>内容</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/comment/add",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n {\n   \"status_code\": \"200\",\n   \"message\": \"ok\",\n   \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "30690",
            "description": "<p>评论失败</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommentController.php",
    "groupTitle": "Comment",
    "name": "GetCommentAdd"
  },
  {
    "type": "get",
    "url": "/Comment/items",
    "title": "评论列表",
    "description": "<p>评论列表</p>",
    "group": "Comment",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "uid",
            "description": "<p>服务者的id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "page",
            "description": "<p>页码</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/comment/items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\nHTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": {\n      \"items\": [\n          {\n              \"id\": 1,\n              \"from_uid\": 10001,\n              \"type\": 1,\n              \"to_uid\": 10002,\n              \"content\": \"巨骚无敌的，bbbb\"\n          },\n          {\n              \"id\": 2,\n              \"from_uid\": 10001,\n              \"type\": 1,\n              \"to_uid\": 10002,\n              \"content\": \"骚的一批\"\n          },\n          {\n              \"id\": 3,\n              \"from_uid\": 10003,\n              \"type\": 1,\n              \"to_uid\": 10002,\n              \"content\": \"bbbjsj\"\n          },\n          {\n              \"id\": 4,\n              \"from_uid\": 10004,\n              \"type\": 1,\n              \"to_uid\": 10002,\n              \"content\": \"cccscd\"\n          },\n          {\n              \"id\": 5,\n              \"from_uid\": 10005,\n              \"type\": 1,\n              \"to_uid\": 10002,\n              \"content\": \"烂的很\"\n          }\n      ],\n      \"last_page\": 1,\n      \"total\": 5\n  }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "20790",
            "description": "<p>暂无评论数据</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommentController.php",
    "groupTitle": "Comment",
    "name": "GetCommentItems"
  },
  {
    "type": "get",
    "url": "common/captchas",
    "title": "图片验证码",
    "description": "<p>图片验证码</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/captchas",
        "type": "curl"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "allowedValues": [
              "+86..",
              "+096.."
            ],
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号</p>"
          }
        ]
      }
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "xx",
            "description": "<p>xx</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": {\n      \"key\": \"captcha-v41iNcwqFXpaH3Z\",\n      \"expire\": \"2019-08-23 00:52:50\",\n      \"_imageBase64\": \"data:image/jpeg;base64,/9j/4\"\n  }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonCaptchas"
  },
  {
    "type": "get",
    "url": "common/ry-token",
    "title": "融云token",
    "description": "<p>融云token</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/ry-token",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "xx",
            "description": "<p>xx</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": {\n     \"code\" => 200\n     \"userId\" => \"user_100034\"\n     \"token\" => \"r8EEHC+9X7sWW0K1yT8WVaDyOPSTa0PuyNs9Rz/CbjWmyMIisnVaU3HHHYBsACosFb22QetKv9b19FiXG3cyEtpX8Q1234Tr\"\n  }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonRyToken"
  },
  {
    "type": "get",
    "url": "/common/startup",
    "title": "开机动画",
    "description": "<p>开机动画</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/startup",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "1077",
            "description": "<p>暂无开机动画</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\n. HTTP/1.1 200 OK\n{\n      \"status_code\": \"200\",\n      \"message\": \"ok\",\n      \"data\": {\n          \"startup\": {\n              \"id\": 1,\n              \"type\": 1,\n              \"title\": \"1\",\n              \"ad_path\": \"https://http://images.appt.dev.com/*startup/39/ed/1239ed229c10cc9bc7bbabf6b8609e9a07cd156242.ceb\",\n              \"href\": \"http://www.baidu.com\",\n              \"status\": 1,\n              \"created_at\": \"2019-07-25 09:34:32\",\n              \"updated_at\": \"2019-05-29 12:05:53\",\n              \"deleted_at\": null\n          }\n      }\n }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonStartup"
  },
  {
    "type": "get",
    "url": "common/sys-notice",
    "title": "系统公告",
    "description": "<p>系统公告</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/startup",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "1099",
            "description": "<p>暂无系统公告</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 1,\n          \"msg\": \"公告请注意！\",\n          \"type\": \"system\",\n          \"created_at\": \"2019-04-29 08:26:11\",\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonSysNotice"
  },
  {
    "type": "get",
    "url": "common/upload-token",
    "title": "七牛上传token",
    "description": "<p>上传token</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/upload-token",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "xx",
            "description": "<p>xx</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": {\n      \"upload_token\": \"captcha-v41iNcwqFXpaH3Z\",\n  }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonUploadToken"
  },
  {
    "type": "get",
    "url": "/common/version",
    "title": "版本更新",
    "description": "<p>版本更新</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/startup",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "1088",
            "description": "<p>暂无最新版本</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": {\n      \"id\": 1,\n      \"title\": \"android\",\n      \"platform\": \"A\",\n      \"force\": 0,\n      \"version_code\": \"1.0.0\",\n      \"package_path\": \"http://video-ss.oss-cn-hongkong.aliyuncs.com/packages/2019-04-26-23-39-05-5cc32619e5b0b.apk\",\n      \"status\": 1,\n      \"lose\": 0,\n      \"remark\": \"\",\n      \"created_at\": \"2019-04-17 22:30:05\",\n      \"updated_at\": \"2019-04-30 08:33:23\",\n      \"deleted_at\": null\n  }\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "GetCommonVersion"
  },
  {
    "type": "post",
    "url": "common/check-code",
    "title": "校验验证码",
    "description": "<p>校验验证码</p>",
    "group": "Common",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Int",
            "optional": false,
            "field": "area_code",
            "description": "<p>国际区号[不要+号]</p>"
          },
          {
            "group": "Parameter",
            "type": "Mobile",
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号[unique]</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code_key",
            "description": "<p>发送短信后服务端返回的短信key</p>"
          },
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "code",
            "description": "<p>验证码</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/check-code",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "xx",
            "description": "<p>xx</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "\nHTTP/1.1 200 OK\n{\n  \"status_code\": \"200\",\n  \"message\": \"验证成功\",\n  \"data\": []\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "PostCommonCheckCode"
  },
  {
    "type": "post",
    "url": "/common/send-code",
    "title": "发送验证码",
    "description": "<p>短信验证码</p>",
    "group": "Common",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "area_code",
            "description": "<p>区号</p>"
          },
          {
            "group": "Parameter",
            "type": "number",
            "optional": false,
            "field": "mobile",
            "description": "<p>手机号</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/common/send-code?mobile=138817**7",
        "type": "curl"
      }
    ],
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "1067",
            "description": "<p>短信发送失败</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "  HTTP/1.1 200 OK\n  {\n      \"status_code\": \"200\",\n      \"message\": \"ok\",\n      \"data\": {\n          \"key\": \"verificationCode_6zdtva6rvLL42sT\",\n          \"expired\": \"2019-08-22T13:02:33.353172Z\"\n      }\n  }\n\n#开发测试环境\ncode 88899",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/CommonController.php",
    "groupTitle": "Common",
    "name": "PostCommonSendCode"
  },
  {
    "type": "get",
    "url": "/feed/items",
    "title": "意见反馈分类",
    "description": "<p>意见反馈分类</p>",
    "group": "Feed",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/feed/items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n  {\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"key\": \"other\",\n          \"name\": \"其他\"\n      },\n      {\n          \"key\": \"add-service\",\n          \"name\": \"加入服务\"\n      },\n      {\n          \"key\": \"withraw-deposit\",\n          \"name\": \"提现\"\n      },\n      {\n          \"key\": \"payment\",\n          \"name\": \"支付\"\n      },\n      {\n          \"key\": \"send-order\",\n          \"name\": \"发单\"\n      },\n      {\n          \"key\": \"grab-order\",\n          \"name\": \"抢单\"\n      },\n      {\n          \"key\": \"custom-serice\",\n          \"name\": \"客户\"\n      }\n   ]\n  }",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/FeedBackController.php",
    "groupTitle": "Feed",
    "name": "GetFeedItems"
  },
  {
    "type": "post",
    "url": "/feed/create",
    "title": "问题创建",
    "description": "<p>问题创建</p>",
    "group": "Feed",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "array",
            "allowedValues": [
              "['问题1'",
              "问题2].."
            ],
            "optional": false,
            "field": "keys",
            "description": "<p>问题分类key</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/feed/items",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2089",
            "description": "<p>问题创建失败</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/FeedBackController.php",
    "groupTitle": "Feed",
    "name": "PostFeedCreate"
  },
  {
    "type": "get",
    "url": "/home/scenes",
    "title": "首页推荐场景",
    "description": "<p>首页推荐场景</p>",
    "group": "Scenes",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/home/scenes",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n\n{\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 40095,\n          \"sort\": 1,\n          \"title\": \"美食\",\n          \"cid\": 40060,\n          \"icon\": \"/test7/default.jpg\",\n          \"background_chart\": \"/test7/default2.jpg\",\n          \"tags\": [\n              {\n                  \"id\": 40097,\n                  \"sort\": 3,\n                  \"title\": \"川菜\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back/ii.jpg\"\n              },\n              {\n                  \"id\": 40098,\n                  \"sort\": 4,\n                  \"title\": \"牛排\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back/zz.jpg\"\n              }\n          ]\n      },\n      {\n          \"id\": 40096,\n          \"sort\": 2,\n          \"title\": \"酒吧\",\n          \"cid\": 40060,\n         \"icon\": \"/test7/default1.jpg\",\n          \"background_chart\": \"/test7/default2.jpg\",\n          \"tags\": [\n              {\n                  \"id\": 40095,\n                  \"sort\": 1,\n                  \"title\": \"夜店 ktv\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back/yy.jpg\"\n              },\n              {\n                  \"id\": 40096,\n                  \"sort\": 2,\n                  \"title\": \"喝酒\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back/xx.jpg\"\n              },\n              {\n                  \"id\": 40099,\n                  \"sort\": 5,\n                  \"title\": \"约炮\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back2/jjj.jpg\"\n              }\n          ]\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2049",
            "description": "<p>暂无场景分类数据</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2037",
            "description": "<p>暂无场景数据</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2027",
            "description": "<p>暂无场景标签数据</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/SceneController.php",
    "groupTitle": "Scenes",
    "name": "GetHomeScenes"
  },
  {
    "type": "get",
    "url": "/scene/cate-itmes",
    "title": "获取场景分类",
    "description": "<p>场景列表</p>",
    "group": "Scenes",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/scene/cate-itme",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n {\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n   \"data\": [\n      {\n          \"id\": 40060,\n          \"sort\": 1,\n          \"title\": \"推荐\",\n          \"icon\": \"/test4/default.jpg\",\n      },\n      {\n          \"id\": 40057,\n          \"sort\": 2,\n          \"title\": \"运动健身\",\n          \"icon\": \"/test/default.jpg\",\n      },\n      {\n          \"id\": 40058,\n          \"sort\": 3,\n          \"title\": \"休闲娱乐\",\n          \"icon\": \"/test2/default.jpg\",\n      },\n      {\n          \"id\": 40059,\n          \"sort\": 4,\n          \"title\": \"生活美容\",\n          \"icon\": \"/test3/default.jpg\",\n      }\n  ]\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2049",
            "description": "<p>暂无分类场景</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/SceneController.php",
    "groupTitle": "Scenes",
    "name": "GetSceneCateItmes"
  },
  {
    "type": "get",
    "url": "/scenes/cate-below-itmes",
    "title": "获取分类下的场景集",
    "description": "<p>获取获取分类下的场景集</p>",
    "group": "Scenes",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "cid",
            "description": "<p>分类id</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/scenes/cate-below-itmes",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n {\n  \"status_code\": \"200\",\n  \"message\": \"ok\",\n  \"data\": [\n      {\n          \"id\": 40098,\n          \"sort\": 3,\n          \"title\": \"夜跑\",\n          \"cid\": 40057,\n          \"icon\": \"/test/defaul.jpg\",\n          \"background_chart\": \"/test/default5.jpg\",\n          \"tags\": [\n              {\n                  \"id\": 40100,\n                  \"sort\": 6,\n                  \"title\": \"谈心\",\n                  \"icon\": \"\",\n                  \"background_chart\": \"/test/back6/hh.jpg\"\n              }\n          ]\n      }\n  ]\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2037",
            "description": "<p>暂无场景数据</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2027",
            "description": "<p>暂无场景标签数据</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/SceneController.php",
    "groupTitle": "Scenes",
    "name": "GetScenesCateBelowItmes"
  },
  {
    "type": "get",
    "url": "/servant/apply",
    "title": "申请服务者",
    "description": "<p>申请服务者</p>",
    "group": "Servant",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "uid",
            "description": "<p>用户ID</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "id_card",
            "description": "<p>身份证   {'front':'正面.jpg', 'negative':'反面.jpg'}</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "p_v",
            "description": "<p>宣传视频 {'item1':'xxxx.mp4', 'item2':'xx.mp4','item3':'xx4.mp4'}</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "cover_img",
            "description": "<p>封面图片地址</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/servant/apply",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n  {\n      \"status_code\": \"200\",\n      \"message\": \"ok\",\n      \"data\":[]\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2127",
            "description": "<p>申请加入服务者失败</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "23001",
            "description": "<p>重复申请加入服务者错误</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/ServantController.php",
    "groupTitle": "Servant",
    "name": "GetServantApply"
  },
  {
    "type": "get",
    "url": "/servant/labelld",
    "title": "为服务者贴标签",
    "description": "<p>为服务者贴标签</p>",
    "group": "Servant",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "uid",
            "description": "<p>服务者id</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "tags",
            "description": "<p>标签iD   [40096,40097,40100]</p>"
          }
        ]
      }
    },
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/servant/labelld",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\nHTTP/1.1 200 OK\n{\n   \"status_code\": \"200\",\n   \"message\": \"ok\",\n   \"data\": []\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "33001",
            "description": "<p>重复添加标签错误</p>"
          },
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "31270",
            "description": "<p>标签添加失败</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/ServantController.php",
    "groupTitle": "Servant",
    "name": "GetServantLabelld"
  },
  {
    "type": "get",
    "url": "/servant/tags",
    "title": "获取服务者标签库",
    "description": "<p>获取服务者表情库</p>",
    "group": "Servant",
    "permission": [
      {
        "name": "none"
      }
    ],
    "version": "1.0.0",
    "examples": [
      {
        "title": "访问示例：",
        "content": "curl -i http://apis.appt.dev.0nt1.com/servant/tags",
        "type": "curl"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Int",
            "optional": false,
            "field": "code",
            "description": "<p>请求成功code为200</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Response 200 Example",
          "content": "注:该接口需要用户Token验证\n\n HTTP/1.1 200 OK\n  {\n      \"status_code\": \"200\",\n      \"message\": \"ok\",\n      \"data\": [\n          {\n              \"id\": 40095,\n              \"sort\": 1,\n              \"title\": \"活泼可爱\"\n          },\n          {\n              \"id\": 40096,\n              \"sort\": 2,\n              \"title\": \"性感撩人\"\n          },\n          {\n              \"id\": 40097,\n              \"sort\": 3,\n              \"title\": \"巨骚无比\"\n          },\n          {\n              \"id\": 40098,\n              \"sort\": 4,\n              \"title\": \"小萝莉\"\n          }\n      ]\n  }",
          "type": "json"
        }
      ]
    },
    "error": {
      "fields": {
        "通用Code码 xxx": [
          {
            "group": "通用Code码 xxx",
            "optional": false,
            "field": "2147",
            "description": "<p>暂无标签数据</p>"
          }
        ]
      }
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/ServantController.php",
    "groupTitle": "Servant",
    "name": "GetServantTags"
  },
  {
    "type": "get",
    "url": "/user",
    "title": "用户信息(user)",
    "description": "<p>用户信息(user)</p>",
    "group": "User",
    "permission": [
      {
        "name": "none"
      }
    ],
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "None",
            "optional": false,
            "field": "none",
            "description": ""
          }
        ]
      }
    },
    "version": "1.0.0",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n     \"status_code\": 0,\n     \"message\": \"\",\n     \"data\": {\n         \"id\": \"100024\",\n         \"nick_name\": \"\",\n         \"mobile\": \"13613613118\",\n         \"score\": \"\",\n         \"sex\": \"\",\n         \"birth\": \"\",\n         \"age\": \"\",\n         \"height\": \"\",\n         \"weight\": \"\",\n         \"profession\": \"\",\n         \"income\": \"\",\n         \"balance\": \"\",\n         \"last_login_at\": \"2019-08-22 16:17:25\"\n     }\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "HTTP/1.1 401 Not Found\n{\n  \"error\": \"UserNotFound\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "/workspace-0nt1/http/apis/api.appt.dev/src/app/Http/Controllers/Api/V1/UserController.php",
    "groupTitle": "User",
    "name": "GetUser"
  }
] });
