<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$api = app('Dingo\Api\Routing\Router');

$api->version('v1', [
    'namespace' => 'App\Http\Controllers\Api\V1',
], function ($api) {

    $api->post('register', 'AuthController@register');
    $api->post('login', 'AuthController@login');
    
    $api->group(['prefix' => 'common'], function($api)
    {
        //短信验证码
        $api->post('send-code', 'CommonController@sendVerificationCode');

        //验证验证码
        $api->post('check-code', 'CommonController@checkMobileCode');

        //开机动画
        $api->get('startup', 'CommonController@getStartup');

        //版本更新
        $api->get('version', 'CommonController@getNewVersion');

        //系统公告
        $api->get('sys-notice', 'CommonController@getNewSysNotice');

        //图片验证码
        $api->get('captchas', 'CommonController@getCaptchas');

        //上传token
        $api->get('upload-token',[
            'middleware' => 'auth:api',
            'uses' => 'CommonController@getQiniuToken'
        ]);

        //上传token
        $api->get('ry-token',[
            'middleware' => 'auth:api',
            'uses' => 'CommonController@getRongyunToken'
        ]);

    });

    $api->group(['middleware' => 'auth:api'], function($api)
    {
        $api->get('user', 'UserController@user');

        $api->put('user', 'UserController@patch');

        $api->patch('password', 'UserController@editPassword');
    });
    $api->get('/',function(){return response()->json('403 Forbidden', 403);});
});


/**
 * items for v2
 */
$api->version('v2', [
    'namespace' => 'App\Http\Controllers\Api\V1',
], function ($api) {

    $api->group(['middleware' => 'auth:api'], function($api) {
        /**
         * 广告路由
         * 
         * 1.首页广告
         * 2.登陆广告
         * 3.钱包广告
         * 4.申请加入服务者广告
         */
        $api->get('home/ad-items','AdController@getHomeAdItems');
        $api->get('login/ad-items','AdController@getLoginAdItems');
        $api->get('wallet/ad-items','AdController@getWalletAdItems');
        $api->get('apply-servant/ad-item','AdController@getApplyServantAdItems');

        /**
         * 意见反馈路由
         * 
         * 1.问题分类
         * 2.问题创建
         */
        $api->get('feed/items','FeedBackController@getQuestionCatItems');
        $api->post('feed/create','FeedBackController@create');

        /**
         * 首页场景
         *
         * 1.推荐场景       home/scenes
         * 2.获取分类下的场景 scenes/items
         * 3.场景分类       scenes/category
         * 
         */
        $api->get('home/scene','SceneController@getRecommendedItems');
        $api->get('scene/cate-below-itmes','SceneController@getCategoryBelowItems');
        $api->get('scene/cate-itmes','SceneController@getCategoryItems');
        //$api->post('scene/create','SceneController@create');
        

        /**
         * 服务者
         *
         * 1.申请加入服务者   
         * 2.服务者标签
         * 3.服务者打标签   
         */
        
        $api->post('servant/apply','ServantController@apply');
        $api->get('servant/tags','ServantController@getTags'); 
        $api->post('servant/labelld','ServantController@labelld');

        /**
         *           
         * 1.收藏列表
         * 2.收藏添加
         * 3.收藏删除
         */
        $api->post('collect/add','CollectController@add');
        $api->post('collect/delete','CollectController@delete');
        $api->get('collect/items','CollectController@items');

        /**
         *           
         * 1.评论添加
         * 2.评论列表
         * 
         */
         $api->post('comment/add','CommentController@add');
         $api->get('comment/items','CommentController@items');
         
    });

    /**
     * 公共路由
     * 
     * 1.短信验证码
     * 2.开机动画
     * 3.版本更新
     * 4.系统公告
     * 5.图片验证码
     */

    $api->get('common/verify-code','CommonController@sendVerificationCode');
    $api->get('common/startup','CommonController@getStartup');
    $api->get('common/version','CommonController@getNewVersion');
    $api->get('common/sys-notice','CommonController@getNewSysNotice');
    $api->get('common/captchas','CommonController@getCaptchas');

    
    /**
     * 默认禁止路由
     */
	$api->get('/',function(){return response()->json('403 Forbidden', 403);});	
});