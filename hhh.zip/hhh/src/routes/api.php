<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/
$router->group(['namespace' => 'App'], function () use ($router) {

    //设置
    $router->post('setting','SettingController@version');

    //用户管理
    $router->post('user_login', 'LoginController@loginApp');
    $router->post('pass_login', 'LoginController@LoginByPass');
    $router->post('send_message', 'LoginController@sendMessage');
    $router->post('third_login', 'LoginController@thirdLogin');
    $router->post('third_bind', 'LoginController@thirdBind');
    $router->post('check_code', 'LoginController@checkCode');
    $router->post('reset_pass', 'UserController@resetPassWord');

    //GOODS
    $router->post('get_subject', 'GoodsController@getBanner');
    $router->post('goods_list', 'GoodsController@getGoodsList');
    $router->post('goods_category', 'GoodsController@getCategory');
    $router->post('taobao_search', 'GoodsController@getGoodsByTaoBao');
    $router->post('taobao_goods', 'GoodsController@getGoodsByQ');
    $router->post('get_keys', 'GoodsController@getHotKeys');
    $router->post('down_goods', 'GoodsController@downGoods');
    $router->post('order/get_tkl', 'GoodsController@getGoodsTkl');
    $router->post('share_goods', 'GoodsController@getShareGoods');
    $router->post('goods/subject_goods', 'GoodsController@subjectGoods');
    $router->post('goods/wuliao', 'GoodsController@getOptimusMaterial');

    //营销素材、赚钱学院
    $router->post('article', 'ArticleController@index');
    $router->post('matter', 'ArticleController@matter');
    $router->post('article/{id}', 'ArticleController@show');
    $router->post('matter/{id}', 'ArticleController@matterDetail');



    $router->group(['middleware' => 'app_token'], function () use ($router) {

        $router->group(['prefix' => 'user'], function () use ($router) {
            $router->post('fill_code', 'UserController@fillInCode');
            $router->post('update_info', 'UserController@updateUserInfo');
            $router->post('info', 'UserController@userInfo');
            $router->post('apply_cash', 'UserController@applyCash');
            $router->post('bind_cash', 'UserController@bindCash');
            $router->post('cash_info', 'UserController@cashInfo');
            $router->post('update_cash', 'UserController@updateCash');
            $router->post('bill', 'UserController@bill');
            $router->post('set_collect', 'UserController@setCollect');
            $router->post('get_browse', 'UserController@getBrowse');
            $router->post('del_collect', 'UserController@delCollect');
            $router->post('get_collect', 'UserController@getCollect');
            $router->post('agent', 'UserController@getAgent');
            $router->post('set_avatar', 'UserController@uploadAvatar');
            $router->post('day_info', 'UserController@dayInfo');
            $router->post('upgrade', 'UserController@upgrade');
            $router->post('apply_upgrade', 'UserController@upgradeApply');
            $router->post('recommend_info', 'UserController@recommendInfo');
            $router->post('get_red_pack', 'UserController@getRedPack');
        });

        $router->group(['prefix' => 'goods'], function () use ($router) {
            $router->post('detail', 'GoodsController@getGoodsDetail');
            $router->post('rate_url', 'GoodsController@getRateUrl');
            $router->post('get_tkl', 'GoodsController@getGoodsTkl');
            $router->post('share_callback', 'GoodsController@shareCallback');
        });

        $router->group(['prefix' => 'order'], function () use ($router) {
            $router->post('/list', 'OrderController@getOrdersByUid');
            $router->post('/agent', 'GoodsController@getRateUrl');
            $router->post('/bind', 'OrderController@bindOrder');
        });

        $router->group(['prefix' => 'duobao'], function () use ($router) {
            $router->post('index', 'StoreHouseController@index');
            $router->post('detail', 'StoreHouseController@detail');
            $router->post('list_prized', 'StoreHouseController@prized');
            $router->post('my_ticket', 'StoreHouseController@myTicket');
            $router->post('my_goods', 'StoreHouseController@myGoods');
            $router->post('joining', 'StoreHouseController@joining');
        });

        $router->group(['prefix' => 'taobao'], function () use ($router) {
            $router->post('refresh_token', 'TaoBaoController@refreshToken');
            $router->post('get_token', 'TaoBaoController@getToken');
        });

    });
});