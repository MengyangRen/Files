<?php

return [
    'encrypt_key'  => env('ENCRYPT_KEY'),
    'app_domain'   => env('APP_DOMAIN'),
    'upload_images_domain'=> env('UPLOAD_IMAGES_DOMAIN'),
    'ry_key' => env('RY_APP_KEY'),
    'ry_secret' => env('RY_APP_SECRET'),
];
