<?php 

return [
    // HTTP 请求的超时时间（秒）
    'timeout' => 5.0,

    // 默认发送配置
    'default' => [
        // 网关调用策略，默认：顺序调用
        'strategy' => \Overtrue\EasySms\Strategies\OrderStrategy::class,
        // 默认可用的发送网关
        'gateways' => [
            //'huyi',
             'yunpian',
            //'aliyun',
           
        ],
    ],
    // 可用的网关配置
    'gateways' => [
        'errorlog' => [
            'file' => '/tmp/easy-sms.log',
        ],
        'yunpian' => [
             'api_key' => env('YunPianAPiKey', '824f0ff2f71cab52936axxxxxxxxxx') ,
        ],
        // 'huyi' => [
        //     'api_id' => env('HUYI_API_ID'),
        //     'api_key' => env('HUYI_API_KEY'),
        //     'signature' => env('HUYI_SIGNATURE'),
        // ]
        /*
        'aliyun' => [
            'access_key_id' => '',
            'access_key_secret' => '',
            'sign_name' => '',
        ],*/
        //...
    ],
];
