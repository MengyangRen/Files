<?php

return [
    'REGISTER_ERROR'  => 10001,

];
