<?php

namespace App\Models;

class OrderModel extends BaseModel
{

    /**
     * @var $_instance null
     */
    private static  $_instance = null;

    /**
     * @return OrderModel|null
     */
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    protected $table = 'v_order';

    protected $primaryKey = "id";

    protected $fillable = [
        'order_no',
        'order_type',
        'order_event',
        'user_id',
        'recharge_id',
        'recharge_coins',
        'price',
        'status',
        'ip',
        'pay_status',
        'pay_type',
        'pay_price',
        'pay_gateway',
        'gateway_no',
        'paid_at',
        'device_type',
        'device_code',
    ];

}
