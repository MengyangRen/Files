<?php
namespace App\Models;
class AdModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "ad";
    protected $fillable = [
        'key', 'type', 'title', 'remark','path', 'redirect_url', 'sort', 'status'
    ];
    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ];
}
