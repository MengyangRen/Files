<?php
namespace App\Models;
use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;

class User extends Model implements AuthenticatableContract, AuthorizableContract,JWTSubject
{
    use Authenticatable, Authorizable;
    protected $table = 'users';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'nickname', 'avatar', 'area_code', 'mobile', 'password', 'description', 'score', 'balance', 'sex', 'birth',
        'age', 'height', 'weight', 'profession', 'income', 'status', 'last_login_at'
    ];
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
    // Rest omitted for brevity
    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }


   /**
     * 
     * In uid集 获取需要的用户
     * 
     * @param   array  $in    
     *  uid数组
     * @param   int  $status  
     *  状态标示
     * @return mixed  default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getNeedUserInfoInUids(array $in = null) {
        $field = ['id','nickname','sex','age','height','weight'];
        return $this
          ->where('status',1)
          ->whereIn('id',$in)
          ->get($field)
          ->toArray();
    }
    
    /**
     * 
     * 性别属性处理
     * @example
     * 
     * 条件 
     * 0:女 1:拿 
     *  
     */
    protected function getSexAttribute($value) { return empty($value)? '女': '男'; }
    
    /**
     * 
     * 身高属性处理
     * @example 
     * cm
     */
    protected function getHeightAttribute($value) { return ($value * 100).'cm'; }

    /**
     * 
     * 年龄属性处理
     * @example 
     * cm
     */
    protected function getAgeAttribute($value) { return $value.'岁数'; }

    /**
     * 
     * 体重属性处理
     * @example 
     * kg
     */
    protected function getWeightAttribute($value) { return $value.'kg'; }


}