<?php

namespace App\Models;

use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BaseModel extends Model
{
    public $timestamps = true;

    /**
     * 批量修改数据
     *
     * @param array $multipleData 添加数据（二维数组key=>value）
     * @return array|bool|int
     * @throws BusinessException
     */
    public function updateBatch($multipleData)
    {
        try {
            if (empty($multipleData)) {
                return error('batch_error');
            }
            $tableName = $this->getTable(); // 表名
            $firstRow  = current($multipleData);

            $updateColumn = array_keys($firstRow);
            // 默认以id为条件更新，如果没有ID则以第一个字段为条件
            $referenceColumn = isset($firstRow['id']) ? 'id' : current($updateColumn);
            unset($updateColumn[0]);
            // 拼接sql语句
            $updateSql = "UPDATE " . $tableName . " SET ";
            $sets      = [];
            $bindings  = [];
            foreach ($updateColumn as $uColumn) {
                $setSql = "`" . $uColumn . "` = CASE ";
                foreach ($multipleData as $data) {
                    $setSql .= "WHEN `" . $referenceColumn . "` = ? THEN ? ";
                    $bindings[] = $data[$referenceColumn];
                    $bindings[] = $data[$uColumn];
                }
                $setSql .= "ELSE `" . $uColumn . "` END ";
                $sets[] = $setSql;
            }
            $updateSql .= implode(', ', $sets);
            $whereIn   = collect($multipleData)->pluck($referenceColumn)->values()->all();
            $bindings  = array_merge($bindings, $whereIn);
            $whereIn   = rtrim(str_repeat('?,', count($whereIn)), ',');
            $updateSql = rtrim($updateSql, ", ") . " WHERE `" . $referenceColumn . "` IN (" . $whereIn . ")";
            // 传入预处理sql语句和对应绑定数据
            $result = DB::update($updateSql, $bindings);

            if ($result) return $result;

            return false;
        } catch (\Exception $e) {

            throw new BusinessException(
                ApiException::message(ApiException::EX_SERVER),
                ApiException::EX_SERVER
            );
        }
    }

    /**
     * 获取表名称 
     *
     * @return mixed  default string,
     *  else Exception
     *
     * @example
     *  
     */
    public function getTableName() 
    {
        return $this->table;
    }
}
