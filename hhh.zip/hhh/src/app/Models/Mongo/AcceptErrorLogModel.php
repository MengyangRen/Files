<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 2018/11/6
 * Time: 11:18 AM
 */

namespace App\Models\Mongo;

class AcceptErrorLogModel extends BaseModel
{

    protected $collection = 'accept_error_logs';

    protected $fillable = [
        'url',
        'method',
        'options',
        'request_code',
        'request_message',
        'response_code',
        'response_message',
    ];

}