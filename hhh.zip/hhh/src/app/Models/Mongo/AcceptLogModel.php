<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 2018/11/6
 * Time: 11:18 AM
 */

namespace App\Models\Mongo;

class AcceptLogModel extends BaseModel
{

    protected $collection = 'accept_logs';

    protected $fillable = [
        'data',
        'header',
    ];

}