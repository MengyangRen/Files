<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 2018/11/6
 * Time: 11:18 AM
 */

namespace App\Models\Mongo;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
//use Jenssegers\Mongodb\Eloquent\HybridRelations;
use Jenssegers\Mongodb\Eloquent\SoftDeletes;

class BaseModel extends Eloquent
{

    use SoftDeletes;

    protected $connection = 'mongodb';

    protected $primaryKey = '_id';

    public function fromDateTime($value)
    {
        return date('Y-m-d H:i:s');
    }

}