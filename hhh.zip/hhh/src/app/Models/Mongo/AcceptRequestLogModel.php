<?php
/**
 * Created by PhpStorm.
 * User: pro
 * Date: 2018/11/6
 * Time: 11:18 AM
 */

namespace App\Models\Mongo;

class AcceptRequestLogModel extends BaseModel
{

    /**
     * @var $_instance null
     */
    private static $_instance = null;

    /**
     *
     * getInstance
     *
     * @return Singleton|null
     */
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    protected $collection = 'accept_request_logs';

    protected $fillable = [
        'url',
        'method',
        'options',
        'client_ip',
    ];

    protected $dates = [
        'created_at', 'updated_at'
    ];

}