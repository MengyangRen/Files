<?php
namespace App\Models;
class RelationModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "relation";
    protected $fillable = [
        'from_uid','to_uid','type'
    ];
    protected $hidden = [
        'created_at','updated_at'
    ];

    /**
     *
     * 通过FormUid获取ToUid集合
     * 
     * @param array $condition
     *  查询条件
     * @return mixed  default number,
     *  else Exception
     *
     * @example
     *  
     */
    public function getToUidMapByFromUid(array $condition = null) {
        $items = $this
                   ->where($condition)
                   ->pluck('to_uid')
                   ->all();

        if (empty($items))
            throw new BusinessException(
                'There is no record for the time being',
                2049
            );
        
        return $items;
    }

}
