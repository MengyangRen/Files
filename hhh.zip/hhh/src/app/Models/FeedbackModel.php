<?php
namespace App\Models;
class FeedbackModel extends BaseModel
{
    private static $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "feedback";
    protected $primaryKey = "id";
    protected $fillable = [
        'remark', 'keys', 'status', 'pic', 'uid', 'ip'
    ];
}
