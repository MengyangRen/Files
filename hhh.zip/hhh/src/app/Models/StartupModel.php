<?php
namespace App\Models;

class StartupModel extends BaseModel
{

    /**
     * @var $_instance null
     */
    private static $_instance = null;

    /**
     * @return StartupModel|null
     */
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    protected $table = "startup";

    protected $primaryKey = "id";

    protected $fillable = [
        'title', 'ad_path', 'status', 'type', 'href'
    ];

}
