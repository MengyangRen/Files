<?php
namespace App\Models;
use App\Exceptions\BusinessException;

class SceneModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "scene";
    protected $fillable = [
    ];

    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ];

   /**
     * 
     * 通过分类ID获取场景数据集
     * 
     * @param   int  $cid  
     *  分类ID
     * @param   int  $status  
     *  状态标示
     * @return mixed  default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getSceneMapByCateID($cid = null) {
        $map = $this
                ->where(['cid'=>$cid])
                ->orderBy('sort', 'asc')
                ->get()
                ->toArray(); 

        if (empty($map))
            throw new BusinessException('No scene data yet',2037);

        return $map;
    }
    
   /**
     * 
     * 通过分类ID获取所属场景的所有标签
     * 
     * @param   int  $cid  
     *  分类ID
     * @param   int  $status  
     *  状态标示
     * @return mixed  default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getTagIdMapByCateID($cid = null,$status = null) {
        return $this
            ->where(['cid'=>$cid,'status'=>$status])
            ->orderBy('sort', 'asc')
            ->get('tids')
            ->toArray();
    }

    /**
     * 标签ids
     * 转换属性 
     */
    protected function getTidsAttribute($value) { return explode(',', $value); }


}
