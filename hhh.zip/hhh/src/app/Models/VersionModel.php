<?php
namespace App\Models;

class VersionModel extends BaseModel
{

    /**
     * @var $_instance null
     */
    private static $_instance = null;

    /**
     * @return VersionModel|null
     */
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    protected $table = "version";

    protected $primaryKey = "id";

    protected $fillable = [
        'title', 'remark', 'platform', 'force', 'lose', 'version_code', 'status', 'package_path',
    ];

    protected $casts = [
        'icon_path' => 'array',
    ];



}
