<?php
namespace App\Models;
use App\Exceptions\BusinessException;

class ServantTagModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "servant_tag";
    protected $fillable = [
    ];

    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ]; 
}