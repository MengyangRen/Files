<?php
namespace App\Models;
use App\Exceptions\BusinessException;
class SceneTagModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "scene_tag";
    protected $fillable = [
        'id','sort','title','icon','status'
    ];
    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ];

   /**
     * 
     * 获取标签集
     * 
     * @param   array  $in    
     *  id数组
     * @param   int  $status  
     *  状态标示
     * @return mixed  default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getTagMapInIds(array $in = null ,$status = null) {
         return $this
            ->where('status',$status)
            ->whereIn('id',$in)
            ->orderBy('sort', 'asc')
            ->get()
            ->toArray();
    }

}
