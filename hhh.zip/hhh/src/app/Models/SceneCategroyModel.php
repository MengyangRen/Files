<?php
namespace App\Models;
use App\Exceptions\BusinessException;

class SceneCategroyModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "scene_categroy";
    protected $fillable = [
        'id','sort','title','icon','status'
    ];
    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ];

    /**
     * 
     * 获取某个分类ID
     * 
     * @param array $condition
     *  查询条件
     * @return mixed  default number,
     *  else Exception
     *
     * @example
     *  
     */
    public function getCateIdByCondition(array $condition = null) {
        $model = $this->where($condition)->first('id');
        if (empty($model))
           throw new BusinessException('No scene classification data yet',2049);
        return $model->id; 
    }


     /**
     * 
     * 获取所有分类集
     * 
     * @param array $condition
     *  查询条件
     * @return mixed  default number,
     *  else Exception
     *
     * @example
     *  
     */
    public function getCateMapByCondition($condition = null) {
        $scm = SceneCategroyModel::getInstance()
            ->where($condition)
            ->orderBy('sort', 'asc')
            ->get();

        if ($scm->isEmpty()) 
            throw new BusinessException(
                'No scene classification data yet ',2049);        
        return $scm;
    }
}
