<?php
namespace App\Models;
use App\Exceptions\BusinessException;

class ServantModel extends BaseModel
{
    private static  $_instance = null;
    public static function getInstance () {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }
    protected $table = "servant";
    protected $fillable = [
        'uid',
        'status',
        'id_card',
        'propaganda_video',
        'cover_img',
    ];

    protected $hidden = [
        'created_at','updated_at','deleted_at','status'
    ]; 

    /**
     * 
     * In uid集 获取服务者的展示视频
     * 
     * @param   array  $in    
     *  uid数组
     * @param   int  $status  
     *  状态标示
     * @return mixed  default array,
     *  else Exception
     *
     * @example
     */  
    public function geVideosByUids(array $in = null) 
    {
        $field = ['propaganda_video'];
        $items = $this
          ->where('status',2)
          ->whereIn('uid',$in)
          ->pluck('propaganda_video')
          ->all();
        return $items;
    }

    /**
     * 
     * 身高属性处理
     * @example 
     * cm
     */
    protected function getPropagandaVideoAttribute($value) { 
        return json_decode($value,true);
    }

}