<?php
namespace App\Exceptions;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * 业务异常类
 * 
 * @author  m.y
 * @package src.Exceptions.HttpException
 * @eplain 当请求接口失败的时候，需要抛出异常类
 *
 */

class BusinessException extends \Exception
{

}