<?php
namespace App\Common;

use Cache;
use Illuminate\Support\Facades\Storage;
#use Basesvr\SimpleCommon\Utils\AES;

class Upload
{

    private static $_instance;

    const PATH_DEFAULT = 'default';

    const PATH_PHOTO   = 'photo'; //头像

    const PATH_IMAGES  = 'images';

    const PATH_UPLOADS = 'uploads';

    const PATH_PACKAGES = 'packages'; //包 apk

    const PATH_VIDEO_COVER   = 'video_cover'; //视频封面

    const PATH_VIDEO_SPECIAL = 'video_special'; //视频系列封面图

    const PATH_AD = 'ad'; //广告

    const PATH_TASK = 'task'; //任务图标

    const PATH_STARTUP = 'startup'; //开机动画

    const PATH_FEEDBACK    = 'feedback'; //反馈图片

    const PATH_ICON     = 'icon';


    /**
     *
     * getInstance
     *
     * @return Upload
     * @author Third
     */
    public static function getInstance ()
    {
        if (empty(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     *
     * upload
     *
     * @param $file
     * @param string $path
     * @return mixed
     */
    public static function upload ($file, $path = self::PATH_DEFAULT)
    {
        if ($file->isValid()){
            $ext = $file->getClientOriginalExtension();
            $realPath = $file->getRealPath();

            $filename = date('Y-m-d-H-i-s') . '-' . uniqid() . '.' . $ext;
            $fullpath = $path . '/' . $filename;

            Storage::put($fullpath, file_get_contents($realPath));

            // TODO 添加到表v_uploads

            return Storage::url($fullpath);
        }
    }

    /**
     * @param $file
     * @param string $path
     * @param bool $refer
     * @return mixed
     * @throws \Exception
     */
    public static function uploadEncrypt ($file, $path = self::PATH_DEFAULT, $refer = [])
    {

        $saveFile = self::file();

        $fullpath = $path . $saveFile['path'] . '/' . $saveFile['filename'];

        try {

            if (!empty($refer)){

                //$opt         =  array('http'=>array('header'=>"Referer: https://thumb-g.toomics.net"));
                $opt  = [
                    'http' => $refer
                ];

                $context     =  stream_context_create($opt);

                $fileContent =  file_get_contents($file,false, $context);

            }else{
                $fileContent = file_get_contents($file);
            }


        } catch (\Exception $e) {

            throw new \Exception($e->getMessage(), $e->getCode());

        }

        Storage::put($fullpath, AES::getInstance(config('sys.encryption_upload_key'))->encryptNotBase64($fileContent));

        return $saveFile['filename'];

    }

    /**
     * @param $file
     * @param string $path
     * @param bool $refer
     * @return mixed
     * @throws \Exception
     */
    public static function uploadEncryptGetSize ($file, $path = self::PATH_DEFAULT, $refer = [])
    {

        $saveFile = self::file();

        $fullPath = $path . $saveFile['path'] . '/' . $saveFile['filename'];

        try {
            if (!empty($refer)){

                //$opt         =  array('http'=>array('header'=>"Referer: https://thumb-g.toomics.net"));
                $opt  = [
                    'http' => $refer
                ];

                $context     =  stream_context_create($opt);

                $fileContent =  file_get_contents($file,false, $context);

                $info = getimagesizefromstring($fileContent);

            }else{
                $fileContent = file_get_contents($file);
            }

        } catch (\Exception $e) {

            throw new \Exception($e->getMessage(), $e->getCode());

        }

        $saveFile['width'] = $info[0] ?? 0;

        $saveFile['height'] = $info[1] ?? 0;

        Storage::put($fullPath, AES::getInstance(config('sys.encryption_upload_key'))->encryptNotBase64($fileContent));

        return $saveFile;

    }

    /**
     *
     * uploadDecrypt
     *
     * @param $file
     * @return string
     */
    public static function uploadDecrypt ($file)
    {

        $fileContent = file_get_contents($file);

        return AES::getInstance(config('sys.encryption_upload_key'))->decryptNotBase64($fileContent);

    }

    /**
     *
     * [hostid][level][dirstr][filename][suffix]
     *
     * @param $data
     * @param string $spide
     * @param int $depth
     * @return array
     * @throws \Exception
     */
    protected static function file (string $spide = '/', int $depth = 2) : array
    {

        $path = '';

        $filename = '';

        $hostid = 1; // todo 暂定是1

        for ($i = 1; $i <= $depth; $i++) {

            $str = self::randStr(2);

            $path .= '/' . $str;

            $filename .= $str;

        }

        $filename = $hostid . $depth . $filename . md5(microtime()) . mt_rand(1000,9999) . '.ceb';

        self::mkDirs($path);

        return [
            'filename' => $filename,
            'path'     => $path,
        ];

    }

    /**
     *
     * mkDirs
     *
     * @param $dir
     * @param int $mode
     * @return bool
     */
    protected static function mkDirs($dir, $mode = 0777)
    {

        if (is_dir($dir) || @mkdir($dir, $mode)) return TRUE;

        if (!self::mkDirs(dirname($dir), $mode)) return FALSE;

        return @mkdir($dir, $mode);

    }

    /**
     *
     * randStr
     *
     * @param int $length
     * @return string
     */
    protected static function randStr (int $length = 1)
    {

        $name = '';

        $str = '0123456789abcdef';

        for ($i = 1; $i <= $length; $i++) {

            $name .= $str[mt_rand(0, strlen($str)-1)];

        }

        return $name;

    }

    /**
     *
     * getUrl
     *
     * @param string $domain
     * @param string $filename
     * @param string $path
     * @return string
     */
    public static function getUrl (string $domain, string $filename, string $path) : string
    {

        if ($domain == '' || $domain == null || $filename == '' || $filename == null) return false;

        $hostId = substr($filename, 0, 1);

        $depth = substr($filename, 1, 1);

        $catalog = substr($filename, 2, $depth * 2);

        $uri = '/' . implode('/', str_split($catalog, 2)) . '/' . $filename;

        if (config('filesystems.default') == 'public') {
            $host = 'http://';
        }else{
            $host = 'https://';
        }

        $url = $host . $domain . '/' . $path . $uri;

        return $url;

    }

}