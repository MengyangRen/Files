<?php

namespace App\Http\Controllers\Api\V1;

use App\Services\CommonService;
use App\Services\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AuthController extends BaseController
{
    protected $user;

    protected $auth;

    public function __construct(UserService $user)
    {
        $this->user = $user;
    }

    /**
     * @api {post} /login 登录(login)
     * @apiDescription 登录(login)
     * @apiGroup Auth
     * @apiPermission none
     * @apiParam {Int}    area_code 手机区号
     * @apiParam {Mobile}  mobile   手机号码
     * @apiParam {String} password  密码
     * @apiVersion 1.0.0
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *           "status_code": 0,
     *           "message": "登陆成功",
     *           "data": {
     *              "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA"
     *           }
     *     }
     * @apiErrorExample {json} Error-Response:
     *     HTTP/1.1 500
     *     {
     *          "status_code": 500,
     *          "message": "登陆失效",
     *          "data": []
     *      }
     */
    public function login(Request $request)
    {
       $validator = Validator::make($request->all(), [
           'area_code' => ['required', 'int'],
           'mobile'    => ['required', 'int'],
           'password'  => ['required', 'string']
       ]);

        if ($validator->fails()) return error($validator->errors()->first());

        $data = $request->all();

        $result = $this->user->login($data);

        return returnData($result['status_code'], $result['message'], $result['data']);
    }

    /**
     * @api {post} /auth/token/new 刷新token(refresh token)
     * @apiDescription 刷新token(refresh token)
     * @apiGroup Auth
     * @apiPermission JWT
     * @apiVersion 1.0.0
     * @apiHeader {String} Authorization 用户旧的jwt-token, value已Bearer开头
     * @apiHeaderExample {json} Header-Example:
     *     {
     *       "Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjEsImlzcyI6Imh0dHA6XC9cL21vYmlsZS5kZWZhcmEuY29tXC9hdXRoXC90b2tlbiIsImlhdCI6IjE0NDU0MjY0MTAiLCJleHAiOiIxNDQ1NjQyNDIxIiwibmJmIjoiMTQ0NTQyNjQyMSIsImp0aSI6Ijk3OTRjMTljYTk1NTdkNDQyYzBiMzk0ZjI2N2QzMTMxIn0.9UPMTxo3_PudxTWldsf4ag0PHq1rK8yO9e5vqdwRZLY"
     *     }
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *           "status_code": 0,
     *           "message": "刷新token成功",
     *           "data": {
     *              "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA"
     *           }
     *     }
     */
    public function refreshToken()
    {
        $token = $this->auth->refresh();
        return $this->response->array(compact('token'));
    }

    /**
     * @api {post} /register 注册(register)
     * @apiDescription 注册(register)
     * @apiGroup Auth
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiParam {String} area_code  国际手机区号
     * @apiParam {Mobile} mobile     手机号[unique]
     * @apiParam {String} password   密码
     * @apiParam {String} code_key   发送短信后服务端返回的短信key
     * @apiParam {String} code       短信验证码
     * @apiParam {String} nickname   昵称
     * @apiParam {Int}    sex   性别
     * @apiParam {Date}   birth   生日
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *           "status_code": 0,
     *           "message": "注册成功",
     *           "data": {
     *              "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC8xMjcuMC4wLjE6NTAwMTFcL2FwaVwvdXNlcnMiLCJpYXQiOjE1NjY0NjA5MDUsImV4cCI6MTU2NjQ2NDUwNSwibmJmIjoxNTY2NDYwOTA1LCJqdGkiOiJZU3BqdU9UbUVxQUczVmd6Iiwic3ViIjoxMDAwMTUsInBydiI6IjIzYmQ1Yzg5NDlmNjAwYWRiMzllNzAxYzQwMDg3MmRiN2E1OTc2ZjcifQ.ZhQxu8Letc_-MUWE9Nc4cS94piQaespOp6QF63MHWtA"
     *           }
     *      }
     * @apiErrorExample {json} Error-Response:
     *     HTTP/1.1 400 Bad Request
     *     {
     *       "status_code": 400,
     *       "message": {
     *           "The mobile has already been taken."
     *        },
     *       "data": []
     *      }
     */
    public function register(Request $request, CommonService $service)
    {
        $validator = Validator::make($request->all(), [
            'area_code'=> 'required',
            'mobile'   => 'required|unique:users',
            'password' => 'required',
            'code_key' => 'required',
            'code'     => 'required',
            'nickname' => 'required',
            'sex'      => 'required|int',
            'birth'    => 'required|date',
        ]);

        if ($validator->fails()) return error($validator->errors()->first());

        if (!$service->checkMobileCode($request->all())) return error('验证码错误');

        $data = $request->all();

        $data['age'] = Carbon::parse($data['birth'])->diffInYears();

        $result = $this->user->register($data);

        return returnData($result['status_code'], $result['message'], $result['data']);
    }
}
