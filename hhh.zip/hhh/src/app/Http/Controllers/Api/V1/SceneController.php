<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\SceneService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Support\Facades\Validator;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   场景模块
 * 
 * @author   m.y
 * @package  App.Ad
 * @example
 *
 */
class SceneController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(SceneService $sceneService) 
    {
        $this->sceneService = $sceneService;
    }

    /**
     * 
     * @api {get} /home/scenes 首页推荐场景
     * @apiDescription 首页推荐场景
     * @apiGroup   Scenes
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/home/scenes
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2049 暂无场景分类数据
     * @apiError (通用Code码 xxx)  2037 暂无场景数据
     * @apiError (通用Code码 xxx)  2027 暂无场景标签数据
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 40095,
     *           "sort": 1,
     *           "title": "美食",
     *           "cid": 40060,
     *           "icon": "/test7/default.jpg",
     *           "background_chart": "/test7/default2.jpg",
     *           "tags": [
     *               {
     *                   "id": 40097,
     *                   "sort": 3,
     *                   "title": "川菜",
     *                   "icon": "",
     *                   "background_chart": "/test/back/ii.jpg"
     *               },
     *               {
     *                   "id": 40098,
     *                   "sort": 4,
     *                   "title": "牛排",
     *                   "icon": "",
     *                   "background_chart": "/test/back/zz.jpg"
     *               }
     *           ]
     *       },
     *       {
     *           "id": 40096,
     *           "sort": 2,
     *           "title": "酒吧",
     *           "cid": 40060,
     *          "icon": "/test7/default1.jpg",
     *           "background_chart": "/test7/default2.jpg",
     *           "tags": [
     *               {
     *                   "id": 40095,
     *                   "sort": 1,
     *                   "title": "夜店 ktv",
     *                   "icon": "",
     *                   "background_chart": "/test/back/yy.jpg"
     *               },
     *               {
     *                   "id": 40096,
     *                   "sort": 2,
     *                   "title": "喝酒",
     *                   "icon": "",
     *                   "background_chart": "/test/back/xx.jpg"
     *               },
     *               {
     *                   "id": 40099,
     *                   "sort": 5,
     *                   "title": "约炮",
     *                   "icon": "",
     *                   "background_chart": "/test/back2/jjj.jpg"
     *               }
     *           ]
     *       }
     *   ]
     *}
     * 
     */ 
    public function getRecommendedItems(Request $request) 
    {
        try {
            return returnData(
                '200',
                'ok',
                $this->sceneService->getRecommendedItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }


    /**
     * 
     * @api {get} /scenes/cate-below-itmes 获取分类下的场景集
     * @apiDescription  获取获取分类下的场景集
     * @apiGroup   Scenes
     * 
     * @apiPermission none 
     * @apiParam   {int}  cid  分类id
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/scenes/cate-below-itmes
     * 
     * @apiSuccess {Int} code请求成功code为200
    *  @apiError (通用Code码 xxx)  2037 暂无场景数据
     * @apiError (通用Code码 xxx)  2027 暂无场景标签数据
     * 
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *  {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 40098,
     *           "sort": 3,
     *           "title": "夜跑",
     *           "cid": 40057,
     *           "icon": "/test/defaul.jpg",
     *           "background_chart": "/test/default5.jpg",
     *           "tags": [
     *               {
     *                   "id": 40100,
     *                   "sort": 6,
     *                   "title": "谈心",
     *                   "icon": "",
     *                   "background_chart": "/test/back6/hh.jpg"
     *               }
     *           ]
     *       }
     *   ]
     * }
     */ 
    public function getCategoryBelowItems(Request $request) 
    {
        try {


            $validator = Validator::make($request->all(),[
                   'cid'   => 'required'
            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                 ApiException::EX_REQUEST_INVAL),
                 ApiException::EX_REQUEST_INVAL);

            return returnData(
                '200',
                'ok',
                $this->sceneService->getCategoryBelowItems($request->cid)
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {get} /scene/cate-itmes 获取场景分类
     * @apiDescription  场景列表
     * @apiGroup   Scenes
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/scene/cate-itme
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2049 暂无分类场景
     *      
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *  {
     *   "status_code": "200",
     *   "message": "ok",
     *    "data": [
     *       {
     *           "id": 40060,
     *           "sort": 1,
     *           "title": "推荐",
     *           "icon": "/test4/default.jpg",
     *       },
     *       {
     *           "id": 40057,
     *           "sort": 2,
     *           "title": "运动健身",
     *           "icon": "/test/default.jpg",
     *       },
     *       {
     *           "id": 40058,
     *           "sort": 3,
     *           "title": "休闲娱乐",
     *           "icon": "/test2/default.jpg",
     *       },
     *       {
     *           "id": 40059,
     *           "sort": 4,
     *           "title": "生活美容",
     *           "icon": "/test3/default.jpg",
     *       }
     *   ]
     *  }
     */ 
    public function getCategoryItems(Request $request) 
    {     
        try {
            return returnData(
                '200',
                'ok',
                $this->sceneService->getCategoryItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }
}