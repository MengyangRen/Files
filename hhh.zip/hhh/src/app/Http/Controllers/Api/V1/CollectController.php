<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\CollectService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Support\Facades\Validator;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  收藏模块
 * 
 * @author   m.y
 * @package  App.Collect
 * @example
 *
 */

class CollectController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(CollectService $collectService) 
    {
        $this->collectService = $collectService;
    }

    /**
     * 
     * @api {post} /collect/add 收藏添加
     * @apiDescription 收藏添加
     * 
     * @apiGroup   Collect
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * @apiParam   {int}    from_uid   收藏者id  
     * @apiParam   {int}    to_uid     目标id  
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/collect/add
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2149   收藏失败
     * @apiError (通用Code码 xxx)  23002  重复收藏用户
     * @apiError (通用Code码 xxx)  20467  该用户非服务者 
     * 
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     * HTTP/1.1 200 OK
     * {
	 *    "status_code": "200",
	 *    "message": "ok",
	 *    "data": []
	 *  }
     * 
     * 
     */ 
    public function add(Request $request) 
    {
        try {

            $validator = Validator::make($request->all(), [
                   'from_uid'   => 'required|integer',
                   'to_uid'     => 'required|integer'
            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                 ApiException::EX_REQUEST_INVAL),
                 ApiException::EX_REQUEST_INVAL);
                
            return returnData(
                '200',
                'ok',
                $this->collectService->add($request->all())
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }

    }
    
    /**
     * 
     * @api {post} /collect/delete 收藏删除
     * @apiDescription 收藏删除
     * @apiGroup   Collect
     * 
     * @apiPermission none 
     * @apiParam   {int}    from_uid   收藏者id  
     * @apiParam   {int}    to_uid     目标id  
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/collect/delete
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2137 收藏删除失败
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *  {
	 *	   "status_code": "200",
	 *	   "message": "ok",
	 *	   "data": []
	 *	}
     */ 
    public function delete(Request $request) 
    {
        try {

            $validator = Validator::make($request->all(), [
                   'from_uid'   => 'required|integer',
                   'to_uid'     => 'required|integer'
            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                 ApiException::EX_REQUEST_INVAL),
                 ApiException::EX_REQUEST_INVAL);
           
            return returnData(
                '200',
                'ok',
                $this->collectService->delete($request->all())
            );
        } catch (BusinessException $e) {
          	return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {get} /collect/items 收藏列表
     * @apiDescription 收藏列表
     * @apiGroup   Collect
     * 
     * @apiPermission none 
     * @apiParam   {int}  uid 用户id  
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/collect/items
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2079 暂无收藏数据
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *
     * {
	 *   "status_code": "200",
	 *   "message": "ok",
	 *   "data": [
	 *       {
	 *           "id": 100007,
	 *           "nickname": "nick-567",
	 *           "sex": "女",
	 *           "age": "24岁数",
	 *           "height": "1.78cm",
	 *           "weight": "45.5kg",
	 *           "cover-video": "xxxx.mp4"
	 *       },
	 *       {
	 *           "id": 100008,
	 *           "nickname": "nick-457",
	 *           "sex": "女",
	 *           "age": "26岁数",
	 *           "height": "1.57cm",
	 *           "weight": "42.5kg",
	 *           "cover-video": "xxxx.mp4"
	 *       },
	 *       {
	 *           "id": 100009,
	 *           "nickname": "nick-678",
	 *           "sex": "女",
	 *           "age": "27岁数",
	 *           "height": "1.82cm",
	 *           "weight": "45.7kg",
	 *           "cover-video": "xxxx.mp4"
	 *       },
	 *       {
	 *           "id": 100010,
	 *           "nickname": "nick-778",
	 *           "sex": "女",
	 *           "age": "18岁数",
	 *           "height": "1.65cm",
	 *           "weight": "65.7kg",
	 *           "cover-video": "xxxx.mp4"
	 *       }
	 *   ]
	 *}
     *  
     */ 
    public function items(Request $request) 
    {
        try {

			$validator = Validator::make($request->all(), [
				'uid'     => 'required|integer'
			]);

			if ($validator->fails()) 
			    throw new BusinessException(ApiException::message(
			     ApiException::EX_REQUEST_INVAL),
			     ApiException::EX_REQUEST_INVAL);

			return returnData(
			    '200',
			    'ok',
			    $this->collectService->items(
			    	$request->uid
			    )
			);

        } catch (BusinessException $e) {
          	return returnData($e->getCode(),$e->getMessage());
        }
    }
         
}