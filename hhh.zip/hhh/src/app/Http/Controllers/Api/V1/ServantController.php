<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\SceneService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Support\Facades\Validator;
use App\Services\ServantService;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   服务者模块
 * 
 * @author   m.y
 * @package  App.Servant
 * @example
 *
 */
class ServantController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(ServantService $servantService) 
    {
        $this->servantService = $servantService;
    }

    /**
     * 
     * @api {get} /servant/apply   申请服务者
     * @apiDescription 申请服务者
     * @apiGroup   Servant
     * 
     * @apiPermission none 
     * @apiParam  {int}     uid       用户ID
     * @apiParam  {json}    id_card   身份证   {'front':'正面.jpg', 'negative':'反面.jpg'}
     * @apiParam  {json}    p_v       宣传视频 {'item1':'xxxx.mp4', 'item2':'xx.mp4','item3':'xx4.mp4'}
     * @apiParam  {string}  cover_img 封面图片地址
     *  
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/servant/apply
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)   2127  申请加入服务者失败
     * @apiError (通用Code码 xxx)   23001 重复申请加入服务者错误
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *   {
     *       "status_code": "200",
     *       "message": "ok",
     *       "data":[]
     *   }
     * 
     */ 
    public function apply(Request $request) {
        try {

            $validator = Validator::make($request->all(),[
                'uid'      => 'required',
                'id_card'  => 'required | string',
                'p_v'      => 'required | string',
                'cover_img'=> 'required | string', 

            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                ApiException::EX_REQUEST_INVAL),
                ApiException::EX_REQUEST_INVAL);

            return returnData(
                '200',
                'ok',
                $this->servantService->apply($request->all())
            );

        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }
    
    /**
     * 
     * @api {get} /servant/tags   获取服务者标签库
     * @apiDescription 获取服务者表情库
     * @apiGroup   Servant
     * 
     * @apiPermission none 
     *  
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/servant/tags
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)   2147  暂无标签数据
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *   {
     *       "status_code": "200",
     *       "message": "ok",
     *       "data": [
     *           {
     *               "id": 40095,
     *               "sort": 1,
     *               "title": "活泼可爱"
     *           },
     *           {
     *               "id": 40096,
     *               "sort": 2,
     *               "title": "性感撩人"
     *           },
     *           {
     *               "id": 40097,
     *               "sort": 3,
     *               "title": "巨骚无比"
     *           },
     *           {
     *               "id": 40098,
     *               "sort": 4,
     *               "title": "小萝莉"
     *           }
     *       ]
     *   }
     * 
     */ 
    public function getTags() 
    {

        try {

            return returnData(
                '200',
                'ok',
                $this->servantService->getTags()
            );

        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }
     
    /**
     * 
     * @api {get} /servant/labelld   为服务者贴标签
     * @apiDescription 为服务者贴标签
     * @apiGroup   Servant
     * 
     * @apiPermission none 
     * @apiParam   {int}    uid       服务者id  
     * @apiParam   {json}   tags     标签iD   [40096,40097,40100]
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/servant/labelld
     * 
     * @apiSuccess {Int} code请求成功code为200
     * 
     * @apiError (通用Code码 xxx)   33001   重复添加标签错误
     * @apiError (通用Code码 xxx)   31270   标签添加失败
     *                             
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     * HTTP/1.1 200 OK
     * {
     *    "status_code": "200",
     *    "message": "ok",
     *    "data": []
     *  }
     * 
     */ 
    public function labelld(Request $request) 
    {
        try {

            $validator = Validator::make($request->all(),[
                'uid'   => 'required | integer',
                'tags'  => 'required | string',

            ]);  

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                ApiException::EX_REQUEST_INVAL),
                ApiException::EX_REQUEST_INVAL);

            return returnData(
                '200',
                'ok',
                $this->servantService->labelld([
                    'uid'  => $request->uid,
                    'tags' => \json_decode($request->tags)
                ])
            );

        } catch (BusinessException $e) {
           return returnData($e->getCode(),$e->getMessage());
        }

    }


}