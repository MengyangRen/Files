<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use Overtrue\EasySms\EasySms;
use App\Services\CommonService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;

use Illuminate\Support\Facades\Validator;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   公共控制器模块
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */
class CommonController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $commonService;
    private $easySms;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(CommonService $commonService,EasySms $easySms) 
    {
        $this->commonService = $commonService;
        $this->easySms = $easySms;
    }

    /**
     * 
     * @api {post} /common/send-code 发送验证码
     * @apiDescription 短信验证码
     * @apiGroup   Common
     * @apiPermission none
     * @apiParam   {number}   area_code  区号
     * @apiParam   {number}   mobile  手机号
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/send-code?mobile=138817**7
     * 
     * @apiError (通用Code码 xxx)  1067    短信发送失败
     * @apiSuccess {Int} code请求成功code为200
     * 
     * @apiSuccessExample {json} Response 200 Example
     *   HTTP/1.1 200 OK
     *   {
     *       "status_code": "200",
     *       "message": "ok",
     *       "data": {
     *           "key": "verificationCode_6zdtva6rvLL42sT",
     *           "expired": "2019-08-22T13:02:33.353172Z"
     *       }
     *   }
     *
     * #开发测试环境
     * code 88899
     * 
     */ 
    public function sendVerificationCode(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'area_code' => 'required|int',
                'mobile'    => 'required|int'
            ]);

            if ($validator->fails()) throw new BusinessException($validator->errors()->first(),ApiException::EX_REQUEST_INVAL);

            $mobile = '+' . $request->get('area_code') . $request->get('mobile');

            return returnData(
                200,
                '发送成功',
                $this->commonService->sendVerificationCode($mobile)
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }

    }

    /**
     * 
     * @api {get} /common/startup 开机动画
     * @apiDescription 开机动画
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/startup
     * 
     * @apiError (通用Code码 xxx)  1077   暂无开机动画
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     * 
     *. HTTP/1.1 200 OK
     * {
     *       "status_code": "200",
     *       "message": "ok",
     *       "data": {
     *           "startup": {
     *               "id": 1,
     *               "type": 1,
     *               "title": "1",
     *               "ad_path": "https://http://images.appt.dev.com/*startup/39/ed/1239ed229c10cc9bc7bbabf6b8609e9a07cd156242.ceb",
     *               "href": "http://www.baidu.com",
     *               "status": 1,
     *               "created_at": "2019-07-25 09:34:32",
     *               "updated_at": "2019-05-29 12:05:53",
     *               "deleted_at": null
     *           }
     *       }
     *  }
     * 
     */ 
    public function getStartup(Request $request)
    {
        try {
            return returnData(
                '200',
                'ok',
                $this->commonService->getStartup()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {get} /common/version 版本更新
     * @apiDescription 版本更新
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/startup
     * 
     * @apiError (通用Code码 xxx)  1088   暂无最新版本
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     * 
     * HTTP/1.1 200 OK
     * 
     *{
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": {
     *       "id": 1,
     *       "title": "android",
     *       "platform": "A",
     *       "force": 0,
     *       "version_code": "1.0.0",
     *       "package_path": "http://video-ss.oss-cn-hongkong.aliyuncs.com/packages/2019-04-26-23-39-05-5cc32619e5b0b.apk",
     *       "status": 1,
     *       "lose": 0,
     *       "remark": "",
     *       "created_at": "2019-04-17 22:30:05",
     *       "updated_at": "2019-04-30 08:33:23",
     *       "deleted_at": null
     *   }
     * }
     * 
     */ 
    public function getNewVersion(Request $request)
    {
        try {
            
            $validator = Validator::make($request->all(), [
                   'platform'   => 'required|in:I,A'
            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                 ApiException::EX_REQUEST_INVAL),
                 ApiException::EX_REQUEST_INVAL);
                
            return returnData(
                '200',
                'ok',
                $this->commonService->getNewVersion($request->platform)
            );

        } catch (BusinessException $e) {
           return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {get} common/sys-notice 系统公告
     * @apiDescription 系统公告
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/startup
     * 
     * @apiError (通用Code码 xxx)  1099   暂无系统公告
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     * 
     * HTTP/1.1 200 OK
     * 
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 1,
     *           "msg": "公告请注意！",
     *           "type": "system",
     *           "created_at": "2019-04-29 08:26:11",
     *       }
     *   ]
     * }
     *
     * 
     */ 
    public function getNewSysNotice(Request $request)
    {
        try {
            return returnData(
                '200',
                'ok',
                $this->commonService->getNewSysNotice()
            );
        } catch (BusinessException $e) {
           return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {get} common/captchas 图片验证码
     * @apiDescription 图片验证码
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/captchas
     * 
     * @apiParam   {number=+86..,+096..}    mobile      手机号  
     * @apiError (通用Code码 xxx)  xx   xx
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     * 
     * HTTP/1.1 200 OK
     *{
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": {
     *       "key": "captcha-v41iNcwqFXpaH3Z",
     *       "expire": "2019-08-23 00:52:50",
     *       "_imageBase64": "data:image/jpeg;base64,/9j/4"
     *   }
     * }
     * 
     */ 
    public function getCaptchas(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                   'mobile'   => 'required|string'
            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                 ApiException::EX_REQUEST_INVAL),
                 ApiException::EX_REQUEST_INVAL);

            return returnData(
                '200',
                'ok',
                $this->commonService->getCaptchas($request->get('mobile'))
            );
        } catch (BusinessException $e) {
           return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     *
     * @api {get} common/upload-token 七牛上传token
     * @apiDescription 上传token
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/upload-token
     *
     * @apiError (通用Code码 xxx)  xx   xx
     *
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     *
     * HTTP/1.1 200 OK
     *{
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": {
     *       "upload_token": "captcha-v41iNcwqFXpaH3Z",
     *   }
     * }
     *
     */
    public function getQiniuToken()
    {
        return returnData(
            200,
            'ok',
            [
                'upload_token' => $this->commonService->getUploadToken()
            ]
        );

    }

    /**
     *
     * @api {get} common/ry-token 融云token
     * @apiDescription 融云token
     * @apiGroup   Common
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/ry-token
     *
     * @apiError (通用Code码 xxx)  xx   xx
     *
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     *
     * HTTP/1.1 200 OK
     *{
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": {
     *      "code" => 200
     *      "userId" => "user_100034"
     *      "token" => "r8EEHC+9X7sWW0K1yT8WVaDyOPSTa0PuyNs9Rz/CbjWmyMIisnVaU3HHHYBsACosFb22QetKv9b19FiXG3cyEtpX8Q1234Tr"
     *   }
     * }
     *
     */
    public function getRongyunToken()
    {
        $result = $this->commonService->ryRegister();

        return returnData($result['status_code'], $result['message'], $result['data']);

    }

    /**
     *
     * @api {post} common/check-code 校验验证码
     * @apiDescription 校验验证码
     * @apiGroup   Common
     * @apiParam {Int}    area_code   国际区号[不要+号]
     * @apiParam {Mobile} mobile   手机号[unique]
     * @apiParam {String} code_key   发送短信后服务端返回的短信key
     * @apiParam {String} code   验证码
     * @apiVersion 1.0.0
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/common/check-code
     *
     * @apiError (通用Code码 xxx)  xx   xx
     *
     * @apiSuccess {Int} code请求成功code为200
     * @apiSuccessExample {json} Response 200 Example
     *
     * HTTP/1.1 200 OK
     *{
     *   "status_code": "200",
     *   "message": "验证成功",
     *   "data": []
     * }
     *
     */
    public function checkMobileCode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'area_code' => 'required|int',
            'mobile'    => 'required|int',
            'code_key'  => 'required|string',
            'code'      => 'required|string',
        ]);

        if ($validator->fails()) return error($validator->errors()->first());

        $result = $this->commonService->checkMobileCode($request->all());

        if ($result) return success([],'验证成功');

        return error('验证失败');

    }
}