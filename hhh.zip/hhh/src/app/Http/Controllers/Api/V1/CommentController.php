<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\CommentService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Support\Facades\Validator;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   评论模块
 * 
 * @author   m.y
 * @package  App.Servant
 * @example
 *
 */
class CommentController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(CommentService $commentService) 
    {
        $this->commentService = $commentService;
    }

    /**
     * 
     * @api {get} /comment/add  评论服务者
     * @apiDescription 评论服务者
     * @apiGroup   Comment
     * 
     * @apiPermission none 
     * @apiParam   {int}    from_uid   评论者id  
     * @apiParam   {int}    to_uid     目标id  
     * @apiParam   {string} content    内容
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/comment/add
     * 
     * @apiSuccess {Int} code请求成功code为200
     * 
     * @apiError (通用Code码 xxx)  30690 评论失败
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *  {
     *    "status_code": "200",
     *    "message": "ok",
     *    "data": []
     *  }
     */ 
    public function add(Request $request) {

        $validator = Validator::make($request->all(),[
            'from_uid'   => 'required | integer',
            'to_uid'     => 'required | integer',
            'content'    => 'required | string', 

        ]);  

        if ($validator->fails()) 
            throw new BusinessException(ApiException::message(
            ApiException::EX_REQUEST_INVAL),
            ApiException::EX_REQUEST_INVAL);

        return returnData(
            '200',
            'ok',
            $this->commentService->add($request->all())
        );

    }

    /**
     * 
     * @api {get} /Comment/items  评论列表
     * @apiDescription 评论列表
     * @apiGroup   Comment
     * 
     * @apiPermission none 
     * @apiParam   {int}   uid  服务者的id
     * @apiParam   {int}   page 页码
     *   
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/comment/items
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  20790 暂无评论数据
     *         
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     * HTTP/1.1 200 OK
     *{
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": {
     *       "items": [
     *           {
     *               "id": 1,
     *               "from_uid": 10001,
     *               "type": 1,
     *               "to_uid": 10002,
     *               "content": "巨骚无敌的，bbbb"
     *           },
     *           {
     *               "id": 2,
     *               "from_uid": 10001,
     *               "type": 1,
     *               "to_uid": 10002,
     *               "content": "骚的一批"
     *           },
     *           {
     *               "id": 3,
     *               "from_uid": 10003,
     *               "type": 1,
     *               "to_uid": 10002,
     *               "content": "bbbjsj"
     *           },
     *           {
     *               "id": 4,
     *               "from_uid": 10004,
     *               "type": 1,
     *               "to_uid": 10002,
     *               "content": "cccscd"
     *           },
     *           {
     *               "id": 5,
     *               "from_uid": 10005,
     *               "type": 1,
     *               "to_uid": 10002,
     *               "content": "烂的很"
     *           }
     *       ],
     *       "last_page": 1,
     *       "total": 5
     *   }
     *} 
     */
    public function items(Request $request) {

        $validator = Validator::make($request->all(),[
            'uid'     => 'required | integer',
            'page'    => 'required | integer'
        ]);  

        if ($validator->fails()) 
            throw new BusinessException(ApiException::message(
            ApiException::EX_REQUEST_INVAL),
            ApiException::EX_REQUEST_INVAL);

        return returnData(
            '200',
            'ok',
            $this->commentService->items($request->uid)
        );
    }
}