<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\FeedBackService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use Illuminate\Support\Facades\Validator;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   意见反馈
 * 
 * @author   m.y
 * @package  App.feedback
 * @example
 *
 */
class FeedBackController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * 
     */
    public function __construct(FeedBackService $feedBackService) 
    {
        $this->feedBackService = $feedBackService;
    }

    /**
     * 
     * @api {get} /feed/items 意见反馈分类
     * @apiDescription 意见反馈分类
     * @apiGroup   Feed
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/feed/items
     * 
     * @apiSuccess {Int} code请求成功code为200
     *      
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *   {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "key": "other",
     *           "name": "其他"
     *       },
     *       {
     *           "key": "add-service",
     *           "name": "加入服务"
     *       },
     *       {
     *           "key": "withraw-deposit",
     *           "name": "提现"
     *       },
     *       {
     *           "key": "payment",
     *           "name": "支付"
     *       },
     *       {
     *           "key": "send-order",
     *           "name": "发单"
     *       },
     *       {
     *           "key": "grab-order",
     *           "name": "抢单"
     *       },
     *       {
     *           "key": "custom-serice",
     *           "name": "客户"
     *       }
     *    ]
     *   }
     * 
     * 
     */ 
     public function getQuestionCatItems(Request $request) {
        try {
            return returnData(
                '200',
                'ok',
                $this->feedBackService->getQuestionCatItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }

    /**
     * 
     * @api {post} /feed/create 问题创建
     * @apiDescription 问题创建
     * @apiGroup   Feed
     * 
     * @apiPermission none 
     *
     * @apiParm    {int}                     uid      用户id 
     * @apiParam   {array=['问题1',问题2]..}  keys     问题分类key
     * @apiParm    {array=['图像1',图像2]..}  pic      问题图片 
     * @apiParm    {string}                  remark   问题描述 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/feed/items
     * 
     * @apiSuccess {Int} code请求成功code为200
     * 
     * @apiError (通用Code码 xxx)  2089   问题创建失败
     * 
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     *
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": []
     *  }
     * 
     */ 
     public function create(Request $request) {
        try {
            
            $validator = Validator::make($request->all(), [
                'uid'       => 'required',
                'keys'      => 'required',
                'pic'       => 'required',
                'remark'    => 'required|string'

            ]);

            if ($validator->fails()) 
                throw new BusinessException(ApiException::message(
                ApiException::EX_REQUEST_INVAL),
                ApiException::EX_REQUEST_INVAL);

            return returnData(
                '200',
                'ok',
                $this->feedBackService->create(
                    $request->uid,
                    $request->keys,
                    $request->pic,
                    $request->remark
                )
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
    }

}