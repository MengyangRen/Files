<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Services\AdService;
use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   广告模块
 * 
 * @author   m.y
 * @package  App.Ad
 * @example
 *
 */
class AdController extends BaseController
{

    /**
     *  公共服务对象
     * @var obj
     */
    private $Service;

    /**
     * 初始化
     * 
     * @param CommonService $commonService 
     *   公共服务对象
     * @param EasySms  $easySms  
     *   短信组件对象
     * 
     */
    public function __construct(AdService $adService) 
    {
        $this->adService = $adService;
    }

    /**
     * 
     * @api {get} /home/ad-items 首页广告
     * @apiDescription 首页广告
     * @apiGroup   Ad
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/home/ad-items
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (错误Code)  2049 暂无广告
     * 
     * @apiSuccessExample响应（示例）：
     * 注:该接口需要用户Token验证
     * 
     *  HTTP/1.1 200 OK
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 5,
     *           "key": "key5",
     *           "position": "HOME-BANNER-MODEL",
     *           "type": "LINK",
     *           "title": "广告3",
     *           "remark": "cc",
     *           "path": "/www/back5/default.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 3
     *       },
     *       {
     *           "id": 4,
     *           "key": "key4",
     *           "position": "HOME-BANNER-MODEL",
     *           "type": "LINK",
     *           "title": "首页广告2",
     *           "remark": "yy",
     *           "path": "/www/back4/default.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 2
     *       },
     *       {
     *           "id": 3,
     *           "key": "key3",
     *           "position": "HOME-BANNER-MODEL",
     *           "type": "LINK",
     *           "title": "首页广告",
     *           "remark": "xxx",
     *           "path": "/www/back3/default.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 1
     *       }
     *   ]
     *}
     * 
     */ 
     public function getHomeAdItems(Request $request) {
        try {
            return returnData(
                '200',
                'ok',
                $this->adService->getHomeAdItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
     }


    /**
     * 
     * @api {get} /login/ad-items 登陆广告
     * @apiDescription 登陆广告
     * @apiGroup   Ad
     * 
     * @apiPermission none 
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/login/ad-items
     *
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2049 赞无广告
     *  
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     *   HTTP/1.1 200 OK
     *   
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 1,
     *           "key": "key",
     *           "position": "LOGIN-MODEL",
     *           "type": "LINK",
     *           "title": "登陆模块广告1",
     *           "remark": "xx",
     *           "path": "/www/back/js.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 1,
     *           "status": 1,
     *           "created_at": "2019-08-25 21:04:10",
     *           "updated_at": null,
     *           "deleted_at": null
     *       }
     *   ]
     * }
     */ 
     public function getLoginAdItems(Request $request) {
        try {
            return returnData(
                '200',
                'ok',
                $this->adService->getLoginAdItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
     }

    /**
     * 
     * @api {get} /wallet/ad-items 钱包广告
     * @apiDescription 钱包广告
     * @apiGroup   Ad
     * 
     * @apiPermission none
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/wallet/ad-items
     * 
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2049 赞无广告
     *     
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     *   HTTP/1.1 200 OK
     *   
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 2,
     *           "key": "key2",
     *           "position": "WALLET-MODEL",
     *           "type": "LINK",
     *           "title": " 钱包模块广告",
     *           "remark": "xxx",
     *           "path": "/www/back2/jsd.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 2
     *       }
     *   ]
     *}
     */ 
     public function getWalletAdItems(Request $request) {
        try {
            return returnData(
                '200',
                'ok',
                $this->adService->getWalletAdItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
     }


    /**
     * 
     * @api {get} apply-servant/ad-item 申请服务者宣传广告
     * @apiDescription 申请服务者宣传广告
     * @apiGroup   Ad
     * 
     * @apiPermission none
     * @apiVersion 1.0.0
     * 
     * @apiExample {curl}访问示例：
     * curl -i http://apis.appt.dev.0nt1.com/apply-servant/ad-item
     * 
     * 
     * @apiSuccess {Int} code请求成功code为200
     * @apiError (通用Code码 xxx)  2049 赞无广告
     *     
     * @apiSuccessExample {json} Response 200 Example
     * 注:该接口需要用户Token验证
     *  HTTP/1.1 200 OK 
     * {
     *   "status_code": "200",
     *   "message": "ok",
     *   "data": [
     *       {
     *           "id": 2,
     *           "key": "key2",
     *           "position": "APPlY-SERVANT",
     *           "type": "LINK",
     *           "title": "申请加入服务者宣传广告",
     *           "remark": "xxx",
     *           "path": "/www/back2/jsd.jpg",
     *           "redirect_url": "http://www.baidu.com",
     *           "sort": 2
     *       }
     *   ]
     *}
     */ 
    
    public function getApplyServantAdItems(Request $request) {
        try {
            return returnData(
                '200',
                'ok',
                $this->adService->getApplyServantAdItems()
            );
        } catch (BusinessException $e) {
          return returnData($e->getCode(),$e->getMessage());
        }
     }
     
}