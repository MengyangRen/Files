<?php

namespace App\Http\Controllers\Api\V1;

use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use App\Services\CommonService;
use App\Services\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends BaseController
{
    protected $user;

    protected $auth;

    public function __construct(UserService $user)
    {
        $this->user = $user;
    }

    /**
     * @api {get} /user 用户信息(user)
     * @apiDescription 用户信息(user)
     * @apiGroup User
     * @apiPermission none
     * @apiParam {None} none
     * @apiVersion 1.0.0
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *          "status_code": 0,
     *          "message": "",
     *          "data": {
     *              "id": "100024",
     *              "nick_name": "",
     *              "mobile": "13613613118",
     *              "score": "",
     *              "sex": "",
     *              "birth": "",
     *              "age": "",
     *              "height": "",
     *              "weight": "",
     *              "profession": "",
     *              "income": "",
     *              "balance": "",
     *              "last_login_at": "2019-08-22 16:17:25"
     *          }
     *      }
     * @apiErrorExample {json} Error-Response:
     *     HTTP/1.1 401 Not Found
     *     {
     *       "error": "UserNotFound"
     *     }
     */
    public function user()
    {

        return success(auth_user());

    }

    /**
     * @api {put} /user 修改用户信息(user)
     * @apiDescription 修改用户信息(user)
     * @apiGroup Auth
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiParam {String} nickname   昵称
     * @apiParam {Int} sex   性别
     * @apiParam {Date} birth   生日
     * @apiParam {Url} avatar   头像
     * @apiParam {String} description   个性签名
     * @apiParam {double} height   身高
     * @apiParam {double} weight   体重
     * @apiParam {String} profession   职业
     * @apiParam {String} income   收入
     *
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *           "status_code": 0,
     *           "message": "修改成功",
     *           "data": []
     *      }
     * @apiErrorExample {json} Error-Response:
     *     HTTP/1.1 400 Bad Request
     *     {
     *       "status_code": 400,
     *       "message": {
     *           "修改失败"
     *        },
     *       "data": []
     *      }
     */
    public function patch(Request $request)
    {
        $validator = Validator::make($request->input(), [
            'nickname' => 'string|max:50',
            'sex' => 'int',
            'birth' => 'string',
            'avatar' => 'url',
        ]);

        $data = $request->all();

        $data['age'] = Carbon::parse($data['birth'])->diffInYears();

        if ($validator->fails())
            throw new BusinessException(
                ApiException::message(
                    ApiException::EX_REQUEST_INVAL
                ),
                ApiException::EX_REQUEST_INVAL
            );
        $result = $this->user->synInfo($request->all());

        return returnData($result['status_code'], $result['message'], $result['data']);
    }

    /**
     * @api {patch} /password 修改密码(password)
     * @apiDescription 修改密码(password)
     * @apiGroup Auth
     * @apiPermission none
     * @apiVersion 1.0.0
     * @apiParam {Mobile} mobile   手机号
     * @apiParam {String} password   密码
     * @apiParam {String} code_key   发送短信后服务端返回的短信key
     * @apiParam {String} code   验证码
     *
     * @apiSuccessExample {json} Success-Response:
     *     HTTP/1.1 200 OK
     *     {
     *           "status_code": 0,
     *           "message": "修改成功",
     *           "data": []
     *      }
     * @apiErrorExample {json} Error-Response:
     *     HTTP/1.1 400 Bad Request
     *     {
     *       "status_code": 400,
     *       "message": {
     *           "修改失败"
     *        },
     *       "data": []
     *      }
     */
    public function editPassword(Request $request, CommonService $service)
    {
        $validator = Validator::make($request->all(), [
            'mobile'   => 'required',
            'password' => 'required',
            'code_key' => 'required',
            'code'     => 'required',
        ]);

        if ($validator->fails()) {
            return error($validator->errors()->first());
        }

        if (!$service->checkMobileCode($request->all())) return error('验证码错误');

        $result = $this->user->editPassword($request->all());

        return returnData($result['status_code'], $result['message'], $result['data']);
    }
}
