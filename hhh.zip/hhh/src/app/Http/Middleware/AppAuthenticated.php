<?php
/**
 * Created by PhpStorm.
 * User: hhb
 * Date: 2018/10/15
 * Time: 16:14
 */

namespace App\Http\Middleware;

use App\Http\Services\RedisService;
use Closure;


class AppAuthenticated
{
    public function handle(
        $request,
        Closure $next,
        $guard = null
    )
    {
        //如果是OPTIONS请求则放行
        if ($request->method() == 'OPTIONS') return $next($request);
        $api_token = $request->header('token');
        if (!$api_token) {
            return returnError('', 'token_null');
        }
        $redisService = new RedisService();
        if (!$redisService->AppTokenVerifyAndRefresh($api_token)) {
            return returnError('', 'token_expired');
        }
        return $next($request);
    }
}
