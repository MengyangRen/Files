<?php
/**
 * Created by PhpStorm.
 * User: hhb
 * Date: 2018/10/22
 * Time: 11:08
 */

namespace App\Http\Middleware;

use Closure;

class AccessControlAllowOrigin
{
    /**
     *
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        header('Access-Control-Allow-Origin:*');
        header("Access-Control-Allow-Headers: Content-Type,Access-Token,api-token,content-type");
        header("Access-Control-Allow-Headers: Access-Token,api-token,token,Content-Type");
        header("Access-Control-Allow-Methods: GET, POST, PATCH, PUT, OPTIONS");
        header("Allow: GET,HEAD,POST,OPTIONS,PUT");
        header("Access-Control-Allow-Credentials: true");
        header("Access-Control-Expose-Headers: true");
        if ($request->method() == 'OPTIONS') return returnSuccess('route not allowed');

        return $next($request);
    }

}
