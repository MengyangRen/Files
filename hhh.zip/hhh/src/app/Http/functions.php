<?php

// 获取当前登录用户
if (! function_exists('auth_user')) {
    /**
     * Get the auth_user.
     *
     * @return mixed
     */
    function auth_user()
    {
        return app('Illuminate\Auth\AuthManager')->user();
    }
}

if (! function_exists('dingo_route')) {
    /**
     * 根据别名获得url.
     *
     * @param string $version
     * @param string $name
     * @param mixed $params
     *
     * @return string
     */
    function dingo_route($version, $name, $params = [])
    {
        return app('Dingo\Api\Routing\UrlGenerator')
            ->version($version)
            ->route($name, $params);
    }
}







if (!function_exists('success')) {

    function success($data, $message = '')
    {
        return [
            'status_code' => 200,
            'message' => $message,
            'data' => $data,
        ];
    }
}

if (!function_exists('error')) {

    function error($message = '')
    {
        return [
            'status_code' => 500,
            'message' => $message,
            'data' => [],
        ];
    }
}

if (!function_exists('returnData')) {

    function returnData($statusCode, $message, $data = [])
    {
        return [
            'status_code' => $statusCode,
            'message' => $message,
            'data' => $data,
        ];
    }
}

/**
 * 加密数据
 * @param $value
 * @return string
 */
if (!function_exists('encryptString')) {
    function encryptString($str, $key)
    {
        $data = openssl_encrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA);
        return base64_encode($data);
    }
}

/**
 * 解密数据
 * @param $value
 * @return string
 */
if (!function_exists('decryptString')) {
    function decryptString($str, $key)
    {
        $decrypt = openssl_decrypt(base64_decode($str), 'AES-128-ECB', $key, OPENSSL_RAW_DATA);
        return $decrypt;
    }
}



if (!function_exists('valid_date')) {
    function valid_date($date)
    {
        //匹配日期格式
        if (preg_match ("/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/", $date, $parts))
        {
            //检测是否为日期,checkdate为月日年
            if(checkdate($parts[2],$parts[3],$parts[1])) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}

if (!function_exists('public_path')) {
    function public_path($path)
    {
        return storage_path('../public/'.$path);
    }
}

if (!function_exists('thumbImage')) {
    //压缩图片
    function thumbImage($im, $maxwidth, $maxheight, $name, $filetype)
    {
        switch ($filetype) {
            case 'image/pjpeg':
            case 'image/jpeg':
                $im = imagecreatefromjpeg($im);    //PHP图片处理系统函数
                break;
            case 'image/gif':
                $im = imagecreatefromgif($im);
                break;
            case 'image/png':
                $im = imagecreatefrompng($im);
                break;
            case 'image/wbmp':
                $im = imagecreatefromwbmp($im);
                break;
        }


        $resizewidth_tag = $resizeheight_tag = false;
        $pic_width = imagesx($im);
        $pic_height = imagesy($im);


        if (($maxwidth && $pic_width > $maxwidth) || ($maxheight && $pic_height > $maxheight)) {
            $resizewidth_tag = $resizeheight_tag = false;
            if ($maxwidth && $pic_width > $maxwidth) {
                $widthratio = $maxwidth / $pic_width;
                $resizewidth_tag = true;
            }
            if ($maxheight && $pic_height > $maxheight) {
                $heightratio = $maxheight / $pic_height;
                $resizeheight_tag = true;
            }
            if ($resizewidth_tag && $resizeheight_tag) {
                if ($widthratio < $heightratio)
                    $ratio = $widthratio;
                else
                    $ratio = $heightratio;
            }
            if ($resizewidth_tag && !$resizeheight_tag)
                $ratio = $widthratio;
            if ($resizeheight_tag && !$resizewidth_tag)
                $ratio = $heightratio;
            $newwidth = $pic_width * $ratio;
            $newheight = $pic_height * $ratio;
            if (function_exists("imagecopyresampled")) {
                $newim = imagecreatetruecolor($newwidth, $newheight);//PHP图片处理系统函数
                imagecopyresampled($newim, $im, 0, 0, 0, 0, $newwidth, $newheight, $pic_width, $pic_height);//PHP图片处理系统函数
            } else {
                $newim = imagecreate($newwidth, $newheight);
                imagecopyresized($newim, $im, 0, 0, 0, 0, $newwidth, $newheight, $pic_width, $pic_height);
            }
            switch ($filetype) {
                case 'image/pjpeg' :
                case 'image/jpeg' :
                    $result = imagejpeg($newim, $name);
                    break;
                case 'image/gif' :
                    $result = imagegif($newim, $name);
                    break;
                case 'image/png' :
                    $result = imagepng($newim, $name);
                    break;
                case 'image/wbmp' :
                    $result = imagewbmp($newim, $name);
                    break;
            }
            imagedestroy($newim);
        } else {
            switch ($filetype) {
                case 'image/pjpeg' :
                case 'image/jpeg' :
                    $result = imagejpeg($im, $name);
                    break;
                case 'image/gif' :
                    $result = imagegif($im, $name);
                    break;
                case 'image/png' :
                    $result = imagepng($im, $name);
                    break;
                case 'image/wbmp' :
                    $result = imagewbmp($im, $name);
                    break;
            }
        }
        return $result;
    }
}
