<?php

namespace App\Events;

class UserRegisterEvent extends Event
{

    /**
     * @var
     */
    public $user;

    /**
     * UserRegisterEvent constructor.
     * @param $user
     */
    public function __construct($user)
    {
        $this->user = $user;
    }

}
