<?php

namespace App\Providers;

use App\Services\InfoService;
use Illuminate\Auth\EloquentUserProvider;

class RedisUserProvider extends EloquentUserProvider
{

    /**
     * Retrieve a user by their unique identifier.
     *
     * @param  mixed  $identifier
     * @return \Illuminate\Contracts\Auth\Authenticatable|null
     */
    public function retrieveById($identifier)
    {
        if (!isset($identifier)) return;

        return InfoService::getInstance()->getInfoById($identifier);
    }


}
