<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{

    public function register()
    {
        $this->app->make('auth')->provider('redis', function ($app, $config) {

            return new RedisUserProvider($app['hash'], $config['model']);

        });
    }

    public function boot()
	{
    //sql调试
	    if (env('APP_DEBUG')) {
	        DB::listen(function ($sql) {
	            foreach ($sql->bindings as $i => $binding) {
	                if ($binding instanceof \DateTime) {
	                    $sql->bindings[$i] = $binding->format('\'Y-m-d H:i:s\'');
	                } else {
	                    if (is_string($binding)) {
	                        $sql->bindings[$i] = "'$binding'";
	                    }
	                }
	            }
	            $query = str_replace(array('%', '?'), array('%%', '%s'), $sql->sql);
	            $query = vsprintf($query, $sql->bindings);
                Log::debug('运行SQL：' . $query);
                Log::debug('运行耗时：' . $sql->time . ' ms');
	        });
	    }
	}
}
