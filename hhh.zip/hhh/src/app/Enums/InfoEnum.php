<?php

namespace App\Enums;


class InfoEnum
{

    const CACHE_ID_KEY        = 'USER_CACHE:ID:';

    const CACHE_INFO_SIGN     = 'USER_CACHE:SIGN:';

    const CACHE_TASK_KEY      = 'USER_CACHE:TASK:';

    const CACHE_ORDER_BIT     = 'USER_CACHE:ORDER:';

}
