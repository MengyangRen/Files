<?php
namespace App\Enums;

/**
 * 
 * 公共常量
 * 配置处
 * 
 */
class CommonEnum
{
	
}
