<?php

namespace App\Services;

use App\Exceptions\ApiException;
use App\Exceptions\BusinessException;
use App\Models\User;
use App\Events\UserRegisterEvent;
use Carbon\Carbon;
use Illuminate\Auth\AuthManager;

class UserService
{
    public $user;

    public $auth;

    public function __construct(User $user, AuthManager $auth)
    {
        if (!$this->user) $this->user = $user;

        if (!$this->auth) $this->auth = $auth;
    }

    public function register (array $data)
    {

        try {

            $attributes = [
                'area_code'=> $data['area_code'],
                'mobile'   => $data['mobile'],
                'nickname' => $data['nickname'],
                'sex'      => $data['sex'],
                'birth'    => $data['birth'],
                'age'      => $data['age'],
                'password' => app('hash')->make($data['password']),
                'last_login_at' => Carbon::now()->toDateTimeString(),
            ];

            $user = $this->user->create($attributes);

            // 初始化用户
            event(new UserRegisterEvent($user));

            $token = $this->auth->fromUser($user);

            return success(compact('token'), '注册成功');

        } catch (\Exception $e) {

            throw new BusinessException(
                ApiException::message(ApiException::EX_SERVER),
                ApiException::EX_SERVER
            );

        }

    }

    public function login (array $data)
    {

        $attributes = [
            'area_code' => $data['area_code'],
            'mobile'    => $data['mobile'],
            'password'  => $data['password'],
        ];

        // 验证失败返回403
        if (! $token = $this->auth->attempt($attributes)) return error('认证失败');

        return success(compact('token'), '登陆成功');

    }

    public function synInfo($data)
    {

        try {
            $fillable = ['nickname','avatar','description','sex','birth','age','height','weight','profession','income'];

            $user = $this->auth->user();

            foreach ($data as $k => $d){

                if (!in_array($k, $fillable)) return error('参数错误');
            }

            $this->user->find($user['id'])->update($data);

            InfoService::getInstance()->setAttribute($user['id'], $data);

        } catch (\Exception $e) {

            throw new BusinessException(
                ApiException::message(ApiException::EX_SERVER),
                ApiException::EX_SERVER
            );

        }

        return success([],'修改成功');
    }

    public function editPassword($data)
    {
        $user = $this->auth->user();

        if ($user['mobile'] != $data['mobile']) return error('电话号码不正确');

        $password = app('hash')->make($data['password']);

        $this->user->find($user['id'])->update(['password' => $password]);

        return success($user);
    }


}
