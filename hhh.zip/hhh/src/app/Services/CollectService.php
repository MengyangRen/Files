<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;
use App\Models\RelationModel;
use App\Models\User;
use App\Models\ServantModel;



/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  收藏服务
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */

class CollectService extends BaseService {

    /**
     * 默认类型码
     */
    const DEFAULE_TYPE_CODE = 1;

    /**
     * 重复申请错误码
     */
    const DEFAULE_REPAT_APPLY_CODE = 23000;

    /**
     * 
     *  添加收藏
     * 
     * @param  array params 
     *  基本数据
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     * 字段说明
     * [
     *     from_uid(收藏者id)
     *     to_uid(目标用户id)
     * ]
     * 
     */
    public function add(array $param) 
    {
        try {

            //是否为服务者
        	$this->_isServant($param['to_uid']);

            $created = RelationModel::getInstance()
                ->create([
					'from_uid' => $param['from_uid'],
					'to_uid'   => $param['to_uid'],
                    'type'     => self::DEFAULE_TYPE_CODE,
                ]);

            if (!$created) 
                throw new BusinessException(
                    'Failed to collect to join the service',
                    2149
                );

            return [];
        
        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } catch (\Exception $e) {
            if ($e->getCode() == self::DEFAULE_REPAT_APPLY_CODE)
                throw new BusinessException(
                    'Repeated collect to join the server error',
                    23002
                );
            else 
                throw $e;
        }
    }

    /**
     * 
     *  删除收藏
     * 
     * @param  array param 
     *  基本数据
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     * 字段说明
     * [
     *     form_uid(收藏者id)
     *     to_uid(目标用户id)
     * ]
     * 
     */
    public function delete(array $param) 
    {
        try {

			$condition = [
				'from_uid' => $param['from_uid'],
				'to_uid'   => $param['to_uid'],
				'type'     => self::DEFAULE_TYPE_CODE,
			  ];
        	
            $deleted = RelationModel::getInstance()
                ->where($condition)
                ->delete();

            if (!$deleted) 
            	throw new BusinessException('delete collection failed',2137);

            return [];

        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } 

    } 
    
    /**
     * 
     *  获取收藏
     * 
     * @param  int uid 
     *  用户id
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     * 
     */
    public function items($uid = null) 
    {

        try {

			$uids = RelationModel::getInstance()
					->getToUidMapByFromUid([
					  	'from_uid' => $uid,
					  	'type'     => self::DEFAULE_TYPE_CODE
					]);
					

			$users = (new User())->getNeedUserInfoInUids($uids);
			$videos = ServantModel::getInstance()->geVideosByUids($uids);

            array_walk(
                $users,
                function(&$user,$index,$videos) {
                    //收藏封面视频添加
                    $user['cover-video'] = $videos[$index]['item1']; 
                },
                $videos
            );

            return $users;


        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } 
    }

}