<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;

use App\Models\SceneModel;
use App\Models\SceneCategroyModel;
use App\Models\SceneTagModel;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  场景模块
 *   
 * @author   m.y
 * @package  App.Scenes
 * @example
 *
 */

class SceneService extends BaseService {

    /**
     * 标示推荐状态码
     */
    const RECOMMEND_STATUS_CODE = 1;

    /**
     * 默认数据状态码
     */
    const DEFAULE_STATUS_CODE = 1;
   

    /**
     * 
     *  获取首页推荐场景
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getRecommendedItems() 
    { 
        try {

            $items = SceneModel::getInstance()
                ->getSceneMapByCateID(
                 SceneCategroyModel::getInstance()
                    ->getCateIdByCondition([
                        'recommend' => self::RECOMMEND_STATUS_CODE,
                        'status'    => self::DEFAULE_STATUS_CODE
                    ])
            );

            foreach ($items as &$item) {
                $tags = SceneTagModel::getInstance()
                   ->getTagMapInIds(
                    $item['tids'],
                    self::DEFAULE_STATUS_CODE
                   );

                unset($item['tids']);
                $item['tags'] = $tags;
            }

            return $items;

        } catch (BusinessException $e) {
            throw new BusinessException($e->getCode(),$e->getMessage());
        } 
    }
    
    /**
    * 
    *  获取分类下的场景集
    * 
    * @param int $cid 
    *  分类id
    * @return mixed $data default array,
    *  else Exception
    *
    * @example
    *  
    */
    public function getCategoryBelowItems($cid = null) 
    {
       try {

            $items = SceneModel::getInstance()
                ->getSceneMapByCateID($cid);
                
            foreach ($items as &$item) {
                $tags = SceneTagModel::getInstance()
                   ->getTagMapInIds(
                    $item['tids'],
                    self::DEFAULE_STATUS_CODE
                   );

                unset($item['tids']);
                $item['tags'] = $tags;
            }

            return $items;
        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } 
    }   
   /**
    * 
    *  获取场景分类
    * 
    * @param null
    * @return mixed $data default array,
    *  else Exception
    *
    * @example
    *  
    */
    public function getCategoryItems($status = null) 
    {
        try {
            return SceneCategroyModel::getInstance()
                    ->getCateMapByCondition([
                        'status' => self::DEFAULE_STATUS_CODE
                    ]);
        } catch (BusinessException $e) {
            throw new BusinessException($e->getCode(),$e->getMessage());
        } 
    }    

}