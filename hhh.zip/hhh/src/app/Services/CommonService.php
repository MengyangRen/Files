<?php
namespace App\Services;

use App\Exceptions\ApiException;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Overtrue\EasySms\EasySms;
use App\Exceptions\BusinessException;
use App\Common\Upload;
use App\Models\StartupModel;
use App\Models\VersionModel;
use App\Models\NoticeModel;
use Gregwar\Captcha\CaptchaBuilder;
use Qiniu\Auth;
use Qiniu\Storage\UploadManager;
use RongCloud\RongCloud;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *   公共服务模块
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */

class CommonService extends BaseService {

    /**
     * 
     *  短信验证码
     * 
     * @param int $mobile
     *    用户手机号
     * @param obj $easySms
     *    短信组件服务对象
     *    
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     *  1.随机5位数字Code码
     *  2.缓存结构 [
     *    'moblie'=>122xx,
     *    'code'=> 1324
     *  ]
     *  
     */
    public function sendVerificationCode($mobile) {

        $code = mt_rand(10000, 99999);

		if (app()->environment('production')) {
			try {
                EasySms::send($mobile, [
				    'content'  => '您的验证码是' . $code
				]);

			} catch (\Overtrue\EasySms\Exceptions\NoGatewayAvailableException $e) {

			    $msg = $e->getException('yunpian')->getMessage();

            	throw new BusinessException($msg ? $msg :'message failed to send !',1076);
			}
		} else { $code = "88888";}

	    $key = 'verificationCode_'.str_random(15);

		$expiredAt = Carbon::now()->addMinutes(10);

	    Cache::put($key, ['mobile' => $mobile, 'code' => $code], $expiredAt);

	    return ['key' => $key,'expired' => $expiredAt];
    }


    public function checkMobileCode($info) {
        
        $info['mobile'] = '+' . $info['area_code'] . $info['mobile'];
        $phone_info = Cache::get($info['code_key']);
        if ($phone_info['mobile'] != $info['mobile'] || $phone_info['code'] != $info['code']) return false;
        return true;
    }

    /**
     * 
     *  获取开机动画
     * 
     * @param  null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     * 
     */
    public function getStartup()
    {

       $data = [];

       $startUps = StartupModel::getInstance()
            ->where(['status' => 1])
            ->orderBy('created_at', 'desc')
            ->get();

        if ($startUps->isEmpty()) 
            throw new BusinessException('No boot animation ads',1077);

        foreach ($startUps as $startUp) {
            $startUp->ad_path = Upload::getUrl(config('sys.upload_images_domain'), $startUp->ad_path,'startup');
            //开机动画
            if ($startUp->type == 1) 
                $data['startup'] = $startUp;
            
            //重启启动动画
            if ($startUp->type == 2) 
                $data['reload'] = $startUp;
        }

        return $data;
    }

    /**
     * 
     *  获取最新版本
     * 
     * @param string $d_
     *    ios or android
     *    
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     * 
     */
    public function getNewVersion($d_ = null)
    {
        $versions = VersionModel::getInstance()
            ->where('platform', $d_)
            ->where('status', 1)
            ->orderBy('version_code', 'desc')
            ->get();

        if ($versions->isEmpty()) 
            throw new BusinessException('No latest version',1099);
        
        return $versions->first();
    }

    /**
     * 
     *  获取系统公告
     * 
     * @param  null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     *
     *  设计与逻辑有点问题
     *  
     */
    public function getNewSysNotice()
    {

        $filed = ['id','msg','type','created_at'];

        $notices = NoticeModel::getInstance()
            ->where('status',0)
            ->where('type','system')
            ->orderByDesc('created_at')
            ->get($filed);

        if ($notices->isEmpty()) 
            throw new BusinessException('No latest system announcement ',1099);

        return $notices;

    }

    /**
     * 获取图片验证码
     *
     * @param $mobile
     * @return array
     */
    public function getCaptchas($mobile = NULL)
    {

        $key = 'captcha-'.str_random(15);
        $captcha = (new CaptchaBuilder)->build();
        $expire = Carbon::now()->addMinutes(2);

        Cache::put($key,[
            'mobile' => $mobile,
            'code' => $captcha->getPhrase()
        ], 
        $expire);
        
        return [
            'key' => $key,
            'expire' => $expire->toDateTimeString(),
            '_imageBase64' => $captcha->inline()
        ];
    }

    /**
     * 生成上传凭证
     *
     * @return string $token
     */
    public function getUploadToken(){

        $accessKey = config('qiniu.accessKey');
        $secretKey = config('qiniu.secretKey');
        $bucket    = config('qiniu.bucket');//上传空间名称

        $auth = new Auth($accessKey, $secretKey);

        return $auth->uploadToken($bucket);//生成token
    }

    /**
     * 七牛图片上传
     *
     * @param $request
     * @return mixed
     * @throws BusinessException
     */
    public function qnUpload($request)
    {
        $uploadManager = new UploadManager();

        $file     =  $request->file();
        $name     =  $file->getFilename();
        $filePath =  $file->getPath();
        $type     =  $file->getType();

        list($result,$error) = $uploadManager->putFile(
            $this->getUploadToken(),
            $name,
            $filePath,
            null,
            $type
        );

        if($error) throw new BusinessException(
            ApiException::message(
                ApiException::EX_SERVER
            ),
            ApiException::EX_SERVER
        );

        return $result;
    }

    public function ryRegister(){

        $client = new RongCloud(config('sys.ry_key'),config('sys.ry_secret'));

        $user_info = auth_user();

        if ($user_info['ry_token']) {
            return success([
                'code'   => 200,
                'userId' => 'user_' . $user_info['id'],
                'token'  => $user_info['ry_token'],
            ], '注册成功');
        }

        $user = [
            'id'=> 'user_' . $user_info['id'],
            'name'=> $user_info['nickname'] ?: '会员'.$user_info['id'],
            'portrait'=> $user_info['avatar'] ?: 'https://v1.qzone.cc/avatar/201907/29/17/03/5d3eb6657bb6d261.jpg',
        ];

        try{
            $result = $client->getUser()->register($user);

        }catch (\Exception $exception){

            throw new BusinessException(
                ApiException::message(ApiException::EX_THIRD_SERVICE_ERR),
                ApiException::EX_THIRD_SERVICE_ERR
            );
        }

        InfoService::getInstance()->setAttribute($user_info['id'], [
            'ry_token' => $result['token']
        ]);

        return success($result, '注册成功');
    }

}