<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;

use App\Models\User;
use App\Models\CommentModel;
use Illuminate\Support\Facades\DB;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * 评论模块
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */

class CommentService extends BaseService {

    /**
     * 默认评论类型
     */
    const DEFAULE_COMMENT_TYPE_CODE = 1;

    /**
     * 重复申请错误码
     */

    const DEFAULE_COMMENT_PAGE_NUM = 5;

    /**
     * 
     *  添加书
     * 
     * @param  array params 
     *  基本数据
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     * 字段说明
     * [
     *     from_uid(收藏者id)
     *     to_uid(目标用户id)
     * ]
     * 
     */
    public function add(array $param) 
    {
        try {

            //是否为服务者
        	$this->_isServant($param['to_uid']);

            $created = CommentModel::getInstance()
                ->create([
					'from_uid' => $param['from_uid'],
					'to_uid'   => $param['to_uid'],
					'content'  => $param['content'],
                    'type'     => self::DEFAULE_COMMENT_TYPE_CODE,
                ]);

            if (!$created) 
                throw new BusinessException(
                    'comment service addition failed',
                    30690
                );

            return [];
        
        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } 

        // catch (\Exception $e) {
        //     if ($e->getCode() == self::DEFAULE_REPAT_APPLY_CODE)
        //         throw new BusinessException(
        //             'Repeat comment error',
        //             13002
        //         );
        //     else 
        //         throw $e;
        // }
    }

    /**
     * 
     *  评论列表
     * 
     * @param  int  uid 
     *  服务者的uid
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     * 
     */
    public function items($uid = null)
    {
    	$items = CommentModel::where('to_uid','=',$uid)
		    	->paginate(self::DEFAULE_COMMENT_PAGE_NUM)
		    	->toArray();
    	
    	if (empty($items['data']))
    		throw new BusinessException('No comment data yet',20790);

    	return [
    		'items'  => $items['data'],
    		'last_page'=> $items['last_page'],
    		'total' => $items['total']
    	];
    }


}