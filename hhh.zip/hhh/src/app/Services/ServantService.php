<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;

use App\Models\ServantModel;
use App\Models\ServantTagMiddleModel;
use App\Models\ServantTagModel;
use Illuminate\Support\Facades\DB;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  服务者模块
 *   
 * @author   m.y
 * @package  App.Servant
 * @example
 *
 */

class ServantService extends BaseService {

    /**
     * 标示推荐状态码
     */
    const RECOMMEND_STATUS_CODE = 1;

    /**
     * 默认数据状态码
     */
    const DEFAULE_STATUS_CODE = 1;


    /**
     * 重复申请错误码
     */
    const DEFAULE_REPAT_APPLY_CODE = 23000;

    /**
     * 
     *  申请服务者
     * 
     * @param  array data 
     *  服务者的基本申请数据
     *  
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *
     * 字段说明
     * [
     *     用户id,
     *     身份证,
     *     视频列表,
     *     封面图
     * ]
     * 
     */
    public function apply(array $data ) 
    {
        try {

            $created = ServantModel::getInstance()
                ->create([
                    'uid'               => $data['uid'],
                    'id_card'           => $data['id_card'],
                    'cover_img'         => $data['cover_img'],
                    'propaganda_video'  => $data['p_v']
                ]);
            
            if (!$created) 
                throw new BusinessException(
                    'Failed to apply to join the service',
                    2127
                );

            return [];
        
        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } catch (\Exception $e) {
            if ($e->getCode() == self::DEFAULE_REPAT_APPLY_CODE)
                throw new BusinessException(
                    'Repeated application to join the server error',
                    23001
                );
            else 
                throw $e;
        }
    }

    /**
     * 
     *  获取服务者标签
     *  
     * @param  null
     * @return mixed $data default array,
     *  else Exception
     * 
     */
    public function getTags() 
    {
        try {
            
            $filed = ['id','sort','title','type'];
            $tags = ServantTagModel::getInstance()
                ->orderBy('sort', 'asc')
                ->get($filed);

            if ($tags->isEmpty()) 
                throw new BusinessException('No label data yet',2147);

            return $tags;
        } catch (BusinessException $e) {
             throw new BusinessException($e->getMessage(),$e->getCode());
        }
      

    }

    

    /**
     * 
     *  为服务者贴标签
     *  
     * @param  null
     * @return mixed $data default array,
     *  else Exception
     * @example 
     *
     * 
     * 字段说明
     * [
     *     uid,
     *     标签id集,
     * ]
     */
    public function labelld(array $param = null) 
    {
        try {
            

            $data = [];
            foreach ($param['tags'] as $tag) {
                $data[] = [
                    'uid' => $param['uid'],
                    'tid' => $tag,
                    //'created_at' => 
                ]; 
            }
            
            $created = DB::table(
                ServantTagMiddleModel::getInstance()
                    ->getTableName()
                )->insert($data);
            
            if (!$created) 
                throw new BusinessException(
                    'Failed to add to join the service',
                    31270
                );

            return [];
        
        } catch (BusinessException $e) {
            throw new BusinessException($e->getMessage(),$e->getCode());
        } catch (\Exception $e) {
            if ($e->getCode() == self::DEFAULE_REPAT_APPLY_CODE)
                throw new BusinessException(
                    'Repeat adding the same label to the service provider. ',
                    33001
                );
            else 
                throw $e;
        }

    }

}