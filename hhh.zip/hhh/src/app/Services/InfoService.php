<?php
/**
 * Created by PhpStorm.
 * User: hhb
 * Date: 2018/11/21
 * Time: 17:23
 */

namespace App\Services;

use Carbon\Carbon;
use App\Enums\InfoEnum;
use Illuminate\Support\Facades\Redis;


class InfoService
{
    private static $_instance;

    public $redis;

    /**
     *
     * getInstance
     *
     * @author pro
     */
    public static function getInstance ()
    {
        if (empty(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct()
    {
        $this->redis = Redis::connection('info');
    }

    /**
     * 设置用户信息
     *
     * @param $event
     */
    public function setInfo($event){

        $this->redis->hset(
            InfoEnum::CACHE_ID_KEY.$event->user->id,
            'id', $event->user->id,
            'nickname', $event->user->nickname,
            'avatar', $event->user->avatar,
            'area_code', $event->user->area_code,
            'mobile', $event->user->mobile,
            'score', $event->user->score,
            'sex', $event->user->sex,
            'birth', $event->user->birth,
            'age', $event->user->age,
            'height', $event->user->height,
            'weight', $event->user->weight,
            'profession', $event->user->profession,
            'income', $event->user->income,
            'balance', $event->user->balance,
            'last_login_at', $event->user->last_login_at
        );
    }

    /**
     * 得到用户信息
     *
     * @param $id
     * @return mixed
     */
    public function getInfoById($id){

        return $this->redis->hgetall(InfoEnum::CACHE_ID_KEY . $id);

    }

    /**
     * 得到用户值
     *
     * @param $id
     * @param $key
     * @return mixed
     */
    public function getValueById($id, $key){

        return $this->redis->hget(InfoEnum::CACHE_ID_KEY . $id, $key);

    }

    /**
     * 设置用户局部信息
     *
     * @param int $id
     * @param array $array
     */
    public function setAttribute(int $id,array $array){

        foreach ($array as $k => $v) {

            $this->redis->hset(InfoEnum::CACHE_ID_KEY . $id, $k, $v);
        }

    }

    /**
     * 增加用户局部信息次数
     *
     * @param int $id
     * @param array $array (params -> function setInfo)
     * @param int $add
     */
    public function addAttributeCount(int $id, array $array, $add = 1){

        foreach ($array as $v) {

            $this->redis->hincrby(InfoEnum::CACHE_ID_KEY . $id, $v, $add);
        }

    }
}
