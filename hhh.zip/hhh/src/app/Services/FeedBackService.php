<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;
use App\Models\FeedbackModel;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  意见反馈模块
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */

class FeedBackService extends BaseService {

    /**
     * 
     *  获取问题分类
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getQuestionCatItems() 
    {
        return [
            ["key"=>"other","name"=>"其他"],
            ["key"=>"add-service","name"=>"加入服务"],
            ["key"=>"withraw-deposit","name"=>"提现"],
            ["key"=>"payment","name"=>"提现"],
            ["key"=>"send-order","name"=>"发单"],
            ["key"=>"grab-order","name"=>"抢单"],
            ["key"=>"custom-serice","name"=>"客户"]
        ];
    }  

    /**
     * 
     *  创建问题项
     * 
     * @param string $cat_key
     *    问题分类key   
     * 
     * @param string $pic
     *    图片列
     *       
     * @param string $remark
     *    基本问题描述
     *    
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function create($uid = null ,$keys = null,$pic = null ,$remark = null) 
    {
        $created = FeedbackModel::getInstance()
            ->create([
            'uid'   => $uid,
            'keys'  => $keys,
            'pic'   => $pic,
            'remark'=> $remark  
        ]);

        if (!$created)
            throw new BusinessException('Feedback Problem creation failed',2089);

        return [];
    }
}