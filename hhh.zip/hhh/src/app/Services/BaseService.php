<?php
namespace App\Services;

use App\Exceptions\BusinessException;

/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  基本服务类
 *  
 * @author  m.y
 * @package App.Service
 * @example
 * 
 */

class BaseService
{
    /**
     * 
     *  检查用户是否为服务者
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
	public function _isServant($uid = null) {
		try {
		 
		   $checked =  \App\Models\ServantModel::getInstance()
		  	 ->where('uid',$uid)
		  	 ->first('id');
		  	if (!$checked) 
		  		throw new \Exception(
		  			'collection of non-service users',
		  			200467
		  		);

		} catch (BusinessException $e) {
			throw new BusinessException($e->getCode(),$e->getMessage());
		}
	}
}