<?php

namespace App\Services;

use App\Models\OrderModel;

class OrderService
{
    public $model;

    public function __construct(OrderModel $orderModel)
    {

        if (!$this->model) $this->model = $orderModel;

    }

}
