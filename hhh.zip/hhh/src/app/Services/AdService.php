<?php
namespace App\Services;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use App\Exceptions\BusinessException;
use App\Models\AdModel;


/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 *  广告模块
 *   
 * @author   m.y
 * @package App.Common
 * @example
 *
 */

class AdService extends BaseService {

    /**
     * 
     *  获取首页广告
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getHomeAdItems() 
    {
        $condition['position'] = 'HOME-BANNER-MODEL';
        $condition['status']  = 1;

        $ads = AdModel::getInstance()
            ->where($condition)
            ->orderBy('sort', 'desc')
            ->get();

        if ($ads->isEmpty()) 
            throw new BusinessException(
                'There is no advertisement for the time being ',2049);

        return $ads;
    }  

    /**
     * 
     *  获取登陆模块的广告
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getLoginAdItems() 
    {
        $condition['position'] = 'LOGIN-MODEL';
        $condition['status']  = 1;

        $ads = AdModel::getInstance()
            ->where($condition)
            ->orderBy('sort', 'desc')
            ->get();

        if ($ads->isEmpty()) 
            throw new BusinessException(
                'There is no advertisement for the time being ',2049);
        
        return $ads;
    }

    /**
     * 
     *  获取钱包模块的广告
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getWalletAdItems() 
    {

        $condition['position'] = 'WALLET-MODEL';
        $condition['status']  = 1;

        $ads = AdModel::getInstance()
            ->where($condition)
            ->orderBy('sort', 'desc')
            ->get();

        if ($ads->isEmpty()) 
            throw new BusinessException(
                'There is no advertisement for the time being ',2049);
        
        return $ads;
    }


    /**
     * 
     *  获取申请加入服务者广告
     * 
     * @param null
     * @return mixed $data default array,
     *  else Exception
     *
     * @example
     *  
     */
    public function getApplyServantAdItems() 
    {

        $condition['position'] = 'APPlY-SERVANT';
        $condition['status']  = 1;

        $ads = AdModel::getInstance()
            ->where($condition)
            ->orderBy('sort', 'desc')
            ->get();

        if ($ads->isEmpty()) 
            throw new BusinessException(
                'There is no advertisement for the time being ',2049);
        
        return $ads;
    }

}