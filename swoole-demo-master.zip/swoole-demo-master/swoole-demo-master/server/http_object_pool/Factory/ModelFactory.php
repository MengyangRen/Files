<?php

/**
 * Created by PhpStorm.
 * User: rookiejin <mrjnamei@gmail.com>
 * Date: 2018/1/5
 * Time: 14:42
 * description: ModelFactory.php - swoole-demo
 */
class ModelFactory
{

}
