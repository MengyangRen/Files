<?php
class Pool
{
    // 连接池数组 .
    protected $connections ;

    // 最大连接数
    protected $max ;

    // 最小连接数
    protected $min ;

    // 已连接数
    protected $count = 0 ;

    protected $inited = false ;

    // 单例
    private static $instance ;

    //数据库配置
    protected $config  = array(
        'host' => '127.0.0.1',
        'port' => 3306,
        'user' => 'guest',
        'password' => 'guest123456',
        'database' => 'zhiCloudCustoms',
        'charset' => 'utf8',
        'timeout' => 2,
    );

    public function __construct()
    {
        //初始化连接是一个Spl队列
        $this->connections = new SplQueue() ;
        $this->max = 30 ;
        $this->min = 5 ;
        // 绑定单例
        self::$instance = & $this ;
    }

    // worker启动的时候 建立 min 个连接
    public function init()
    {
        if($this->inited){
            return ;
        }
        for($i = 0; $i < $this->min ; $i ++){
            $this->generate();
        }
        return $this ;
    }

    /**
     * 维持当前的连接数不断线，并且剔除断线的链接 .
     */
    public function keepAlive()
    {
        // 2分钟检测一次连接
        swoole_timer_tick( 1000 , function(){
            // 维持连接
            while ($this->connections->count() >0 && $next=$this->connections->shift()){
                $next->query("select 1" , function($db ,$res){
                    if($res == false){
                        return ;
                    }
                   // echo "当前连接数：" . $this->connections->count() . PHP_EOL ;
                    $this->connections->push($db);
                });
            }
        });

        swoole_timer_tick(1000 , function(){
            // 维持活跃的链接数在 min-max之间
            if($this->connections->count() > $this->max) {
                while($this->max < $this->connections->count()){
                    $next = $this->connections->shift();
                    $next->close();
                    $this->count -- ;
                    echo "关闭连接...\n" ;
                }
            }
        });
    }

    // 建立一个新的连接
    public function generate($callback = null)
    {
        $db = new swoole_mysql ;
        $db->connect($this->config , function($db , $res) use($callback) {
            if($res == false){
                throw new Exception("数据库连接错误::" . $db->connect_errno . $db->connect_error);
            }
            $this->count ++ ;
            $this->addConnections($db);
            if(is_callable($callback)){
                call_user_func($callback);
            }
        });
    }

    // 连接推进队列
    public function addConnections($db)
    {
        $this->connections->push($db);
        return $this;
    }


    // 执行数据库命令 . 会判断连接数够不够，够就直接执行，不够就新建连接执行
    public function query($query , $callback)
    {
        if($this->connections->count() == 0) {
            $this->generate(function() use($query,$callback){
                $this->exec($query,$callback);
            });
        }
        else{
           $this->exec($query,$callback);
        }
    }
    
    // 直接执行数据库命令并且 callback();
    private function exec($query, $callback)
    {
        $db = $this->connections->shift();
        $db->query($query ,function($db , $result) use($callback){
            $this->connections->push($db);
            $callback($result);
        });
    }

    public static function getInstance()
    {
        if(is_null(self::$instance)){
            new Pool();
        }
        return self::$instance;
    }
}

class Util {
    public static function jsonEncode(array $data = NULL) {
        return json_encode($data);
    }
    public static function jsonDecode($str = NULL) {
        return (array)json_decode($str);
    }
}

$server = new swoole_server("0.0.0.0" ,7501);
$server->set([
    'worker_num' => 4,
    'daemonize' => false, 
]);

/**
 * 
 * 初始化连接池 检查连接
 * 
 * @param objs $server
 * @param int $wid
 * @return void
 * 
 */
    
$server->on("WorkerStart",function($server , $wid){
    Pool::getInstance()->init()->keepAlive();
});


/**
 * 
 * 接受连接池客户端数据请求
 * 
 * @param string $ip
 * @param int $fd
 * @return void
 * 
 */
$server->on("Receive",function($server,$fd,$reactorId,$data) {

    $_uq = Util::jsonDecode($data)['_uq'];
    $_sql = Util::jsonDecode($data)['_sql'];
    $_org = Util::jsonDecode($data)['_org'];
    $ip = $server->connection_info($fd)['remote_ip'];

    print PHP_EOL;
    print '------------------------------------------------------';
    print PHP_EOL;
    print "\033[32;40m [IP] \033[0m".':'. $ip;
    print PHP_EOL;
    print "\033[32;40m [编号] \033[0m".':'. $_uq;
    print PHP_EOL;
    print "\033[32;40m [语句] \033[0m".':'.$_sql;
    print PHP_EOL;
    print "\033[32;40m [应用] \033[0m".':'.$_org;
    print PHP_EOL;
    print '------------------------------------------------------';
    print PHP_EOL;

    $pool = Pool::getInstance()->query($_sql, function($res) use($server,$fd) {
        $server->send($fd,Util::jsonEncode(array(
            'code'=>200,
            'data'=>$res,
        )));
    });

});
$server->start();