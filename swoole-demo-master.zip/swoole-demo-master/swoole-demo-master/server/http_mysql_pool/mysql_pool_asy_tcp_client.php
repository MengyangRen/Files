<?php
class mysql_pool_syn_tcp_client 
{
    private $client;
    public static $ip = "127.0.0.1";
    public static $port = 7501;
    public static $org = array(
    	'2022'=>'crmTaskServer',
    	'3033'=>'crmInitTaskServer',
    	'4044'=>'multiProcessTask',
    	'5055'=>'pushTask',
    );

    public function __construct() {
        if (empty($this->client)) {
           $this->client = new swoole_client(SWOOLE_SOCK_TCP);
        }
    }
    public function connect($ip = NULL ,$port = NULL) {
        if (empty($ip))
            $ip = mysql_pool_syn_tcp_client::$ip;
        if (empty($port)) 
            $port = mysql_pool_syn_tcp_client::$port;

        $fp = $this->client->connect($ip,$port,-1); 
        if( !$fp ) {
        	print "Swoole database connection pool connection failed \n";
            print "Error: {$fp->errMsg}[{$fp->errCode}]\n";
            return;
        }
    }
    
    public function send($data) {
        if (!$this->client->isConnected()) {
           print "Swoole database connection pool not commected !\n";
           return ;
        }

        if (!is_string($data)) {
           $data['_org'] = mysql_pool_syn_tcp_client::$org[$data['_org']];
           $data = json_encode($data);
        }

        if ($this->client->send($data)) {
			$ret = $this->client->recv();
            $ret = json_decode($ret);
            if ($ret->data != 'flase') {
                return $this->makeJsonToArray($ret->data);
            } else {
                return false;
            }
        }
        return false;
    }

	public function makeJsonToArray($json){
	    $json = is_object($json)?get_object_vars($json):$json;
        $arr = array();
        foreach ($json as $key => $value) {
              if (is_array($value)|| is_string($value)) {
                  $val = $value;
        	  } else {
        	  	 if(is_object($value)) {
        	  	 	$val = $this->makeJsonToArray($value);
        	  	 }
        	  }
        	  $arr[$key] = $val;
        	# code...
        }
        $json = null;
        return $arr;
	}
    public function close() {
       return $this->client->close();
    }
    public function isConnected() {
        return $this->client->isConnected();
    }
}

$mysql_pool_syn_tcp_client = new mysql_pool_syn_tcp_client();
$mysql_pool_syn_tcp_client->connect();
$ret = $mysql_pool_syn_tcp_client->send(array(
	'_sql'=>"select count(*) as num from zhiCloudCustoms.companys",
	'_uq' =>md5(time()),
	'_org'=>2022,
));
var_dump($ret);
$mysql_pool_syn_tcp_client->close();

