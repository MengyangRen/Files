### 该demo为数据库连接池demo 

## Usage : 

``` 
修改 Pool::$config 属性为自己的mysql配置。然后在 onrequest 回调中写sql .
php Pool.php 
访问: localhost:9501  
```
